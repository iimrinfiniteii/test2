<?php if (!defined('PARENT')) { exit; } ?>
<!DOCTYPE html>
<html lang="<?php echo $this->LANG; ?>" dir="<?php echo $this->DIR; ?>">
  <head>
    <meta charset="<?php echo $this->CHARSET; ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php echo $this->META_DESC; ?>">
    <meta name="keywords" content="<?php echo $this->META_KEYS; ?>">
    <base href="<?php echo BASE_HREF; ?>">
    <title><?php echo $this->TITLE; ?></title>
    <link rel="stylesheet" href="<?php echo BASE_HREF; ?>content/<?php echo THEME; ?>/css/normalize.css" type="text/css">
    <link rel="stylesheet" href="<?php echo BASE_HREF; ?>content/<?php echo THEME; ?>/css/animate.css" type="text/css">
    <link href="<?php echo BASE_HREF; ?>content/<?php echo THEME; ?>/css/bootstrap.css" rel="stylesheet">
    <link href="<?php echo BASE_HREF; ?>content/<?php echo THEME; ?>/css/font-awesome/fontawesome.css" rel="stylesheet">
    <link href="<?php echo BASE_HREF; ?>content/<?php echo THEME; ?>/css/theme.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo BASE_HREF; ?>content/<?php echo THEME; ?>/css/plugins.css" type="text/css">
    <link rel="stylesheet" href="<?php echo BASE_HREF; ?>content/<?php echo THEME; ?>/css/mobile.css" type="text/css">
    <?php
    // Load plugins if required..DO NOT remove
    echo $this->PLUGIN_LOADER;
    ?>
    <link rel="ICON" href="<?php echo BASE_HREF; ?>favicon.ico">
  </head>

  <body>

    <?php
    // Shows only on extra small screens
    ?>
    <div class="toppagebar hidden-sm hidden-md hidden-lg push">
      <a href="<?php echo BASE_HREF; ?>"><?php echo $this->STORE; ?></a>
    </div>

    <div class="navbar push">
      <div class="navbar-inner">
        <div class="container">
          <div class="table-responsive">
            <table class="table">
              <tbody>
                <tr>
                  <td><i class="fas fa-bars<?php echo ($this->SETTINGS->sysstatus == 'yes' ? ' menu-btn ' : ' '); ?>fa-fw"></i></td>
                  <td class="hidden-xs"><a href="<?php echo BASE_HREF; ?>"><?php echo $this->STORE; ?></a></td>
                  <td>
                    <?php
                    // We only show links if system is active
                    if ($this->SETTINGS->sysstatus == 'yes') {
                      // Show account link if not logged in..
                      if (LOGGED_IN == 'no') {
                      ?>
                      <a href="<?php echo $this->URL[1]; ?>"><i class="far fa-user fa-fw"></i> <span class="hidden-xs"><?php echo $this->TXT[1]; ?></span></a>
                      <?php
                      } else {
                      ?>
                      <a href="<?php echo $this->URL[1]; ?>"><i class="fas fa-tachometer-alt fa-fw"></i> <span class="hidden-xs"><?php echo $this->TXT[1]; ?></span></a>
                      <?php
                      }
                      ?>
                      <a href="<?php echo $this->URL[2]; ?>"><i class="far fa-calendar-alt fa-fw"></i> <span class="hidden-xs"><?php echo $this->TXT[4]; ?></span></a>
                      <?php
                      // Hide basket on checkout screen..
                      if (!defined('BASKET_SCREEN_LOADED')) {
                      ?>
                      <a href="#" onclick="mswBasket();return false"><i class="fas fa-shopping-basket fa-fw"></i> <span class="hidden-xs"> <?php echo $this->TXT[15][0]; ?></span> (<span class="basket_count"><?php echo $this->BASKET_COUNT; ?></span>)</a>
                      <?php
                      }
                      ?>
                      <a href="<?php echo $this->URL[9]; ?>"><i class="far fa-life-ring fa-fw"></i> <span class="hidden-xs"><?php echo $this->TXT[15][10]; ?></span></a>
                      <?php
                    }
                    ?>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>

    <div class="container mainmswarea push" id="container">