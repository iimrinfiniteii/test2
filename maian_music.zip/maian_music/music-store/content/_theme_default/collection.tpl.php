<?php if(!defined('PARENT')) { exit; }

/* COLLECTION TEMPLATE
----------------------------------*/

?>

    <div class="row mainarea collectionarea">
      <form method="post" action="#">
        <div class="col-lg-9 col-md-8">

          <h1><?php echo $this->TXT[0]; ?></h1>

          <?php
          // Cover art..small screens..appears at top..
          if (in_array($this->PLATFORM, array('tablet', 'mobile')) && $this->COLLECTION->coverart) {
          ?>
          <div class="panel panel-default coverart">
            <div class="panel-body">
              <img src="<?php echo $this->BUILD->cover($this->COLLECTION->coverart); ?>" alt="" class="img-responsive">
            </div>
          </div>
          <?php
          }
          ?>

          <div class="panel panel-default">
            <div class="panel-body">
              <?php
              // Collection description..
              echo mswNL2BR(mswSH($this->COLLECTION->information));
              ?>
            </div>
          </div>

          <?php
          // Addthis social sharing..
          if ($this->API['addthis']['code'] && $this->API['addthis']['html']) {
          ?>
          <div class="text-right social">
            <?php
            echo $this->API['addthis']['html'];
            ?>
            <script src="//s7.addthis.com/js/300/addthis_widget.js#pubid=<?php echo $this->API['addthis']['code']; ?>" async></script>
          </div>
          <?php
          }

          // Show tracks..
          if ($this->TRACKS) {
          ?>
          <div class="panel panel-default trackarea">
            <div class="panel-body">
              <div class="table-responsive">
                <table class="table table-striped table-hover">
                <thead>
                  <tr>
                    <th><i class="fas fa-music fa-fw"></i></th>
                    <th><?php echo $this->TXT[6]; ?></th>
                    <th><?php echo $this->TXT[7]; ?></th>
                    <th><?php echo $this->TXT[10]; ?></th>
                    <th><?php echo $this->TXT[9]; ?></th>
                    <th class="text-right">&nbsp;</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  // html/collection-tracks.tpl
                  // html/track-play-button.tpl
                  echo $this->TRACKS;
                  ?>
                </tbody>
                </table>
              </div>
            </div>
            <div class="panel-footer">
              <span class="pull-right">
                <button type="button" class="btn btn-default btn-sm" onclick="mswTracks('<?php echo $this->COLLECTION->id; ?>_MP3')"><i class="fas fa-plus fa-fw"></i><span class="hidden-xs"> <?php echo $this->TXT[8]; ?></span></button>
              </span>
              <?php
              // Is CD as download enabled?
              if ($this->COST != '') {
              ?>
              <button type="button" class="btn btn-primary btn-sm" onclick="mswCart('<?php echo $this->COLLECTION->id; ?>_MP3')"><i class="fas fa-headphones fa-fw"></i><span class="hidden-xs"> <?php echo $this->TXT[16]; ?>:</span> <?php echo $this->COST; ?></button>
              <?php
              }
              // Is CD as purchase enabled?
              if ($this->SETTINGS->cdpur == 'yes' && $this->COSTCD != '') {
              ?>
              <button type="button" class="btn btn-success btn-sm" onclick="mswCart('<?php echo $this->COLLECTION->id; ?>_CD')"><i class="fas fa-cart-plus fa-fw"></i><span class="hidden-xs"> <?php echo $this->TXT[17]; ?>:</span> <?php echo $this->COSTCD; ?></button>
              <?php
              }
              ?>
            </div>
          </div>
          <?php
          }

          // Comments
          if ($this->COMMENTS) {
          ?>
          <h2><?php echo $this->TXT[11]; ?></h2>
          <div class="panel panel-default">
            <div class="panel-body">
              <?php
              // html/disqus.tpl
              echo $this->COMMENTS;
              ?>
            </div>
          </div>
          <?php
          }

          // Related..
          if ($this->RELATED) {
          ?>
          <h2><?php echo $this->TXT[12]; ?></h2>
          <?php
          // html/collection.tpl
          echo $this->RELATED;
          }

          // Search tags..
          if ($this->TAGS) {
          ?>
          <h2><?php echo $this->TXT[13]; ?></h2>
          <div class="panel panel-default">
            <div class="panel-body">
              <?php
              // html/collection.tpl
              echo $this->TAGS;
              ?>
            </div>
          </div>
          <?php
          }
          ?>

        </div>
        <div class="col-lg-3 col-md-4">
          <?php
          // Cover art..large screens.
          if (in_array($this->PLATFORM, array('pc')) && $this->COLLECTION->coverart) {
          ?>
          <div class="panel panel-default coverart">
            <div class="panel-body">
              <img src="<?php echo $this->BUILD->cover($this->COLLECTION->coverart); ?>" alt="" class="img-responsive">
            </div>
          </div>
          <?php
          }
          // Release date and catalogue number..
          if ($this->COLLECTION->released > 0 || $this->COLLECTION->catnumber) {
          ?>
          <div class="panel panel-default">
            <div class="panel-body">
              <?php
              if ($this->COLLECTION->released > 0) {
              ?>
              <b><?php echo $this->TXT[2]; ?></b>:<br><?php echo $this->DT->dateTimeDisplay($this->COLLECTION->released, $this->SETTINGS->dateformat);
              }
              // Show cat. number if there is one..
              if ($this->COLLECTION->catnumber) {
              if ($this->COLLECTION->released > 0) {
              ?>
              <br><br>
              <?php
              }
              ?>
              <b><?php echo $this->TXT[3]; ?></b>:<br><?php echo mswSH($this->COLLECTION->catnumber);
              }
              ?>
            </div>
          </div>
          <?php
          }
          // Styles..
          if ($this->STYLES) {
          ?>
          <div class="panel panel-default">
            <div class="panel-heading">
              <i class="fas fa-headphones fa-fw"></i> <?php echo $this->TXT[1]; ?>
            </div>
            <div class="panel-body">
              <?php
              echo $this->STYLES;
              ?>
            </div>
          </div>
          <?php
          }
          ?>
          <div class="panel panel-default">
            <div class="panel-body">
              <i class="fas fa-binoculars fa-fw"></i> <?php echo $this->HIT_COUNTER; ?>
            </div>
          </div>
          <?php
          // Right panel..
          include(dirname(__file__) . '/right-panel.tpl.php');
          ?>
        </div>
      </form>
    </div>