<?php if(!defined('PARENT')) { exit; }

/* PROFILE TEMPLATE
----------------------------------*/

?>

    <div class="formfield">
      <form method="post" action="#">
        <div class="row mainarea">
          <div class="col-lg-9 col-md-8">

            <h1><?php echo $this->TXT[0]; ?></h1>

            <div class="panel panel-default">
              <div class="panel-body">
                <div class="form-group">
                  <label><?php echo $this->TXT[1]; ?></label>
                  <input type="text" name="name" class="form-control" value="<?php echo mswSH($this->ACCOUNT['name']); ?>">
							  </div>

                <div class="form-group">
                  <label><?php echo $this->TXT[2]; ?></label>
                  <input type="text" name="email" class="form-control" value="<?php echo mswSH($this->ACCOUNT['email']); ?>">
                </div>

                <div class="form-group">
                  <label><?php echo $this->TXT[3]; ?></label>
                  <select name="timezone" class="form-control">
									 <option value="">- - -</option>
								   <?php
									 if (!empty($this->TIMEZONES)) {
								     foreach ($this->TIMEZONES AS $k => $v) {
								     ?>
								     <option value="<?php echo $k; ?>"<?php echo ($this->ACCOUNT['timezone']==$k ? ' selected="selected"' : ''); ?>><?php echo $v; ?></option>
								     <?php
								     }
									 }
								   ?>
									</select>
								</div>

                <div class="form-group">
                  <label><?php echo $this->TXT[12]; ?></label>
                  <select name="accCountry" class="form-control">
									 <?php
									 if (!empty($this->COUNTRIES)) {
								     foreach ($this->COUNTRIES AS $k => $v) {
								     ?>
								     <option value="<?php echo $k; ?>"<?php echo ($this->ACCOUNT['accCountry']==$k ? ' selected="selected"' : ''); ?>><?php echo $v; ?></option>
								     <?php
								     }
									 }
								   ?>
									</select>
							  </div>

                <div class="form-group">
                  <label><?php echo $this->TXT[4]; ?></label>
                  <input type="password" name="passwd" class="form-control">
							  </div>

                <div class="form-group">
                  <label><?php echo $this->TXT[5]; ?></label>
                  <input type="password" name="passwd2" class="form-control">
                </div>
              </div>
            </div>

            <h2><?php echo $this->TXT[6]; ?></h2>

            <div class="panel panel-default">
              <div class="panel-body">
                <div class="form-group">
                  <label><?php echo $this->TXT[7]; ?></label>
                  <input type="text" name="address1" class="form-control" value="<?php echo mswSH($this->ACCOUNT['address1']); ?>">
                </div>
							  <div class="form-group">
                  <label><?php echo $this->TXT[8]; ?></label>
                  <input type="text" name="address2" class="form-control" value="<?php echo mswSH($this->ACCOUNT['address2']); ?>">
                </div>
                <div class="form-group">
                  <label><?php echo $this->TXT[9]; ?></label>
                  <input type="text" name="city" class="form-control" value="<?php echo mswSH($this->ACCOUNT['city']); ?>">
							  </div>
							  <div class="form-group">
                  <label><?php echo $this->TXT[10]; ?></label>
                  <input type="text" name="county" class="form-control" value="<?php echo mswSH($this->ACCOUNT['county']); ?>">
                </div>
                <div class="form-group">
                  <label><?php echo $this->TXT[11]; ?></label>
                  <input type="text" name="postcode" class="form-control" value="<?php echo mswSH($this->ACCOUNT['postcode']); ?>">
                </div>
							  <div class="form-group">
                  <label><?php echo $this->TXT[16]; ?></label>
                  <select name="addCountry" class="form-control">
									 <option value="">- - -</option>
								   <?php
									 if (!empty($this->COUNTRIES)) {
								     foreach ($this->COUNTRIES AS $k => $v) {
								     ?>
								     <option value="<?php echo $k; ?>"<?php echo ($this->ACCOUNT['addCountry']==$k ? ' selected="selected"' : ''); ?>><?php echo $v; ?></option>
								     <?php
								     }
									 }
								   ?>
									</select>
                </div>
              </div>
            </div>

            <h2><?php echo $this->TXT[15]; ?></h2>

            <div class="panel panel-default">
              <div class="panel-body">
                <div class="form-group">
                  <label><?php echo $this->TXT[14]; ?></label>
                  <select name="method" class="form-control">
                   <option value="">- - -</option>
                   <?php
                   if (!empty($this->RATES)) {
                     foreach ($this->RATES AS $k => $v) {
                     ?>
                     <option value="<?php echo $k; ?>"<?php echo ($this->ACCOUNT['shipping'] == $k ? ' selected="selected"' : ''); ?>><?php echo $v; ?></option>
                     <?php
                     }
                   }
                   ?>
                  </select>
                </div>
              </div>
            </div>

            <div class="act-button text-center"  style="padding-bottom:30px">
              <button type="button" class="btn btn-primary" onclick="mswAction()"><i class="fas fa-check fa-fw"></i> <?php echo $this->TXT[13]; ?></button>
					  </div>

          </div>
          <div class="col-lg-3 col-md-4">
            <?php
            // Right panel..
            include(dirname(__file__) . '/right-panel.tpl.php');
            ?>
          </div>
        </div>
      </form>
    </div>