<?php if(!defined('PARENT')) { exit; }

/* PREVIEW TEMPLATE
----------------------------------*/

?>

    <div class="container-fluid previewarea">
      <form method="post" action="#">
        <div class="row">
          <div class="col-lg-12">
            <h2><a href="<?php echo $this->URL; ?>"><?php echo mswSH($this->COLLECTION->name); ?></a></h2>
          </div>
        </div>
			  <div class="row">
          <div class="col-lg-2 coverart">
            <a href="<?php echo $this->URL; ?>"><img src="<?php echo $this->BUILD->cover($this->COLLECTION->coverart); ?>" alt="" class="img-responsive"></a>
          </div>
          <div class="col-lg-10" style="padding-bottom:20px">
            <div class="table-responsive">
              <table class="table table-striped table-hover">
                <tbody>
                  <table class="table table-striped table-hover">
                    <thead>
                      <tr>
                        <th><i class="fas fa-music fa-fw"></i></th>
                        <th><?php echo $this->TXT[0]; ?></th>
                        <th><?php echo $this->TXT[1]; ?></th>
                        <th><?php echo $this->TXT[2]; ?></th>
                        <th><?php echo $this->TXT[3]; ?></th>
                        <th class="text-right">&nbsp;</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      // html/collection-tracks.tpl
                      // html/track-play-button.tpl
                      echo $this->TRACKS;
                      ?>
                    </tbody>
                  </table>
                </tbody>
              </table>
            </div>
            <div class="text-right prevbutton">
              <span class="pull-left">&nbsp;</span>
              <button type="button" class="btn btn-default btn-sm" onclick="mswPrevTracks('<?php echo $this->COLLECTION->id; ?>_MP3')"><i class="fas fa-plus fa-fw"></i><span class="hidden-xs"> <?php echo $this->TXT[4]; ?></span></button>
            </div>
          </div>
			  </div>
      </form>
		</div>