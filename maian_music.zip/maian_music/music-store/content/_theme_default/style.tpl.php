<?php if(!defined('PARENT')) { exit; }

/* STYLE / COLLECTIONS LIST TEMPLATE
---------------------------------------*/

?>

    <div class="row">
      <div class="col-lg-9 col-md-8">

        <h1><?php echo $this->TXT[0]; ?> (<?php echo $this->COUNT; ?>)</h1>

        <?php
        // COLLECTIONS
        // html/collection.tpl
        echo $this->COLLECTIONS;

        // PAGINATION
        // html/pagination/*
        echo $this->PAGINATION;
        ?>

      </div>
      <div class="col-lg-3 col-md-4">
        <?php
        if ($this->SETTINGS->rss == 'yes') {
        ?>
        <div class="panel panel-default">
          <div class="panel-body">
            <a href="<?php echo $this->FEED_URL; ?>" onclick="window.open(this);return false" class="mm_green"><i class="fas fa-rss fa-fw"></i></a>
          </div>
        </div>
        <?php
        }
        // Right panel..
        include(dirname(__file__) . '/right-panel.tpl.php');
        ?>
      </div>
    </div>