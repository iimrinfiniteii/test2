function mswRemCart(slot) {
  switch(slot) {
    case 'all':
      var cur = jQuery('.modalbuttons button[class="btn btn-danger"]').html();
      jQuery('.modalbuttons button[class="btn btn-danger"]').html('<i class="fas fa-spinner fa-fw fa-spin"></i>');
      break;
    default:
      var cur = jQuery('.modal_tr_' + slot + ' td:last-child a i').attr('class');
      jQuery('.modal_tr_' + slot + ' td:last-child a i').attr('class', 'fas fa-spinner fa-fw fa-spin msw_red');
      break;
  }
  jQuery(document).ready(function() {
    jQuery.ajax({
      url: 'index.php',
      data: 'ajax=rem-basket&id=' + slot,
      dataType: 'json',
      cache: false,
      success: function(data) {
        if (data['resp'] == 'OK') {
          if (data['count'] > 0) {
            jQuery('.modal_tr_' + slot).slideUp();
            jQuery('span[class="basket_count"]').html(data['cart']['count']);
            jQuery('.modalcost span').html(data['total']);
          } else {
            jQuery('span[class="basket_count"]').html('0');
            jQuery('.modalbasketarea').attr('class', 'nothing').html('').after(data['nothing']);
          }
        } else {
          switch(slot) {
            case 'all':
              jQuery('.modalbuttons button[class="btn btn-danger"]').html(cur);
              break;
            default:
              jQuery('.modal_tr_' + slot + ' td:last-child a i').attr('class', cur);
              break;
          }
        }
      }
    });
  });
  return false;
}

function mswCart(id) {
  var colc = id.split('_');
  if (colc[0] != undefined && colc[1] != undefined) {
    jQuery(document).ready(function() {
      mswShowSpinner();
      jQuery.ajax({
        url: 'index.php',
        data: 'ajax=add&id=' + id,
        dataType: 'json',
        cache: false,
        success: function(data) {
          mswCloseSpinner();
          jQuery('span[class="basket_count"]').html(data['cart']['count']);
          mswAlert(data['title'], data['msg'], data['resp']);
        }
      });
    });
    return false;
  }
}

function mswBasket() {
  jQuery(document).ready(function() {
    mswShowSpinner();
    jQuery.ajax({
      url: 'index.php',
      data: 'ajax=basket&id=0',
      dataType: 'json',
      cache: false,
      success: function(data) {
        mswCloseSpinner();
        if (data['cart']['count'] > 0) {
          mswAlert(data['title'], data['msg'], 'basket');
        } else {
          mswAlert(data['title'], data['nothing'], 'basket');
        }
      }
    });
  });
  return false;
}