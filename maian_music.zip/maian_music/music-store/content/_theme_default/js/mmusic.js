function mswPanel(panl) {
  jQuery(document).ready(function() {
    jQuery.ajax({
      url: 'index.php',
      data: 'ajax=menu-panel&pnl=' + panl,
      dataType: 'json',
      cache: false,
      success: function(data) {
      }
    });
  });
  return false;
}

function mswFilters() {
  jQuery(document).ready(function() {
   jQuery.post('index.php?ajax=search-filters&id=0', {
     filter : jQuery('select[name="filters"]').val()
   },
   function(data) {
     location.reload(true);
   }, 'json');
  });
  return false;
}

function mswGetKeyCode(e) {
  var unicode = (e.keyCode ? e.keyCode : e.charCode);
  return unicode;
}

function mswCleanSearch() {
  var q = jQuery('input[name="q"]').val();
  q = q.replace('/', ' ');
  jQuery('input[name="q"]').val(q);
}

function mswWinLoc(page) {
  window.location = page;
}

function mswAlert(txt, msg, mtype) {
  if (jQuery('.bootbox')) {
    jQuery('.bootbox').remove();
  }
  if (jQuery('.modal-backdrop')) {
    jQuery('.modal-backdrop').remove();
  }
  switch(mtype) {
    case 'err':
      bootbox.dialog({
        message   : msg,
        title     : '<i class="fas fa-exclamation-triangle fa-fw"></i> ' + txt,
        className : 'msw-box-error',
        onEscape  : true,
        backdrop  : true
      });
      break;
    case 'info':
      bootbox.dialog({
        message   : msg,
        title     : '<i class="fas fa-info-circle fa-fw"></i> ' + txt,
        className : 'msw-box-ok',
        onEscape  : true,
        backdrop  : true
      });
      break;
    case 'basket':
    default:
      bootbox.dialog({
        message   : msg,
        title     : '<i class="'+ (mtype == 'basket' ? 'fas fa-shopping-basket' : 'fas fa-check') + ' fa-fw"></i> ' + txt,
        className : 'msw-box-ok',
        onEscape  : true,
        backdrop  : true
      });
      break;
  }
}

function mswShowSpinner() {
  jQuery('body').css({'opacity' : '0.7'});
  jQuery('.overlaySpinner').css({
    'left' : '50%',
    'top' : '50%',
    'position' : 'fixed',
    'margin-left' : -jQuery('.overlaySpinner').outerWidth()/2,
    'margin-top' : -jQuery('.overlaySpinner').outerHeight()/2
  });
  jQuery('div[class="overlaySpinner"]').show();
}

function mswCloseSpinner() {
  jQuery('body').css({
    'opacity': '1.0'
  });
  jQuery('div[class="overlaySpinner"]').hide();
}