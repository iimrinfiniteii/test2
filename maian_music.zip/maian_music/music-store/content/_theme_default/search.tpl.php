<?php if(!defined('PARENT')) { exit; }

/* SEARCH TEMPLATE
----------------------------------*/

?>

    <div class="row">
      <div class="col-lg-9 col-md-8">

        <h1><?php echo $this->TXT[0]; ?></h1>

        <?php
        // COLLECTIONS
        // html/collection.tpl
        echo $this->SEARCH;

        // PAGINATION
        // html/pagination/*
        echo $this->PAGINATION;
        ?>

      </div>
      <div class="col-lg-3 col-md-4">
        <?php
        // Right panel..
        include(dirname(__file__) . '/right-panel.tpl.php');
        ?>
      </div>
    </div>