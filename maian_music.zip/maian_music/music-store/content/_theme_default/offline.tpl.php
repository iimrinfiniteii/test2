<?php if(!defined('PARENT')) { exit; }

/* OFFLINE TEMPLATE
----------------------------------*/

?>

    <div class="row">
      <div class="col-lg-12">

        <h1 class="msw_red"><i class="fas fa-exclamation-triangle fa-fw"></i> <?php echo $this->TXT[0]; ?></h1>

        <div class="panel panel-default">
          <div class="panel-body">
            <?php echo $this->TXT[1]; ?>
          </div>
        </div>

      </div>
    </div>