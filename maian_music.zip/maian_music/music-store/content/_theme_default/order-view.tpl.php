<?php if(!defined('PARENT')) { exit; }

/* ORDER VIEW TEMPLATE
----------------------------------*/

?>

    <div class="row">
      <div class="col-lg-9 col-md-8">

        <h1><?php echo $this->TXT[0]; ?> #<?php echo $this->INVOICE_NO; ?></h1>

        <div class="panel panel-default">
          <div class="panel-body">
            <?php echo $this->TXT[18][3]; ?>
          </div>
        </div>

        <?php
        // DOWNLOADS..
        if ($this->ORDER_DETAIL) {
        ?>
        <h2><?php echo $this->TXT[5]; ?></h2>

        <div class="panel panel-default orders">
          <div class="panel-body">
            <div class="table-responsive">
              <table class="table table-striped table-hover">
              <thead>
                <tr>
                  <th>&nbsp;</td>
                  <th><?php echo $this->TXT[2]; ?></th>
                  <th><?php echo $this->TXT[7]; ?></th>
                  <th class="text-right"><?php echo $this->TXT[4]; ?></th>
                </tr>
              </thead>
              <tbody>
                <?php
                // html/order-detail-item-download.tpl
                echo $this->ORDER_DETAIL;
                ?>
              </tbody>
              </table>
            </div>
          </div>
        </div>
        <?php
        }

        // TANGIBLE..
        if ($this->ORDER_DETAIL2) {
        ?>
        <h2><?php echo $this->TXT[6]; ?></h2>

        <div class="panel panel-default orders">
          <div class="panel-body">
            <div class="table-responsive">
              <table class="table table-striped table-hover">
              <thead>
                <tr>
                  <th>&nbsp;</td>
                  <th><?php echo $this->TXT[2]; ?></th>
                  <th class="text-right"><?php echo $this->TXT[7]; ?></th>
                </tr>
              </thead>
              <tbody>
                <?php
                // LATEST ORDERS
                // html/order-detail-item-shipped.tpl
                echo $this->ORDER_DETAIL2;
                ?>
              </tbody>
              </table>
            </div>
          </div>
        </div>

        <?php
        if ($this->ORDER->shippingAddr) {
        ?>
        <h2><?php echo $this->TXT[14]; ?></h2>

        <div class="panel panel-default">
          <div class="panel-body">
            <?php echo $this->ORDER->accountName; ?>
            <br>
            <?php echo mswNL2BR(mswSH($this->ORDER->shippingAddr)); ?>
          </div>
        </div>
        <?php
        }
        }
        ?>

        <div style="padding-bottom:30px" class="text-right">
          <?php
          // We don`t show this for guest checkouts..
          if ($this->GUEST == 'no') {
          ?>
          <span class="pull-left">
            <button type="button" class="btn btn-primary" onclick="mswWinLoc('<?php echo $this->URL[0]; ?>')"><i class="fas fa-undo fa-fw"></i><span class="hidden-xs">  <?php echo $this->TXT[1]; ?></span></button>
				  </span>
          <?php
          }
          ?>
          &nbsp;
        </div>

      </div>
      <div class="col-lg-3 col-md-4">
        <div class="panel panel-default">
          <div class="panel-heading">
            <i class="fas fa-info-circle fa-fw"></i> <?php echo $this->TXT[18][4]; ?>
          </div>
          <div class="panel-body">
            <?php
            // For guest checkout show name and email..
            if ($this->GUEST == 'yes') {
            ?>
            <b><?php echo $this->INFO['guest_name']; ?></b><br>
            <?php echo $this->INFO['guest_email']; ?><hr>
            <?php
            }
            echo $this->TXT[9]; ?>:<br><b><?php echo $this->INFO['date']; ?></b>
            <?php
            if ($this->INFO['method']) {
              echo '<br><br>' . $this->TXT[8]; ?>:<br><b><?php echo $this->INFO['method']; ?></b>
            <?php
            }
            ?>
            <hr>
            <div class="table-responsive">
              <table class="table table-striped table-hover">
              <tbody>
                <?php
                // Digital Goods..
                if ($this->INFO['sub-raw'][0] > 0) {
                  ?>
                  <tr>
                    <td><?php echo $this->TXT[18][6]; ?></td>
                    <td class="text-right highlight"><?php echo $this->INFO['dig-sub']; ?></td>
                  </tr>
                  <?php
                  // Coupon..
                  if ($this->INFO['sub-raw'][6]['digital'] > 0 ) {
                  ?>
                  <tr>
                    <td><?php echo $this->TXT[19][21]; ?></td>
                    <td class="text-right highlight"><?php echo $this->INFO['coupon-discounts']['digital']; ?></td>
                  </tr>
                  <?php
                  }
                  // Digital Goods Tax..
                  if ($this->INFO['sub-raw'][4] > 0 ) {
                  ?>
                  <tr>
                    <td><?php echo str_replace('{tax}', $this->INFO['taxrate2'], $this->TXT[18][8]); ?></td>
                    <td class="text-right highlight"><?php echo $this->INFO['tax2']; ?></td>
                  </tr>
                  <?php
                  }
                }
                // Tangible Goods..
                if ($this->INFO['sub-raw'][1] > 0) {
                  ?>
                  <tr>
                    <td><?php echo $this->TXT[18][7]; ?></td>
                    <td class="text-right highlight"><?php echo $this->INFO['tang-sub']; ?></td>
                  </tr>
                  <?php
                  // Coupon..
                  if ($this->INFO['sub-raw'][6]['tangible'] > 0 ) {
                  ?>
                  <tr>
                    <td><?php echo $this->TXT[19][20]; ?></td>
                    <td class="text-right highlight"><?php echo $this->INFO['coupon-discounts']['tangible']; ?></td>
                  </tr>
                  <?php
                  }
                  // Tangible Shipping..
                  if ($this->INFO['sub-raw'][2] > 0) {
                  ?>
                  <tr>
                    <td><?php echo $this->TXT[11]; ?></td>
                    <td class="text-right highlight"><?php echo $this->INFO['shipping']; ?></td>
                  </tr>
                  <?php
                  }
                  // Tangible Goods Tax..
                  if ($this->INFO['sub-raw'][3] > 0 ) {
                  ?>
                  <tr>
                    <td><?php echo str_replace('{tax}', $this->INFO['taxrate'], $this->TXT[18][8]); ?></td>
                    <td class="text-right highlight"><?php echo $this->INFO['tax']; ?></td>
                  </tr>
                  <?php
                  }
                }
                ?>
              </tbody>
              </table>
            </div>
          </div>
          <div class="panel-footer text-right ordertotal">
            <?php echo $this->TXT[13]; ?>: <span class="highlight"><b><?php echo $this->INFO['total']; ?></b></span>
          </div>
        </div>
        <div class="panel panel-default">
          <div class="panel-body">
            <?php
            // Company Info..
            echo $this->COMPANY;
            ?>
          </div>
        </div>
        <div class="panel panel-default">
          <div class="panel-body text-center paidwiththanks">
            <i class="fas fa-check-circle fa-fw msw_green fa-2x"></i><span><?php echo $this->TXT[15]; ?></span>
          </div>
        </div>
      </div>
    </div>
