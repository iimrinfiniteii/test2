<?php if(!defined('PARENT')) { exit; }

/* LOAD BOXES
-----------------------------------------------*/

?>
<div class="right-panel-boxes">
<?php
if (!empty($this->BOXES)) {
  for ($i=0; $i<count($this->BOXES); $i++) {
    switch($this->BOXES[$i]['type']) {
      // STANDARD TEMPLATE
      // html/box.htm
      case 'standard':
        echo $this->BOXES[$i]['box'];
        break;
      // CUSTOM TEMPLATE
      // custom-templates/box_*.tpl.php
      case 'custom':
        if (file_exists(dirname(__file__) . '/custom-templates/' . $this->BOXES[$i]['box'])) {
          include(dirname(__file__) . '/custom-templates/' . $this->BOXES[$i]['box']);
        }
        break;
    }
  }
}

?>
</div>