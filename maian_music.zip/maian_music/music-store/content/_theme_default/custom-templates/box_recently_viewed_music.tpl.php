<?php if(!defined('PARENT') || empty($this->BOXES)) { exit; }

/* CUSTOM TEMPLATE - RECENTLY VIEWED COLLECTIONS
   Only shows if data is present

   You can use any element from the box array:

   print_r($this->BOXES[$i])

   Or manually add your own code.
-----------------------------------------------*/

if (isset($this->RECENTLY_VIEWED) && $this->RECENTLY_VIEWED) {
?>

        <div class="panel panel-default recentboxarea">
          <div class="panel-heading">
            <i class="<?php echo $this->BOXES[$i]['icon']; ?> fa-fw"></i> <?php echo $this->BOXES[$i]['title']; ?>
          </div>
          <div class="panel-body">
            <?php
            // html/collection-recently-viewed-link.tpl
            echo $this->RECENTLY_VIEWED;
            ?>
          </div>
        </div>
<?php
}
?>