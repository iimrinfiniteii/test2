This directory is for the 'Pages' and 'Boxes' sections in your admin control panel.

Create files here with a '.tpl.php' extension.

-------------
PAGES
-------------

- Specify file as the load file when adding/editing a new page. Pages must NOT be prefixed with
  a 'box_' prefix, these are for boxes only. See below.

  This will override the system default file and enable you to add in your own PHP for different pages.

  You can set a page as the landing page instead of the default main page.

-------------
BOXES
-------------

- Boxes must be prefixed 'box_'.
  See example file: box_1.tpl.php

  The following are used by the default system and should not be removed:

  box_popular_music.tpl.php
  box_recently_viewed_music.tpl.php

  (If you do accidentally delete them, replace from the download zip on the Maian Music website)