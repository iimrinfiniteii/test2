<?php if(!defined('PARENT')) { exit; }

/* BASKET/CHECKOUT TEMPLATE
----------------------------------*/

?>

    <div class="row mainarea basketarea">
      <form method="post" action="<?php echo $this->URL[0]; ?>" id="bform">
        <div class="col-lg-9 col-md-8 basketdata">

          <?php
          if ($this->CART_COUNT > 0) {
          ?>
          <h1>
            <span class="pull-right">
              <a href="#" onclick="mswRemBsk('all');return false"><i class="fas fa-times-circle fa-fw msw_red"></i></a>
            </span>
            <?php echo $this->TXT[0]; ?>
          </h1>

          <div class="basket_accordion">
            <?php
            // Panel 1 - Basket Items
            ?>
            <div class="basket_op pn1">
              <div class="panel panel-default">
                <div class="panel-heading">
                  <i class="fas fa-music fa-fw"></i> <?php echo $this->TXT[4]; ?>
                </div>
                <div class="panel-body items">
                  <div class="table-responsive">
                    <table class="table table-striped table-hover">
                      <tbody>
                        <?php
                        // html/basket.tpl
                        // html/basket-item.tpl
                        echo $this->BASKET_ITEMS;
                        ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
              <div class="text-right prevnextbtns">
                <button type="button" class="btn btn-primary" onclick="mswBkPnl('1','2')"><i class="fas fa-chevron-right fa-fw"></i> <?php echo $this->TXT[30][4]; ?></button>
              </div>
            </div>

            <?php
            // Panel 2 - Account
            ?>
            <div class="basket_op pn2">
              <div class="panel panel-default">
                <div class="panel-heading">
                  <i class="fas fa-user fa-fw"></i> <?php echo $this->TXT[7]; ?>
                </div>
                <div class="panel-body">
                  <div class="account">
                    <p><?php echo $this->TXT[31][15]; ?></p>
                    <div class="form-group">
                      <label><?php echo $this->TXT[31][18]; ?></label>
                      <input type="text" name="em" class="form-control" value="<?php echo (isset($this->ACCOUNT['email']) ? mswSH($this->ACCOUNT['email']) : ''); ?>">
                    </div>
                    <div class="form-group">
                      <label><?php echo $this->TXT[31][19]; ?></label>
                      <input type="password" name="ps" class="form-control" value="">
                    </div>
                    <p><?php echo $this->TXT[30][6]; ?></p>
                    <div class="form-group">
                      <label><?php echo $this->TXT[31][20]; ?></label>
                      <input type="text" name="nm" class="form-control" value="">
                    </div>
                    <div class="form-group">
                      <label><?php echo $this->TXT[31][29]; ?></label>
                      <select name="rescountry" class="form-control">
                        <option value="0">- - - - - - - -</option>
                        <?php
                        if (!empty($this->COUNTRIES)) {
                          foreach ($this->COUNTRIES AS $k => $v) {
                          ?>
                          <option value="<?php echo $k; ?>"><?php echo $v; ?></option>
                          <?php
                          }
                        }
                        ?>
                      </select>
                    </div>
                  </div>
                  <hr class="hr_acc">
                  <div class="form-group">
                    <div class="checkbox">
                      <label><input type="checkbox" name="guest" value="yes" onclick="mswGuest(this.checked)"> <?php echo $this->TXT[30][7]; ?></label>
                    </div>
                  </div>
                  <div class="guest" style="display:none">
                    <hr>
                    <p><?php echo $this->TXT[30][8]; ?></p>
                    <div class="form-group">
                      <label><?php echo $this->TXT[31][20]; ?></label>
                      <input type="text" name="g_nm" class="form-control" value="">
                    </div>
                    <div class="form-group">
                      <label><?php echo $this->TXT[31][18]; ?></label>
                      <input type="text" name="g_em" class="form-control" value="">
                    </div>
                    <div class="form-group">
                      <label><?php echo $this->TXT[31][29]; ?></label>
                      <select name="g_rescountry" class="form-control">
                        <option value="0">- - - - - - - -</option>
                        <?php
                        if (!empty($this->COUNTRIES)) {
                          foreach ($this->COUNTRIES AS $k => $v) {
                          ?>
                          <option value="<?php echo $k; ?>"><?php echo $v; ?></option>
                          <?php
                          }
                        }
                        ?>
                      </select>
                    </div>
                  </div>
                </div>
              </div>
              <div class="text-right prevnextbtns">
                <span class="pull-left">
                  <button type="button" class="btn btn-primary" onclick="mswBkPnl('1', 'back')"><i class="fas fa-chevron-left fa-fw"></i><span class="hidden-xs"> <?php echo $this->TXT[30][5]; ?></span></button>
                </span>
                <button type="button" class="btn btn-primary" onclick="mswBkPnl('2','<?php echo ($this->IS_SHIPPING == 'yes' ? '3' : '4'); ?>')"><span class="hidden-xs"><?php echo $this->TXT[30][4]; ?> </span><i class="fas fa-chevron-right fa-fw"></i></button>
              </div>
            </div>

            <?php
            // Panel 3 - Shipping, if applicable..
            ?>
            <div class="basket_op pn3">
              <div class="panel panel-default">
                <div class="panel-heading">
                  <i class="fas fa-truck fa-fw"></i> <?php echo $this->TXT[9]; ?>
                </div>
                <div class="panel-body">
                  <div class="form-group">
                    <label><?php echo $this->TXT[17]; ?></label>
                    <select name="method" class="form-control">
                    <?php
                    if (!empty($this->RATES)) {
                    foreach ($this->RATES AS $k => $v) {
                    ?>
                    <option value="<?php echo $k; ?>"<?php echo ($this->SHIP['method'] == $k ? ' selected="selected"' : ''); ?>><?php echo $v; ?></option>
                    <?php
                    }
                    }
                    ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label><?php echo $this->TXT[11]; ?></label>
                    <input type="text" name="address1" class="form-control" value="<?php echo $this->SHIP['address1']; ?>">
                  </div>
                  <div class="form-group">
                    <label><?php echo $this->TXT[12]; ?></label>
                    <input type="text" name="address2" class="form-control" value="<?php echo $this->SHIP['address2']; ?>">
                  </div>
                  <div class="form-group">
                    <label><?php echo $this->TXT[13]; ?></label>
                    <input type="text" name="city" class="form-control" value="<?php echo $this->SHIP['city']; ?>">
                  </div>
                  <div class="form-group">
                    <label><?php echo $this->TXT[14]; ?></label>
                    <input type="text" name="county" class="form-control" value="<?php echo $this->SHIP['county']; ?>">
                  </div>
                  <div class="form-group">
                    <label><?php echo $this->TXT[15]; ?></label>
                    <input type="text" name="postcode" class="form-control" value="<?php echo $this->SHIP['postcode']; ?>">
                  </div>
                  <div class="form-group">
                    <label><?php echo $this->TXT[16]; ?></label>
                    <select name="country" class="form-control">
                    <option value="0">- - - - - - - -</option>
                    <?php
                    if (!empty($this->COUNTRIES)) {
                      foreach ($this->COUNTRIES AS $k => $v) {
                      ?>
                      <option value="<?php echo $k; ?>"<?php echo ($this->SHIP['country'] == $k ? ' selected="selected"' : ''); ?>><?php echo $v; ?></option>
                      <?php
                      }
                    }
                    ?>
                    </select>
                  </div>
                </div>
              </div>
              <div class="text-right prevnextbtns">
                <span class="pull-left">
                  <button type="button" class="btn btn-primary" onclick="mswBkPnl('2', 'back')"><i class="fas fa-chevron-left fa-fw"></i><span class="hidden-xs"> <?php echo $this->TXT[30][5]; ?></span></button>
                </span>
                <button type="button" class="btn btn-primary" onclick="mswBkPnl('3','4')"><span class="hidden-xs"><?php echo $this->TXT[30][4]; ?> </span><i class="fas fa-chevron-right fa-fw"></i></button>
              </div>
            </div>

            <?php
            // Panel 4 - Gift coupon..
            ?>
            <div class="basket_op pn4">
              <div class="panel panel-default">
                <div class="panel-heading">
                  <i class="fas fa-gift fa-fw"></i> <?php echo $this->TXT[25]; ?>
                </div>
                <div class="panel-body">
                  <div class="form-group">
                    <label><?php echo $this->TXT[26]; ?></label>
                    <input type="text" name="coupon" class="form-control coupon_code" value="">
                    <span class="help-block"><?php echo $this->TXT[30][12]; ?></span>
                  </div>
                </div>
              </div>
              <div class="text-right prevnextbtns">
                <span class="pull-left">
                  <button type="button" class="btn btn-primary" onclick="mswBkPnl('<?php echo ($this->IS_SHIPPING == 'yes' ? '3' : '2'); ?>', 'back')"><i class="fas fa-chevron-left fa-fw"></i><span class="hidden-xs"> <?php echo $this->TXT[30][5]; ?></span></button>
                </span>
                <button type="button" class="btn btn-primary" onclick="mswBkPnl('4','5')"><span class="hidden-xs"><?php echo $this->TXT[30][4]; ?> </span><i class="fas fa-chevron-right fa-fw"></i></button>
              </div>
            </div>

            <?php
            // Panel 5 - Payment gateway..
            ?>
            <div class="basket_op pn5">
              <div class="panel panel-default">
                <div class="panel-heading">
                  <i class="far fa-credit-card"></i> <?php echo $this->TXT[10]; ?>
                </div>
                <div class="panel-body">
                  <div class="row">
                    <div class="col-lg-4">
                      <div class="form-group">
                        <label><?php echo $this->TXT[19]; ?></label>
                        <select name="payment" class="form-control" onchange="mswPayRld(this.value)">
                          <option value="0">- - - - - - -</option>
                          <?php
                          $pimg = array();
                          $def = '';
                          if (!empty($this->METHODS)) {
                            for ($i = 0; $i < count($this->METHODS); $i++) {
                            $pimg[] = $this->METHODS[$i];
                            // Display default if set..overrides above..
                            if ($this->METHODS[$i]['def'] == 'yes') {
                              $def = $this->METHODS[$i]['img'];
                            }
                            ?>
                            <option value="<?php echo $this->METHODS[$i]['id']; ?>"<?php echo ($this->METHODS[$i]['def'] == 'yes' ? ' selected="selected"' : ''); ?>><?php echo $this->METHODS[$i]['name']; ?></option>
                            <?php
                            }
                            // If no default, set first for display..
                            if ($def == '' && isset($pimg[0]['img'])) {
                              $def = $pimg[0]['img'];
                            }
                          }
                          ?>
                        </select>
                        <?php
                        if ($def) {
                        ?>
                        <div class="payimg hidden-xs">
                          <hr>
                          <img src="<?php echo $def; ?>" alt="">
                        </div>
                        <?php
                        }
                        // Store gateway images in hidden fields. We can use this to refresh image to prevent db lookup..
                        if (!empty($pimg)) {
                          foreach ($pimg AS $im) {
                          ?>
                          <input type="hidden" name="gw<?php echo mswSH($im['id']); ?>" value="<?php echo mswSH($im['img']); ?>">
                          <?php
                          }
                        }
                        ?>
                      </div>
                    </div>
                    <div class="col-lg-8">
                      <div class="table-responsive paytotalsarea">
                        <table class="table table-striped table-hover">
                        <tbody>
                          <tr class="t_sub">
                            <td class="text-right"><?php echo $this->TXT[20]; ?></td>
                            <td class="text-right"><?php echo $this->CHARGES['sub']; ?></td>
                          </tr>
                          <?php
                          // Shipping and tax will be hidden if they don`t apply
                          ?>
                          <tr class="t_shipping">
                           <td class="text-right"><?php echo $this->TXT[21]; ?></td>
                           <td class="text-right"><?php echo $this->CHARGES['ship']; ?></td>
                          </tr>
                          <tr class="t_tax">
                           <td class="text-right"><?php echo $this->TXT[22]; ?></td>
                           <td class="text-right"><?php echo $this->CHARGES['tax']; ?></td>
                          </tr>
                          <tr class="t_total">
                           <td class="text-right total"><?php echo $this->TXT[23]; ?></td>
                           <td class="text-right total highlight"><?php echo $this->CHARGES['total']; ?></td>
                          </tr>
                        </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <?php
              if ($def) {
              ?>
              <div class="panel panel-default">
                <div class="panel-body">
                  <div class="form-group">
                    <label><?php echo $this->TXT[24]; ?></label>
                    <textarea name="notes" cols="2" rows="10" class="form-control"></textarea>
                  </div>
                </div>
              </div>
              <?php
              // Terms and conditions if enabled
              // Admin > Settings > Other > Terms and Conditions
              if ($this->SETTINGS->termsenable == 'yes') {
              ?>
              <div class="panel panel-default tosarea">
                <div class="panel-body text-right">
                  <div class="form-group">
                    <div class="checkbox">
                      <label><input type="checkbox" name="terms" value="accept"> <a href="#" onclick="mswTOS();return false"><?php echo $this->TXT[27]; ?></a></label>
                    </div>
                  </div>
                </div>
              </div>
              <?php
              }
              ?>
              <div class="text-right prevnextbtns">
                <span class="pull-left">
                  <button type="button" class="btn btn-primary" onclick="mswBkPnl('4', 'back')"><i class="fas fa-chevron-left fa-fw"></i><span class="hidden-xs"> <?php echo $this->TXT[30][5]; ?></span></button>
                </span>
                <button type="button" class="btn btn-success" onclick="mswBkPnl('checkout')"><i class="fas fa-check fa-fw"></i><span class="hidden-xs"> <?php echo $this->TXT[30][2]; ?></span></button>
              </div>
              <?php
              } else {
              ?>
              <div class="alert alert-danger">
                <i class="fas fa-exclamation-triangle fa-fw"></i> <?php echo $this->TXT[30][9]; ?>
              </div>
              <?php
              }
              ?>
            </div>

          </div>
          <?php
          } else {
          ?>
          <h1><?php echo $this->TXT[0]; ?></h1>

          <div class="panel panel-default">
            <div class="panel-body text-center">
              <i class="fas fa-exclamation-circle fa-4x fa-fw"></i><br><br>
              <?php echo $this->TXT[6]; ?>
            </div>
          </div>
          <?php
          }
          ?>

        </div>
        <div class="col-lg-3 col-md-4">
          <?php
          // Right panel..
          include(dirname(__file__) . '/right-panel.tpl.php');
          ?>
        </div>
        <input type="hidden" name="gateway" value="no">
        <input type="hidden" name="is_shipping" value="<?php echo $this->IS_SHIPPING; ?>">
        <input type="hidden" name="account" value="<?php echo LOGGED_IN; ?>">
      </form>
    </div>