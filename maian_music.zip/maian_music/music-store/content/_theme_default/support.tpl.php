<?php if(!defined('PARENT')) { exit; }

/* SUPPORT TEMPLATE
----------------------------------*/

?>

    <div class="formfield">
      <form method="post" action="#">
        <div class="row mainarea supportarea">
          <div class="col-lg-9 col-md-8">

            <h1><?php echo $this->TXT[0][10]; ?></h1>

            <div class="panel panel-default">
              <div class="panel-body">
                <div class="form-group">
                  <label><?php echo $this->TXT[0][11]; ?></label>
                  <input type="text" name="nm" class="form-control" value="">
							  </div>
                <div class="form-group">
							    <label><?php echo $this->TXT[0][12]; ?></label>
                  <input type="text" name="em" class="form-control" value="">
                </div>
                <div class="form-group">
							    <label><?php echo $this->TXT[0][13]; ?></label>
                  <input type="text" name="sb" class="form-control" value="">
                </div>
                <div class="form-group">
							    <label><?php echo $this->TXT[0][14]; ?></label>
                  <textarea name="cm" class="form-control" rows="5" cols="20"></textarea>
                </div>
                <?php
                // Simple anti spam (if enabled)..
                // Do not remove the hidden field..
                if ($this->ANTI_SPAM) {
                ?>
                <div class="form-group spamarea">
							    <label><?php echo $this->TXT[0][17]; ?>: <span><?php echo $this->ANTI_SPAM; ?></span></label>
                  <div class="form-group input-group">
                    <span class="input-group-addon"><a href="#" onclick="mswSpmRld();return false"><i class="fas fa-sync fa-fw"></i></a></span>
                    <input type="text" name="as" class="form-control" value="">
                  </div>
                  <input type="hidden" name="message" value="">
                </div>
                <?php
                }
                ?>
              </div>
            </div>

            <div class="act-button text-center">
              <button type="button" class="btn btn-primary" onclick="mswAction()"><i class="fas fa-check fa-fw"></i> <?php echo $this->TXT[0][15]; ?></button>
					  </div>

          </div>
          <div class="col-lg-3 col-md-4">
            <?php
            // Right panel..
            include(dirname(__file__) . '/right-panel.tpl.php');
            ?>
          </div>
        </div>
      </form>
    </div>