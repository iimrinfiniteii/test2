<?php if(!defined('PARENT')) { exit; }

/* PAGE TEMPLATE
----------------------------------*/

?>

    <div class="row mainarea">
      <div class="col-lg-9 col-md-8">

        <h1><?php echo $this->TXT[0]; ?></h1>

        <div class="panel panel-default">
          <div class="panel-body">
            <?php
				    echo mswNL2BR($this->PAGE->info);
				    ?>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-md-4">
        <?php
        // Right panel..
        include(dirname(__file__) . '/right-panel.tpl.php');
        ?>
      </div>
    </div>