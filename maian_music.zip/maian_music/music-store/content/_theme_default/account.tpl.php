<?php if(!defined('PARENT')) { exit; }

/* DASHBOARD TEMPLATE
----------------------------------*/

?>

    <div class="row mainarea">
      <div class="col-lg-9 col-md-8">

        <h1><?php echo $this->TXT[0]; ?> (<?php echo mswSH($this->ACCOUNT['name']); ?>)</h1>

        <?php
        // If account hasn`t been verified, we show this message until it is.
        if ($this->ACCOUNT['enabled'] == 'no') {
        ?>
        <div class="alert alert-danger alert-dismissable">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fas fa-times fa-fw"></i></button>
          <?php
          echo $this->TXT[8];
          ?>
        </div>
        <?php
        }
        ?>

        <div class="panel panel-default">
          <div class="panel-body">
            <?php echo $this->TXT[2]; ?>
          </div>
        </div>

        <h2><?php echo $this->TXT[1]; ?></h2>

        <?php
        // LATEST ORDERS
        if ($this->ORDERS) {
        ?>
        <div class="panel panel-default orders">
          <div class="panel-body">
            <div class="table-responsive">
              <table class="table table-striped table-hover">
              <thead>
                <tr>
                  <th><?php echo $this->TXT[4]; ?></th>
                  <th><?php echo $this->TXT[5]; ?></th>
                  <th><?php echo $this->TXT[6]; ?></th>
                  <th class="text-right"><?php echo $this->TXT[7]; ?></th>
                </tr>
              </thead>
              <tbody>
                <?php
                // html/order-item.tpl
                echo $this->ORDERS;
                ?>
              </tbody>
              </table>
            </div>
          </div>
          <div class="panel-footer text-center">
            <a href="<?php echo $this->URL[0]; ?>"><i class="fas fa-search fa-fw"></i> <?php echo $this->TXT[3]; ?></a>
          </div>
        </div>
        <?php
        }
        ?>

      </div>
      <div class="col-lg-3 col-md-4">
        <?php
        // Right panel..
        include(dirname(__file__) . '/right-panel.tpl.php');
        ?>
      </div>
    </div>