<?php if(!defined('PARENT')) { exit; }

/* LOGIN TEMPLATE
----------------------------------*/

?>

    <div class="formfield">
      <form method="post" action="#">
        <div class="row mainarea">
          <div class="col-lg-9 col-md-8">

            <h1><?php echo $this->TXT[0]; ?></h1>

            <div class="panel panel-default">
              <div class="panel-body">

                <div class="form-group">
                  <label><?php echo $this->TXT[2]; ?></label>
                  <input type="text" name="e" class="form-control" value="" onkeypress="if(mswGetKeyCode(event)==13){mswLogin('enter');return false}">
                </div>

                <div class="form-group passarea">
                  <label><?php echo $this->TXT[3]; ?></label>
                  <input type="password" name="p" class="form-control" value="" onkeypress="if(mswGetKeyCode(event)==13){mswLogin('enter');return false}" autocomplete="off">
                </div>

              </div>
              <div class="panel-footer">
                <button type="button" class="btn btn-primary" onclick="mswLogin('forgot')" id="bforgot" style="display:none"><i class="far fa-envelope fa-fw"></i> <?php echo $this->TXT[6]; ?></button>
                <button type="button" class="btn btn-link" onclick="mswLogin('forgot-cancel')" id="bforgot2" style="display:none"><i class="fas fa-undo fa-fw"></i></button>
                <button type="button" class="btn btn-primary" onclick="mswLogin('enter')" id="benter"><i class="fas fa-lock fa-fw"></i> <?php echo $this->TXT[4]; ?></button>
                <button type="button" class="btn btn-link" onclick="mswLogin('forgot-load')" id="benter2"><?php echo $this->TXT[5]; ?></button>
              </div>
            </div>

          </div>
          <div class="col-lg-3 col-md-4">
            <div class="panel panel-default">
              <div class="panel-body">
                 <a rel="nofollow" href="<?php echo $this->CREATE_URL; ?>"><i class="fas fa-pencil-alt fa-fw"></i> <?php echo $this->TXT[1]; ?></a>
              </div>
            </div>
            <?php
            // Right panel..
            include(dirname(__file__) . '/right-panel.tpl.php');
            ?>
          </div>
        </div>
      </div>
    </div>