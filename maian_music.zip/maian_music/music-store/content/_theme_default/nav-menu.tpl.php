<?php if(!defined('PARENT')) { exit; } ?>

    <nav class="pushy pushy-left">
      <div class="pushy-content">

        <?php

        /* SEARCH BOX
        -------------------------------------------------*/

        ?>
        <div class="navsearchwrap">
          <form method="get" action="<?php echo BASE_HREF; ?>" id="seform">
          <div class="form-group">
            <div class="form-group input-group">
              <input type="text" onkeyup="mswCleanSearch()" class="form-control" name="q" value="<?php echo $this->KEYS; ?>" placeholder="<?php echo mswSH($this->TXT[2][5]); ?>" onkeypress="if(mswGetKeyCode(event)==13){jQuery('#seform').submit()}">
              <span class="input-group-addon"><i class="fas fa-search fa-fw mswcursor_p" onclick="jQuery('#seform').submit()"></i></span>
            </div>
          </div>
          </form>
        </div>

        <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
          <?php

          /* ACCOUNT MENU
          -------------------------------------------------------*/

          if (LOGGED_IN == 'yes') {
          ?>
          <div class="panel panel-default">
            <div class="panel-heading" role="tab" id="heading_acc">
              <h4 class="panel-title">
                <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse_acc" aria-expanded="<?php echo ($this->DEF_PANEL == '_acc' ? 'true' : 'false'); ?>" onclick="mswPanel('_acc')" aria-controls="collapse_acc" title="">
                  <i class="fas fa-user fa-fw"></i> <?php echo $this->TXT[1][0]; ?>
                </a>
              </h4>
            </div>
            <div id="collapse_acc" class="panel-collapse collapse<?php echo ($this->DEF_PANEL == '_acc' ? ' in' : ''); ?>" role="tabpanel" aria-labelledby="heading_acc">
              <div class="panel-body">
                <div><a href="<?php echo $this->URL[1]; ?>" rel="nofollow"><i class="fas fa-angle-right"></i> <?php echo $this->TXT[1][16]; ?></a></div>
                <div><a href="<?php echo $this->URL[6]; ?>" rel="nofollow"><i class="fas fa-angle-right"></i> <?php echo $this->TXT[1][4]; ?></a></div>
                <div><a href="<?php echo $this->URL[7]; ?>" rel="nofollow"><i class="fas fa-angle-right"></i> <?php echo $this->TXT[1][5]; ?></a></div>
                <div><a href="<?php echo $this->URL[8]; ?>" rel="nofollow"><i class="fas fa-angle-right"></i> <?php echo $this->TXT[1][3]; ?></a></div>
              </div>
            </div>
          </div>
          <?php
          }

          /* MUSIC STYLES
          -------------------------------------------------------*/

          ?>
          <div class="panel panel-default">
            <div class="panel-heading" role="tab" id="heading_styles">
              <h4 class="panel-title">
                <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse_styles" aria-expanded="<?php echo ($this->DEF_PANEL == '_styles' ? 'true' : 'false'); ?>" onclick="mswPanel('_styles')" aria-controls="collapse_styles" title="">
                  <i class="fas fa-headphones fa-fw"></i> <?php echo $this->TXT[2][9]; ?>
                </a>
              </h4>
            </div>
            <div id="collapse_styles" class="panel-collapse collapse<?php echo ($this->DEF_PANEL == '_styles' ? ' in' : ''); ?>" role="tabpanel" aria-labelledby="heading_styles">
              <div class="panel-body stylesarea">
                <?php
                if (!empty($this->MENU_STYLES)) {
                  foreach ($this->MENU_STYLES AS $sk => $sv) {
                  // Is this style linked directly to a collection?
                  if ($sv['colurl']) {
                    $sv['url'] = $sv['colurl'];
                  } else {
                    // Are we showing counts?
                    if ($sv['linked'] == 'yes') {
                      $showCount = DISPLAY_STYLE_COUNTS_LINKED;
                    } else {
                      $showCount = DISPLAY_STYLE_COUNTS;
                    }
                  }
                  ?>
                  <div><a href="<?php echo $sv['url']; ?>" title="<?php echo mswSH($sv['name']); ?>"><i class="fas fa-angle-right"></i> <?php echo mswSH($sv['name']) . ($showCount ? ' <span>(' . mswNFM($sv['count']) . ')</span>' : ''); ?></a></div>
                  <?php
                  }
                }
                ?>
              </div>
            </div>
          </div>
          <?php

          /* OTHER PAGES
           -------------------------------------------------------*/

          if (!empty($this->OTHER)) {
          ?>
          <div class="panel panel-default">
            <div class="panel-heading" role="tab" id="heading_pages">
              <h4 class="panel-title">
                <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse_pages" aria-expanded="<?php echo ($this->DEF_PANEL == '_pages' ? 'true' : 'false'); ?>" onclick="mswPanel('_pages')" aria-controls="collapse_pages" title="">
                  <i class="far fa-file-alt fa-fw"></i> <?php echo $this->TXT[2][10]; ?>
                </a>
              </h4>
            </div>
            <div id="collapse_pages" class="panel-collapse collapse<?php echo ($this->DEF_PANEL == '_pages' ? ' in' : ''); ?>" role="tabpanel" aria-labelledby="heading_pages">
              <div class="panel-body stylesarea">
                <?php
                foreach ($this->OTHER AS $ok => $ov) {
                ?>
                <div><a href="<?php echo $ov['url']; ?>" title="<?php echo mswSH($ov['name']); ?>"><i class="fas fa-angle-right"></i> <?php echo mswSH($ov['name']); ?></a></div>
                <?php
                }
                ?>
              </div>
            </div>
          </div>
          <?php
          }
          ?>

        </div>
      </div>
    </nav>

    <div class="site-overlay"></div>