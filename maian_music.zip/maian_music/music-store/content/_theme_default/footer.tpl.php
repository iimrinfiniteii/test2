<?php if (!defined('PARENT')) { exit; } ?>
    </div>

    <footer class="push">
      <?php
      // Social Buttons..
			if ($this->SOCIAL_BUTTONS) {
      ?>
      <div class="social">
        <?php
        // html/social.tpl
        echo $this->SOCIAL_BUTTONS;
        ?>
      </div>
      <?php
      }

      // Footer must NOT be changed unless a commercial licence has been purchased
      // Maian Music is protected by copyright laws
      // It would be great if you can support this software, thank you.
      // https://www.maianmusic.com/purchase.html
      echo $this->FOOTER;
      ?>
    </footer>

    <?php
    // Nav menu..
    include(PATH . 'content/' . THEME . '/nav-menu.tpl.php');

    // Load JS Files..
    include(PATH . 'content/' . THEME . '/js-loader/global.php');
    if (file_exists(PATH . 'content/' . THEME . '/js-loader/' . $this->JS_LOADER . '.php')) {
      include(PATH . 'content/' . THEME . '/js-loader/' . $this->JS_LOADER . '.php');
    }
    include(PATH . 'content/' . THEME . '/js-loader/previews.php');

    // Action spinner, DO NOT REMOVE
    ?>
    <div class="overlaySpinner" style="display:none"></div>

  </body>
</html>