<?php if(!defined('PARENT')) { exit; }

/* HOME TEMPLATE
----------------------------------*/

?>

    <div class="row mainarea">
      <div class="col-lg-9 col-md-8">


       <?php
       // FEATURED COLLECTIONS
       // html/collection.tpl
       echo $this->FEATURED;
       ?>

      </div>
      <div class="col-lg-3 col-md-4">
        <?php
        // Right panel..
        include(dirname(__file__) . '/right-panel.tpl.php');
        ?>
      </div>
    </div>