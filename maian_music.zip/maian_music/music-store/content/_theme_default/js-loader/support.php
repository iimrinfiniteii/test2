<?php

/* JAVASCRIPT LOADER
--------------------------------------------------------*/

if (!defined('PARENT')) {
  exit;
}

?>
<script src="<?php echo BASE_HREF; ?>content/<?php echo THEME; ?>/js/plugins/jquery.textareafullscreen.js"></script>
<script>
//<![CDATA[
jQuery(document).ready(function() {
  if (jQuery('input[name="name"]').val() == '') {
    jQuery('input[name="name"]').focus();
  }
  jQuery('textarea').textareafullscreen({
    overlay   : true,
    maxWidth  : '80%',
    maxHeight : '80%'
  });
});
function mswSpmRld() {
   jQuery('input[name="as"]').addClass('msw-box-spinner-right');
   jQuery(document).ready(function() {
      jQuery.ajax({
        url: 'index.php',
        data: 'ajax=spm-rld&id=0',
        dataType: 'json',
        cache: false,
        success: function (data) {
          jQuery('.spamarea label span').html(data['spamreloaded']);
          jQuery('input[name="as"]').removeClass('msw-box-spinner-right');
          jQuery('input[name="as"]').val('');
        }
      });
    });
    return false;
}
function mswAction() {
  jQuery(document).ready(function() {
    mswShowSpinner();
    jQuery.ajax({
      type: 'POST',
      url: 'index.php?ajax=support&id=0',
      data: jQuery('.formfield > form').serialize(),
      cache: false,
      dataType: 'json',
      success: function(data) {
        mswCloseSpinner();
        if (data['resp'] == 'OK') {
          jQuery('.supportarea input[type="text"]').val('');
          jQuery('.supportarea textarea').val('');
        }
        mswAlert(data['title'], data['msg'], data['resp']);
      }
    });
    return false;
  });
  return false;
}
//]]>
</script>
