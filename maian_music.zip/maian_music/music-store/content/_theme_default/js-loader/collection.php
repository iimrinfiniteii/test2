<?php

/* JAVASCRIPT LOADER
--------------------------------------------------------*/

if (!defined('PARENT')) {
  exit;
}

?>
<script src="<?php echo BASE_HREF; ?>content/<?php echo THEME; ?>/js/soundmanager/soundmanager.js"></script>
<script>
//<![CDATA[
jQuery(document).ready(function() {
  soundManager.setup({
    url       : 'content/<?php echo THEME; ?>/swf/',
    debugMode : false
  });
});
function mswPlayMusic(id, fle) {
  // We populate the href programatically to prevent validation errors..
  // HTML doesn`t support mp3 files in the href tag..
  if (jQuery('#play-' + id).attr('href') == '#') {
    jQuery('#play-' + id).attr('href', fle)
  }
  soundManager.stopAll();
  var current = jQuery('#play-' + id + ' i:nth-child(2)').attr('class');
  if (current == 'fa fa-play fa-stack-1x fa-inverse') {
    // Reset all except current id..
    jQuery('.trackarea tbody tr td a.sm2_button').each(function() {
      var tr = jQuery(this).attr('id');
      var trid = tr.substring(5);
      if (trid != id) {
        jQuery('#play-' + trid + ' i:nth-child(2)').attr('class', 'fa fa-play fa-stack-1x fa-inverse');
        jQuery('#play-' + trid + ' span:nth-child(1)').removeClass('playing-button');
      }
    });
    jQuery('#play-' + id + ' i:nth-child(2)').attr('class', 'fa fa-stop fa-stack-1x fa-inverse');
    jQuery('#play-' + id + ' span:nth-child(1)').addClass('playing-button');
    soundManager.createSound({
      id       : 'play-' + id,
      url      : jQuery('#play-' + id).attr('href'),
      onfinish : function() {
        jQuery('#' + this.id + ' i:nth-child(2)').attr('class', 'fa fa-play fa-stack-1x fa-inverse');
        jQuery('#' + this.id + ' span:nth-child(1)').removeClass('playing-button');
      }
    });
    soundManager.play('play-' + id);
  } else {
    jQuery('#play-' + id + ' i:nth-child(2)').attr('class', 'fa fa-play fa-stack-1x fa-inverse');
    jQuery('#play-' + id + ' span:nth-child(1)').removeClass('playing-button');
    soundManager.destroySound('play-' + id);
  }
}
function mswTracks(id) {
  if (jQuery('.trackarea input[type="checkbox"]:checked').length > 0) {
    jQuery(document).ready(function() {
      mswShowSpinner();
      jQuery.ajax({
        type: 'POST',
        url: 'index.php?ajax=add-tracks&id=' + id,
        data: jQuery('.collectionarea > form').serialize(),
        cache: false,
        dataType: 'json',
        success: function(data) {
          mswCloseSpinner();
          jQuery('span[class="basket_count"]').html(data['cart']['count']);
          jQuery('.trackarea input[type="checkbox"]').prop('checked', false);
          mswAlert(data['title'], data['msg'], data['resp']);
        }
      });
    });
  }
  return false;
}
//]]>
</script>

<?php
// Include preview code..
define('COL_LOADED', 1);
?>