<?php

/* JAVASCRIPT LOADER
--------------------------------------------------------*/

if (!defined('PARENT')) {
  exit;
}

?>
<script>
//<![CDATA[
function mm_verifyResend() {
  jQuery(document).ready(function() {
    mswShowSpinner();
    jQuery.ajax({
      url: 'index.php',
      data: 'ajax=resend-verification&id=0',
      dataType: 'json',
      success: function(data) {
        mswCloseSpinner();
        mswAlert(data['title'], data['msg'], 'err');
      }
    });
  });
  return false;
}
//]]>
</script>