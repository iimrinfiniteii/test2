<?php

/* JAVASCRIPT LOADER
--------------------------------------------------------*/

if (!defined('PARENT')) {
  exit;
}

?>
<script>
//<![CDATA[
function mswAction() {
  jQuery(document).ready(function() {
    mswShowSpinner();
    jQuery.ajax({
      type: 'POST',
      url: 'index.php?ajax=profile&id=0',
      data: jQuery('.formfield > form').serialize(),
      cache: false,
      dataType: 'json',
      success: function(data) {
        mswCloseSpinner();
        mswAlert(data['title'], data['msg'], data['resp']);
      }
    });
    return false;
  });
  return false;
}
//]]>
</script>