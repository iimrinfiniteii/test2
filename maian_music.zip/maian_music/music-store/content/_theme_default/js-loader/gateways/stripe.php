<?php

/* JAVASCRIPT LOADER - STRIPE GATEWAY
--------------------------------------------------------*/

if (!defined('PARENT') && !empty($this->GATEWAYS_ENABLED['stripe'])) {
  exit;
}

?>
<script src="https://checkout.stripe.com/checkout.js"></script>
<script>
//<![CDATA[
function mswStripe() {
  jQuery(document).ready(function() {
    jQuery.ajax({
      type     : 'POST',
      url      : '<?php echo $this->URL[5]; ?>',
      data     : jQuery('#bform').serialize(),
      cache    : false,
      dataType : 'json',
      success  : function (data) {
        switch(data['status']) {
          case 'ok':
            var chargeAmount = data['s_charge'];
            var gw_handler = StripeCheckout.configure({
              key            : '<?php echo $this->GATEWAYS_ENABLED['stripe']['params']['perishable-key']; ?>',
              image          : '<?php echo (isset($this->GATEWAYS_ENABLED['stripe']['params']['image']) && $this->GATEWAYS_ENABLED['stripe']['params']['image'] ? $this->GATEWAYS_ENABLED['stripe']['params']['image'] : $this->URL[0] . 'content/' . THEME . '/images/stripe.png'); ?>',
              locale         : '<?php echo (isset($this->GATEWAYS_ENABLED['stripe']['params']['locale']) ? $this->GATEWAYS_ENABLED['stripe']['params']['locale'] : 'auto'); ?>',
              currency       : '<?php echo $this->SETTINGS->currency; ?>',
              billingAddress : true,
              token          : function(token) {
                mswShowSpinner();
                jQuery.post('<?php echo $this->URL[0]; ?>callback/stripe.php', {
                  id     : token.id,
                  email  : token.email,
                  custom : data['s_custom'],
                  charge : chargeAmount.toFixed(0)
                }, function(data) {
                  switch(data['status']) {
                    case 'ok':
                      window.location = data['url'];
                      break;
                    default:
                      if (data['errcode'] != undefined) {
                        window.location = 'index.php?msg=12&code=' + data['errcode'];
                      } else {
                        mswCloseSpinner();
                        mswAlert(data['title'], data['msg'], 'err');
                      }
                      break;
                  }
                }, 'json');
              }
            });
            if (jQuery('input[name="guest"]:checked').val()) {
              var paymail = jQuery('input[name="g_em"]').val();
            } else {
              var paymail = jQuery('input[name="em"]').val();
            }
            gw_handler.open({
              name        : '<?php echo mswSH(mswJS($this->SETTINGS->website)); ?>',
              description : '<?php echo mswJS($this->TXT[3][2]); ?>',
              email       : paymail,
              zipCode     : true,
              amount      : chargeAmount.toFixed(0)
            });
            mswCloseSpinner();
            break;
          default:
            mswCloseSpinner();
            mswAlert(data['title'], data['msg'], data['resp']);
            break;
        }
      }
    });
  });
}
window.addEventListener('popstate', function() {
  gw_handler.close();
});
//]]>
</script>