<?php

/* JAVASCRIPT LOADER
--------------------------------------------------------*/

if (!defined('PARENT')) {
  exit;
}

?>
<script>
//<![CDATA[
function mswDL(id, txt, path) {
  jQuery(document).ready(function() {
    mswShowSpinner();
    jQuery.ajax({
      url: 'index.php',
      data: 'dmf=' + id,
      dataType: 'json',
      success: function(data) {
        mswCloseSpinner()
        switch (data['resp']) {
          case 'TOKEN':
            mswWinLoc('index.php?dmf=' + data['itemid'] + '&t=' + data['token']);
            break;
          case 'LOCK':
            mswWinLoc('index.php?msg=6');
            break;
          case 'RDR-INDEX':
            mswWinLoc('index.php');
            break;
          case 'err':
            mswAlert(data['title'], data['msg'], 'err');
            break;
        }
      }
    });
  });
  return false;
}
//]]>
</script>