<?php

/* GLOBAL JAVASCRIPT LOADER
--------------------------------------------------------*/

if (!defined('PARENT')) {
  exit;
}

?>
<script src="<?php echo BASE_HREF; ?>content/<?php echo THEME; ?>/js/jquery.js"></script>
<script src="<?php echo BASE_HREF; ?>content/<?php echo THEME; ?>/js/bootstrap.js"></script>
<script src="<?php echo BASE_HREF; ?>content/<?php echo THEME; ?>/js/plugins/jquery.bootbox.js"></script>
<script src="<?php echo BASE_HREF; ?>content/<?php echo THEME; ?>/js/plugins/jquery.ibox.js"></script>
<script src="<?php echo BASE_HREF; ?>content/<?php echo THEME; ?>/js/plugins/jquery.pushy.js"></script>
<script>
//<![CDATA[
var mswcfg = {
  ays : '<?php echo (isset($this->CONF_MSG) ? $this->CONF_MSG : ''); ?>',
  path : '<?php echo BASE_HREF; ?>content/<?php echo THEME; ?>/'
}
//]]>
</script>
<script src="<?php echo BASE_HREF; ?>content/<?php echo THEME; ?>/js/mmusic.js"></script>
<script src="<?php echo BASE_HREF; ?>content/<?php echo THEME; ?>/js/mmusic-ops.js"></script>
