<?php

/* JAVASCRIPT LOADER
--------------------------------------------------------*/

if (!defined('PARENT')) {
  exit;
}

?>
<script src="<?php echo BASE_HREF; ?>content/<?php echo THEME; ?>/js/plugins/jquery.textareafullscreen.js"></script>
<script>
//<![CDATA[
jQuery(document).ready(function() {
  jQuery('textarea').textareafullscreen({
    overlay   : true,
    maxWidth  : '80%',
    maxHeight : '80%'
  });
});
function mswTOS() {
  jQuery(document).ready(function() {
    mswShowSpinner();
    jQuery.ajax({
      url: 'index.php',
      data: 'ajax=tac&id=0',
      dataType: 'json',
      cache: false,
      success: function (data) {
        mswCloseSpinner();
        mswAlert(data['title'], data['msg'], data['resp']);
      }
    });
  });
  return false;
}
function mswTax() {
  jQuery(document).ready(function() {
    mswShowSpinner();
    jQuery.ajax({
      url: 'index.php',
      data: 'ajax=tax-info&id=0',
      dataType: 'json',
      cache: false,
      success: function (data) {
        mswCloseSpinner();
        mswAlert(data['title'], data['msg'], data['resp']);
      }
    });
  });
  return false;
}
function mswPayRld(vl) {
  jQuery('select[name="payment"]').addClass('msw-box-spinner-center');
  setTimeout(function() {
    if (jQuery('.payimg img')) {
      if (vl == '0') {
        jQuery('.payimg img').hide();
      } else {
        jQuery('.payimg img').attr('src', jQuery('input[name="gw' + vl + '"]').val());
        jQuery('.payimg img').show();
      }
    }
    jQuery('select[name="payment"]').removeClass('msw-box-spinner-center');
  }, 500);
}
function mswGuest(op) {
  switch(op) {
    case true:
      jQuery('div[class="account"]').hide();
      jQuery('div[class="guest"]').fadeIn(500);
      jQuery('input[name="g_em"]').val(jQuery('input[name="em"]').val());
      jQuery('input[name="g_nm"]').val(jQuery('input[name="nm"]').val());
      jQuery('select[name="g_rescountry"]').val(jQuery('select[name="rescountry"]').val());
      jQuery('div[class="account"] input').val('');
      jQuery('div[class="account"] select').val('0');
      jQuery('hr[class="hr_acc"]').hide();
      jQuery('.pn2 .panel-body').css('padding-top', '0');
      break;
    case false:
      jQuery('div[class="account"]').fadeIn(500);
      jQuery('div[class="guest"]').hide();
      jQuery('input[name="em"]').val(jQuery('input[name="g_em"]').val());
      jQuery('input[name="nm"]').val(jQuery('input[name="g_nm"]').val());
      jQuery('select[name="rescountry"]').val(jQuery('select[name="g_rescountry"]').val());
      jQuery('div[class="guest"] input').val('');
      jQuery('div[class="guest"] select').val('0');
      jQuery('hr[class="hr_acc"]').show();
      jQuery('.pn2 .panel-body').css('padding-top', '12px');
      break;
  }
}
function mswClrShipFlds() {
  jQuery('.pn3 input[type="text"]').val('');
  jQuery('.pn3 select[name="country"]').val('0');
}
function mswBkPnl(id, act) {
  // Check for shipping selector..
  // If shipped items have been removed, adjust action..
  var is_ship = jQuery('input[name="is_shipping"]').val();
  var is_acc = jQuery('input[name="account"]').val();
  switch(id) {
    case '2':
      if (act == '3' && is_ship == 'no') {
        mswClrShipFlds();
        var act = 4;
      }
      if (act == 'back' && is_acc == 'yes') {
        var act = 'items';
      }
      break;
    case '3':
      if (act == 'back' && is_ship == 'no') {
        if (is_acc == 'no') {
          var id = 2;
        }
      }
      break;
  }
  if (act == 'back') {
    jQuery('.basket_op').hide();
    jQuery('.pn' + id).fadeIn(500);
    return false;
  }
  if (act == 'items') {
    jQuery('.basket_op').hide();
    jQuery('.pn1').fadeIn(500);
    return false;
  }
  mswShowSpinner();
  switch(id) {
    // Items..
    case '1':
    // Shipping..
    case '3':
    // Checkout..
    case 'checkout':
      var d_url = '';
      switch(id) {
        case '1':
          jQuery('input[name="guest"]').prop('checked', false);
          var d_url = 'index.php?ajax=basket-login&min=yes&id=0';
          break;
        case '3':
          var d_url = 'index.php?ajax=basket-shipping&id=0';
          break;
        case 'checkout':
          var d_url = 'index.php?ajax=basket-checkout&id=0';
          break;
      }
      if (d_url) {
        jQuery(document).ready(function() {
          jQuery.ajax({
            type: 'POST',
            url: d_url,
            data: jQuery('.basketarea > form').serialize(),
            cache: false,
            dataType: 'json',
            success: function (data) {
              switch(data['resp']) {
                case 'err':
                  mswCloseSpinner();
                  mswAlert(data['title'], data['msg'], data['resp']);
                  break;
                default:
                  if (data['basket'] == 'process') {
                    jQuery('#bform').append('<input type="hidden" name="process" value="yes">');
                    switch (jQuery('select[name="payment"]').val()) {
                      // Stripe gateway..
                      case data['stripe']:
                        setTimeout(function() {
                          mswStripe();
                        }, 500);
                        break;
                      // Keep going..
                      default:
                        jQuery('#bform').submit();
                        break;
                    }
                  } else {
                    mswCloseSpinner();
                    // If logged in, we can bypass account screen..
                    if (data['logged_in'] == 'yes') {
                      jQuery('.basket_op').hide();
                      if (is_ship == 'yes') {
                        jQuery('.pn3').fadeIn(500);
                      } else {
                        jQuery('.pn4').fadeIn(500);
                      }
                    } else {
                      jQuery('.basket_op').hide();
                      jQuery('.pn' + act).fadeIn(500);
                    }
                  }
                  break;
              }
            }
          });
        });
      }
      return false;
      break;
    // Account..
    case '2':
      jQuery(document).ready(function() {
        jQuery.ajax({
          type: 'POST',
          url: 'index.php?ajax=basket-login&id=0',
          data: jQuery('.basketarea > form').serialize(),
          cache: false,
          dataType: 'json',
          success: function (data) {
            mswCloseSpinner();
            switch(data['resp']) {
              case 'err':
                mswAlert(data['title'], data['msg'], data['resp']);
                break;
              case 'NEW':
                break;
              case 'GUEST-EXIST':
                mswAlert(data['title'], data['msg'], 'err');
                jQuery('input[name="guest"]').prop('checked', false);
                var em = jQuery('input[name="g_em"]').val();
                mswGuest(false);
                jQuery('input[name="em"]').val(em);
                break;
              case 'GUEST-OK':
                mswTotals(data['sys']);
                jQuery('select[name="country"]').val(jQuery('select[name="g_rescountry"]').val());
                jQuery('.basket_op').hide();
                jQuery('.pn' + act).fadeIn(500);
                break;
              case 'VALID':
                // Address fields, populate only if blank..
                if (jQuery('select[name="method"]').val() == '') {
                  jQuery('select[name="method"]').val(data['sys']['method']);
                }
                if (jQuery('input[name="address1"]').val() == '') {
                  jQuery('input[name="address1"]').val(data['sys']['address1']);
                }
                if (jQuery('input[name="address2"]').val() == '') {
                  jQuery('input[name="address2"]').val(data['sys']['address2']);
                }
                if (jQuery('input[name="city"]').val() == '') {
                  jQuery('input[name="city"]').val(data['sys']['city']);
                }
                if (jQuery('input[name="county"]').val() == '') {
                  jQuery('input[name="county"]').val(data['sys']['county']);
                }
                if (jQuery('input[name="postcode"]').val() == '') {
                  jQuery('input[name="postcode"]').val(data['sys']['postcode']);
                }
                if (jQuery('select[name="country"]').val() == '0') {
                  jQuery('select[name="country"]').val(data['sys']['country']);
                }
                jQuery('input[name="account"]').val('yes');
                mswTotals(data['sys']);
                jQuery('.basket_op').hide();
                jQuery('.pn' + act).fadeIn(500);
                break;
            }
          }
        });
      });
      return false;
      break;
    // Gift code..
    case '4':
      jQuery(document).ready(function() {
        jQuery.ajax({
          type: 'POST',
          url: 'index.php?ajax=basket-coupon&id=0',
          data: jQuery('.basketarea > form').serialize(),
          cache: false,
          dataType: 'json',
          success: function (data) {
            mswCloseSpinner();
            switch(data['resp']) {
              case 'OK':
              case 'CLEARED':
                mswTotals(data['sys']);
                jQuery('.basket_op').hide();
                jQuery('.pn' + act).fadeIn(500);
                break;
              case 'err':
                mswAlert(data['title'], data['msg'], data['resp']);
                break;
            }
          }
        });
      });
      return false;
      break;
  }
}
function mswTotals(obj) {
  jQuery('.t_shipping').hide();
  jQuery('.t_tax').hide();
  if (jQuery('.t_coupon').html()) {
    jQuery('.t_coupon').remove();
  }
  // Is shipping applicable?
  if (obj['ship'] != undefined && jQuery('input[name="is_shipping"]').val() == 'yes' && obj['ship'] != '0.00') {
    jQuery('.t_sub td:nth-child(2)').html(obj['sub']);
    jQuery('.t_shipping td:nth-child(2)').html(obj['ship']);
    jQuery('.t_shipping').show();
  }
  // Is tax applicable..
  if (obj['tax'] != undefined && obj['tax'] != 'no' && obj['tax'] != '0.00') {
    jQuery('.t_tax td:nth-child(2)').html(obj['tax']);
    jQuery('.t_tax').show();
  }
  // Was coupon applied..
  if (obj['couponhtml'] != undefined && obj['couponhtml'] != '') {
    jQuery('.t_sub').after(obj['couponhtml']);
  } else {
    if (jQuery('.t_coupon').html()) {
      jQuery('.t_coupon').remove();
    }
  }
  if (obj['rawtotal'] != undefined) {
    if (obj['rawtotal'] > 0) {
      jQuery('select[name="payment"]').removeClass('disabled');
    } else {
      jQuery('select[name="payment"]').val('0');
      mswPayRld('0');
      jQuery('select[name="payment"]').addClass('disabled');
    }
  }
  jQuery('.t_total td:nth-child(2)').html(obj['total']);
}
function mswRemBsk(slot) {
  switch(slot) {
    case 'all':
      var confirmSub = confirm(mswcfg.ays);
      if (!confirmSub) {
        return false;
      }
      mswShowSpinner();
      break;
    default:
      jQuery('.basket_tr_' + slot + ' td:nth-child(4) i').attr('class', 'fas fa-spinner fa-fw fa-spin msw_red');
      break;
  }
  jQuery(document).ready(function() {
    jQuery.ajax({
      url: 'index.php',
      data: 'ajax=' + (slot == 'all' ? 'clear-all-basket' : 'rem-basket') + '&id=' + slot,
      dataType: 'json',
      cache: false,
      success: function (data) {
        mswCloseSpinner();
        if (slot == 'all' || data['count'] == 0) {
          window.location.reload();
        } else {
          jQuery('span[class="basket_count"]').html(data['count']);
          jQuery('.basket_tr_' + slot).remove();
          jQuery('input[name="is_shipping"]').val(data['cart']['is_ship']);
        }
      }
    });
  });
  return false;
}
<?php
// Populate shipping address on load if logged in and if shipping is applicable..
if (isset($this->IS_SHIPPING) && $this->IS_SHIPPING == 'yes' && isset($this->ACCOUNT['accID'])) {
?>
jQuery(document).ready(function() {
  mswAcc('<?php echo $this->ACCOUNT['accID']; ?>');
});
function mswAcc(id) {
  jQuery(document).ready(function() {
    jQuery.ajax({
      url: 'index.php',
      data: 'ajax=address&id=' + id,
      dataType: 'json',
      success: function(data) {
        if (data['resp'] == 'OK') {
          jQuery('select[name="method"]').val(data['sys']['method']);
          jQuery('input[name="address1"]').val(data['sys']['address1']);
          jQuery('input[name="address2"]').val(data['sys']['address2']);
          jQuery('input[name="city"]').val(data['sys']['city']);
          jQuery('input[name="county"]').val(data['sys']['county']);
          jQuery('input[name="postcode"]').val(data['sys']['postcode']);
          jQuery('select[name="country"]').val(data['sys']['country']);
        }
      }
    });
  });
  return false;
}
<?php
}

// Send data to gateway..don`t change..
if ($this->GATEWAY_LOADED == 'yes') {
?>
jQuery(document).ready(function() {
  setTimeout(function() {
    jQuery('#payform').submit();
  }, 2000);
});
<?php
}
?>
//]]>
</script>
<?php

// Gateway specific code, load if required..
if (isset($this->GATEWAYS_ENABLED['stripe']['enabled']) && $this->GATEWAYS_ENABLED['stripe']['enabled'] == 'yes') {
  include(dirname(__file__) . '/gateways/stripe.php');
}

?>