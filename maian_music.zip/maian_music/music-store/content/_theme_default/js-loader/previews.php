<?php

/* JAVASCRIPT LOADER
--------------------------------------------------------*/

if (!defined('PARENT')) {
  exit;
}

// Already loaded for collections, so not needed..
if (!defined('COL_LOADED')) {
?>
<script src="<?php echo BASE_HREF; ?>content/<?php echo THEME; ?>/js/soundmanager/soundmanager.js"></script>
<?php
}
?>
<script>
//<![CDATA[
<?php
// Already loaded for collections, so not needed..
if (!defined('COL_LOADED')) {
?>
jQuery(document).ready(function() {
  soundManager.setup({
    url       : 'content/<?php echo THEME; ?>/swf/',
    debugMode : false
  });
});
<?php
}
?>
function mswPlayPrevMusic(id, fle) {
  // We populate the href to prevent validation errors..
  // HTML5 doesn`t support mp3 files in the href tag on load..
  if (jQuery('#prevplay-' + id).attr('href') == '#') {
    jQuery('#prevplay-' + id).attr('href', fle)
  }
  soundManager.stopAll();
  var current = jQuery('#prevplay-' + id + ' i:nth-child(2)').attr('class');
  if (current == 'fa fa-play fa-stack-1x fa-inverse') {
    // Reset all except current id..
    jQuery('.previewarea tbody tr td a.sm2_button').each(function() {
      var tr = jQuery(this).attr('id');
      var trid = tr.substring(9);
      if (trid != id) {
        jQuery('#prevplay-' + trid + ' i:nth-child(2)').attr('class', 'fa fa-play fa-stack-1x fa-inverse');
        jQuery('#prevplay-' + trid + ' span:nth-child(1)').removeClass('playing-button');
      }
    });
    jQuery('#prevplay-' + id + ' i:nth-child(2)').attr('class', 'fa fa-stop fa-stack-1x fa-inverse');
    jQuery('#prevplay-' + id + ' span:nth-child(1)').addClass('playing-button');
    soundManager.createSound({
      id       : 'prevplay-' + id,
      url      : jQuery('#prevplay-' + id).attr('href'),
      onfinish : function() {
        jQuery('#' + this.id + ' i:nth-child(2)').attr('class', 'fa fa-play fa-stack-1x fa-inverse');
        jQuery('#' + this.id + ' span:nth-child(1)').removeClass('playing-button');
      }
    });
    soundManager.play('prevplay-' + id);
  } else {
    jQuery('#prevplay-' + id + ' i:nth-child(2)').attr('class', 'fa fa-play fa-stack-1x fa-inverse');
    jQuery('#prevplay-' + id + ' span:nth-child(1)').removeClass('playing-button');
    soundManager.destroySound('prevplay-' + id);
  }
}
function mswPrevTracks(id) {
  var boxeschk = jQuery('.previewarea input[type="checkbox"]:checked').length;
  if (boxeschk > 0) {
    var cur = jQuery('.prevbutton button').html();
    jQuery('.prevbutton button').html('<i class="fas fa-spinner fa-fw fa-spin"></i>');
    jQuery(document).ready(function() {
      jQuery.ajax({
        type: 'POST',
        url: 'index.php?ajax=add-tracks&id=' + id + '&prev=yes',
        data: jQuery('.previewarea > form').serialize(),
        cache: false,
        dataType: 'json',
        success: function(data) {
          jQuery('span[class="basket_count"]').html(data['cart']['count']);
          jQuery('.prevbutton span').html('<i class="fas fa-check fa-fw"></i> ' + boxeschk + ' ' + data['tracks']);
          jQuery('.previewarea input[type="checkbox"]').prop('checked', false);
          jQuery('.prevbutton button').html(cur);
        }
      });
    });
  }
  return false;
}
//]]>
</script>