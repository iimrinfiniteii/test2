<?php

/* JAVASCRIPT LOADER
--------------------------------------------------------*/

if (!defined('PARENT')) {
  exit;
}

?>
<script>
//<![CDATA[
function mswLogin(action) {
  switch (action) {
    case 'forgot':
    case 'enter':
      switch (action) {
        case 'forgot':
          if (jQuery('input[name="e"]').val() == '') {
            jQuery('input[name="e"]').focus();
            return false;
          }
          break;
        case 'enter':
          if (jQuery('input[name="e"]').val() == '') {
            jQuery('input[name="e"]').focus();
            return false;
          } else {
            if (jQuery('input[name="p"]').val() == '') {
              jQuery('input[name="p"]').focus();
              return false;
            }
          }
          break;
      }
      jQuery(document).ready(function() {
        mswShowSpinner();
        jQuery.ajax({
          type: 'POST',
          url: 'index.php?ajax=login&id=' + action,
          data: jQuery('.formfield > form').serialize(),
          cache: false,
          dataType: 'json',
          success: function(data) {
            mswCloseSpinner();
            switch (data['resp']) {
              case 'rdr':
                mswWinLoc(data['wind']);
                break;
              case 'err':
              case 'OK':
                mswAlert(data['title'], data['msg'], data['resp']);
                break;
            }
          }
        });
        return false;
      });
      break;
    case 'forgot-load':
      jQuery('.passarea').hide();
      jQuery('#benter').hide();
      jQuery('#benter2').hide();
      jQuery('#bforgot').show();
      jQuery('#bforgot2').show();
      if (jQuery('input[name="e"]').val() == '') {
        jQuery('input[name="e"]').focus();
      }
      break;
    case 'forgot-cancel':
      jQuery('.passarea').show();
      jQuery('#benter').show();
      jQuery('#benter2').show();
      jQuery('#bforgot').hide();
      jQuery('#bforgot2').hide();
      if (jQuery('input[name="e"]').val()) {
        if (jQuery('input[name="p"]').val() == '') {
          jQuery('input[name="p"]').focus();
        }
      } else {
        jQuery('input[name="e"]').focus();
      }
      break;
  }
  return false;
}
jQuery(document).ready(function() {
  if (jQuery('input[name="e"]').val()=='') {
    jQuery('input[name="e"]').focus();
  } else {
    if (jQuery('input[name="p"]').val()=='') {
      jQuery('input[name="p"]').focus();
    }
  }
});
//]]>
</script>