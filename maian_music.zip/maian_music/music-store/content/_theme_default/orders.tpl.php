<?php if(!defined('PARENT')) { exit; }

/* ORDERS TEMPLATE
----------------------------------*/

?>

    <div class="row mainarea">
      <div class="col-lg-9 col-md-8">

        <h1><?php echo $this->TXT[0]; ?> (<?php echo $this->COUNT; ?>)</h1>

        <?php
        // ORDERS..
        if ($this->ORDERS) {
        ?>
        <div class="panel panel-default orders">
          <div class="panel-body">
            <div class="table-responsive">
              <table class="table table-striped table-hover">
              <thead>
                <tr>
                  <th><?php echo $this->TXT[1]; ?></th>
                  <th><?php echo $this->TXT[2]; ?></th>
                  <th><?php echo $this->TXT[3]; ?></th>
                  <th class="text-right"><?php echo $this->TXT[4]; ?></th>
                </tr>
              </thead>
              <tbody>
                <?php
                // html/order-item.tpl
                echo $this->ORDERS;
                ?>
              </tbody>
              </table>
            </div>
          </div>
        </div>

        <?php
        // PAGINATION
        // html/pagination/*
        echo $this->PAGINATION;
        }
        ?>

      </div>
      <div class="col-lg-3 col-md-4">
        <?php
        // Right panel..
        include(dirname(__file__) . '/right-panel.tpl.php');
        ?>
      </div>
    </div>

<?php
/*
?>
            <div class="col-lg-9 col-md-9 col-sm-12">

              <div class="col-lg-12 col-sm-12">
            		<span class="title"><?php echo $this->TXT[0]; ?></span>
            	</div>

				      <?php
				      if ($this->ORDERS) {
				      ?>
	            <div class="col-lg-12 col-sm-12">
					     <table class="table table-bordered tbl-orders table-hover">
                <thead>
                 <tr>
                  <td><?php echo $this->TXT[1]; ?></td>
                  <td><?php echo $this->TXT[2]; ?></td>
                  <td><?php echo $this->TXT[3]; ?></td>
                  <td><?php echo $this->TXT[4]; ?></td>
                 </tr>
                </thead>
                <tbody>
						    <?php
						    // ORDERS
						    // html/order-item.tpl
						    echo $this->ORDERS;
						    ?>
                </tbody>
               </table>

               <div class="pagesdiv">
				       <?php
				       // PAGINATION
				       // control/classes/class.page.php
				       echo $this->PAGINATION;
				       ?>
					     </div>

              </div>
				      <?php
				      }
				      ?>

            </div>
            <?php
            */
            ?>