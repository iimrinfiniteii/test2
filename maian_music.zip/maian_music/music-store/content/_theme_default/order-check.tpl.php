<?php if(!defined('PARENT')) { exit; }

/* ORDER CHECK TEMPLATE
------------------------------------------*/

?>

    <div class="row mainarea">
      <div class="col-lg-9 col-md-8">

        <h1><i class="fas fa-chevron-right fa-fw"></i> <?php echo $this->TXT[0]; ?></h1>

        <div class="panel panel-default">
          <div class="panel-body">
            <img src="<?php echo BASE_HREF; ?>content/<?php echo THEME; ?>/images/animated/doing-something.gif" alt=""><br><br>
            <?php echo $this->TXT[1]; ?>
          </div>
        </div>

      </div>
      <div class="col-lg-3 col-md-4">
        <?php
        // Right panel..
        include(dirname(__file__) . '/right-panel.tpl.php');
        ?>
      </div>
    </div>