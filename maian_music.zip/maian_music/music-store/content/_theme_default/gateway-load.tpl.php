<?php if(!defined('PARENT')) { exit; }

/* GATEWAY LOAD TEMPLATE
----------------------------------*/

?>

    <div class="row mainarea">
      <div class="col-lg-9 col-md-8">

        <h1><i class="fas fa-credit-card fa-fw"></i> <?php echo $this->TXT[0]; ?></h1>

        <div class="panel panel-default">
          <div class="panel-body">
            <img src="<?php echo BASE_HREF; ?>content/<?php echo THEME; ?>/images/animated/doing-something.gif" alt=""><br><br>
            <?php echo $this->TXT[1]; ?>
            <div style="display:none">
              <form method="post" action="<?php echo $this->SERVER; ?>" id="payform">
              <?php
              // PAYMENT GATEWAY FIELDS
              // You may add to the fields array if you wish to send additional info..(advanced users)
              if (!empty($this->FIELDS)) {
                foreach ($this->FIELDS AS $k => $v) {
                ?>
                <input type="hidden" name="<?php echo mswSH($k); ?>" value="<?php echo mswSH($v); ?>">
                <?php
                }
              }
              ?>
              </form>
            </div>
          </div>
        </div>

      </div>
      <div class="col-lg-3 col-md-4">
        <?php
        // Right panel..
        include(dirname(__file__) . '/right-panel.tpl.php');
        ?>
      </div>
    </div>