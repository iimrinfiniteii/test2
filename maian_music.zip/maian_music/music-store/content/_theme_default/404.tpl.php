<?php if(!defined('PARENT')) { exit; }

/* 404 TEMPLATE
----------------------------------*/

?>

    <div class="row mainarea">
      <div class="col-lg-9 col-md-8">

        <h1 class="msw_red"><i class="fas fa-exclamation-triangle fa-fw"></i> <?php echo $this->TXT[0]; ?></h1>

        <div class="panel panel-default">
          <div class="panel-body">
            <?php echo $this->TXT[1]; ?>
          </div>
          <div class="panel-footer">
            <button type="button" class="btn btn-default" onclick="mswWinLoc('<?php echo BASE_HREF; ?>')"><?php echo $this->TXT[2][1]; ?> <i class="fas fa-chevron-right fa-fw"></i></button>
          </div>
        </div>

      </div>
      <div class="col-lg-3 col-md-4">
        <?php
        // Right panel..
        include(dirname(__file__) . '/right-panel.tpl.php');
        ?>
      </div>
    </div>