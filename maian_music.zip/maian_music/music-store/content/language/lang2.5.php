<?php

//------------------------------------------------------------------------------
// LANGUAGE FILE
// Edit with care. Make a backup first before making changes.
//
// [1] Apostrophes should be escaped. eg: it\'s christmas.
// [2] Take care when editing arrays as they are spread across multiple lines
//
// If you make a mistake and you see a parse error, revert to backup file
//------------------------------------------------------------------------------

$pageErrs = array(
  'Oops, an error has occurred. Page Not Found!',
  'Oops, an error has occurred. Forbidden!',
  'Return to Dashboard'
);

$msw_global_2_5 = array(
  'Please select at least 1 item',
  'No missing music files were found',
  'No missing music preview files were found',
  'No missing cover art images were found',
  'Export Collections/Tracks',
  'Browse',
  'Mail Settings',
  'Software Version',
  'Settings',
  'Tools',
  'Print Invoice',
  'Manage Boxes',
  'Add New Box',
  'Approve Sales'
);

$msw_collections_2_5 = array(
  'Please enter a collection name',
  'SEO rewrite slug MUST be unique, please try again',
  'Selected collection(s) successfully deleted',
  'Please locate CSV file and select at least 1 music style',
  'Please locate CSV file and select destination collection',
  'Cancel &amp; Return to Collections',
  'Create Tags From Tracks',
  'Minimum Word Length',
  'Max Tags to Create (0 = Unlimited)',
  'Create Tags'
);

$msw_dashboard_2_5 = array(
  'Sales',
  'History',
  'There is no sales data to display',
  'Search sales, music and accounts',
  'Completed Sales'
);

$msw_settings_2_5 = array(
  'Email Personalisation Tags',
  'Approve All Sales',
  'Company Info',
  'Company Info (HTML can be used)'
);

$msw_music_tracks_2_5 = array(
  'Please choose a folder to load tracks from that folder.<br><br>If no folders exist, please add your folders to your secure folder. Music files can be in the root of your secure folder or in sub folders:<br><br>{folder}<br><br>Once added, refresh page to see folders in list.',
  'Add Track',
  'Tracks currently in collection: {count}',
  'Tracks in "{folder}" folder: {count}',
  'Selected track(s) successfully deleted',
  'Length (Shortest)',
  'Length (Longest)',
  'Not Set',
  'Edit Tracks'
);

$msw_maxmind_settings_2_5 = array(
  'Maxmind Settings',
  'IPv4',
  'IPv6',
  'Maxmind settings successfully updated',
  'Locate MaxMind IPv4 GeoLite2 Country DB File',
  'IPv4 Database Active',
  'IPv6 Database Active',
  'Please refer to the documentation which details what files to upload'
);

$msw_mail_settings_2_5 = array(
  'Headers',
  'SMTP "Reply-To" Name',
  'SMTP "Reply-To" Email',
  'Enable Email Debugging',
  'Mail Protocol',
  'PHP Mail Function',
  'SSL/TLS Only - Do Not Verify Certificates',
  'Mail settings successfully updated'
);

$msw_social_settings_2_5 = array(
  'Twitter API',
  'Social Links',
  'AddThis HTML Code',
  'Comments',
  'There are currently no social links',
  'Enter font awesome class name..',
  'Enter url..',
  'Send',
  'Enable Twitter Cards',
  'Enable Google+ Meta Tags',
  'Social settings successfully updated',
  'Click button to send message to your pushover devices',
  'An error status was returned, check pushover settings',
  'Twitter Username',
  'Tweet successfully posted'
);

$msw_styles_2_5 = array(
  'Please enter a style name',
  'SEO rewrite slug MUST be unique, please try again',
  'Selected collection(s) successfully deleted',
  'Show All for Sorting'
);

$msw_accounts_2_5 = array(
  'Please enter name, valid email address and country of residence',
  'Order by Sales (9-0)',
  'Order by Sales (0-9)',
  'Disabled Only',
  'Clear Login History',
  'There is no data to export, please try again',
  'All Accounts',
  'Please enter subject, message and select at least 1 account',
  'Selected account(s) successfully deleted',
  'Selected account login history successfully deleted',
  'Order by IP (Asc)',
  'Order by IP (Desc)',
  'Order by Country (A-Z)',
  'Order by Country (Z-A)',
  'Order by Date/Time (Asc)',
  'Order by Date/Time (Desc)'
);

$msw_sales_2_5 = array(
  'Export MOSS',
  'Lock Download Page',
  'Purchases',
  'Full Collection',
  'Digital Download',
  'CD',
  'Remove Item',
  'Add Item',
  'This will reset the selected downloads. Are you sure?',
  'Reset',
  'Shipping Method / Zone',
  'Guest Checkout',
  'Selected sale(s) successfully deleted',
  'Create Account if Account Doesn`t Exist',
  'Please enter name, valid email address, invoice number and payment status',
  'At least 1 sale item is required.<br><br>Please add items to the sale clipboard or select an item from the sale clipboard to add',
  'Please specify at least 1 download to reset',
  'Clear Download History (All Items)',
  'Licence agreement resent to "{name}"',
  'Best Sellers',
  'Tangible Discount',
  'Digital Discount'
);

$msw_approve_2_5 = array(
  'Awaiting Approval',
  'Approve',
  'Approve - Send Emails',
  'Approve - No Emails',
  '{count} sales(s) approved and email(s) sent',
  '{count} sales(s) approved'
);

$msw_best_sellers_2_5 = array(
  'Top {count} Best Selling Collection Downloads',
  'Top {count} Best Selling Track Downloads',
  'Top {count} Best Selling Collection CD Purchases',
  'Total Sales',
  'Total Revenue',
  'Export to CSV',
  'Name,Total Sales,Total Revenue', //for csv
  'Name,Collection,Total Sales,Total Revenue'
);

$msw_offers_2_5 = array(
  'All Collections',
  'Please enter a discount value',
  'Please enter coupon code and discount value',
  'Selected offer(s) successfully deleted',
  'Selected coupon(s) successfully deleted'
);

$msw_gateways_2_5 = array(
  'Please enter gateway name, live server url and sandbox server url',
  'Selected gateway(s) successfully deleted',
  'Document Page'
);

$msw_pages_2_5 = array(
  'Please enter a page name',
  'SEO rewrite slug MUST be unique, please try again',
  'Selected page(s) successfully deleted'
);

$msw_countries_2_5 = array(
  'All fields in the first tab are required, please try again',
  'Selected countries successfully deleted'
);

$msw_backup_2_5 = array(
  'Backup completed and saved to backup folder'
);

$msw_mobile_2_5 = array(
  '["J","F","M","A","M","J","J","A","S","O","N","D"]' // short months for graph
);

$msw_boxes_2_5 = array(
  'Box Title',
  'Box Info/Code',
  'General',
  'Options',
  'Enabled',
  'Load from Custom Template',
  'Add Box',
  'Update Box',
  'Menu Box List',
  'Box successfully added',
  'Box successfully updated',
  'Selected box(es) successfully deleted',
  'A box with this title already exists',
  'Please enter title and information OR title and custom template',
  'Box Icon (Font Awesome Class Name)'
);

$msw_search_2_5 = array(
  'Search Results',
  'Collections',
  'Tracks',
  'Sales',
  'Accounts',
  'In'
);

/* Public updates */
$msw_public_int_2_5 = array(
  'Basket',
  'Continue',
  'Your account is already enabled',
  'If there are any problems with this order, please contact us',
  'Order Details',
  'Invoice',
  'Digital Goods',
  'Tangible Goods',
  'Tax @ {tax}%',
  'h,m,s', // hours, minutes, seconds prefix
  'Support',
  'Name',
  'Email Address',
  'Subject',
  'Comments',
  'Send Message',
  'Preview',
  'Spam Prevention',
  'Spam prevention answer not completed or incorrect, please try again'
);

$msw_public_global_2_5 = array(
  'Music @ {website}'
);

$msw_public_music_2_5 = array(
  'track(s) added'
);

$msw_public_checkout_2_5 = array(
  'Sub Total',
  'Clear All',
  'Checkout &amp; Pay',
  'This will clear your shopping basket.\n\nAre you sure?',
  'Continue',
  'Previous',
  'If this is a new account, please complete the following',
  'Ignore account options and checkout as guest',
  'For guest checkout, please complete the following',
  'No payment method selected',
  'Please enter name, valid email address and country of residence',
  'An account exists with this email address. Please login to your account to proceed',
  'If you have entered a coupon code, leave the box blank to clear it',
  'Please wait...',
  'Please select a payment method..'
);

$emlang_2_5 = array(
  '[{website}] New Sale Added',
  '[{website}] Sale Approved'
);

$checkmsg_2_5 = array(
  'For security and fraud prevention, our system is set to approve all orders before they can be accessed.<br><br>An email will follow as soon as your order has been approved.<br><br>We appreciate your patience and apologise for any inconvenience.'
);

$msw_public_errs_2_5 = array(
  'An error occurred with this transaction. This may be an issue with our database.<br><br>Please try again. If this persists, please let us know, thank you.<br><br>We apologise for any inconvenience.'
);

?>