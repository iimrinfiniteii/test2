<?php

//------------------------------------------------------------------------------
// LANGUAGE FILE
// Edit with care. Make a backup first before making changes.
//
// [1] Apostrophes should be escaped. eg: it\'s christmas.
// [2] Take care when editing arrays as they are spread across multiple lines
//
// If you make a mistake and you see a parse error, revert to backup file
//------------------------------------------------------------------------------

$jslang = array(
  '["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]',
  '["Su","Mo","Tu","We","Th","Fr","Sa"]',
  'false', // Should calendar display right to left (RTL)?
  'Are you sure?',
  'System Message',
  'Delete',
  'Cancel',
  'Deletions are permanent and cannot be recovered',
  'Backup completed and saved to "backup" folder',
  '<b>{email}</b><br><br>This email already exists in database.',
  'Nothing found based on search criteria',
  'Please specify subject, message and at least 1 account',
  'A problem has occurred with the server request.<br><br>Please try again or view the logs to see if an error has been logged preventing the ajax request completing.',
  'System Error',
  'Please specify at least 1 track',
  'Please enter valid email address..',
  'Please enter valid email address and password..',
  'No active account found, please try again..',
  '<br><br>If uploading MaxMind CSVs, make sure the "<b>post_max_size</b>" &amp; "<b>upload_max_filesize</b>" values in your PHP.ini file are greater than the combined size of all 3 MaxMind CSV files',
  '<i class="fas fa-exclamation fa-fw"></i> The free version of {script_name} allows <b>{limit}</b> collections only.<br><br>If you want to add more, please consider a commercial licence.<br><br><i class="fas fa-shopping-cart fa-fw"></i> <a href="?p=purchase">Purchase {script_name}</a><br><br><i class="fas fa-cubes fa-fw"></i> <a href="https://www.{script_url}/features.html">{script_name} Feature Matrix</a>',
  '<i class="fas fa-exclamation fa-fw"></i> The free version of {script_name} allows <b>{limit}</b> tracks only.<br><br>If you want to add more, please consider a commercial licence.<br><br><i class="fas fa-shopping-cart fa-fw"></i> <a href="?p=purchase">Purchase {script_name}</a><br><br><i class="fas fa-cubes fa-fw"></i> <a href="https://www.{script_url}/features.html">{script_name} Feature Matrix</a>',
  'Clear ALL history. Are you sure?',
  'Please accept our terms and conditions, thank you',
  'Please locate CSV file and specify at least 1 style..',
  'Please locate CSV file and specify the destination collection..',
  'Preview file not set'
);

?>