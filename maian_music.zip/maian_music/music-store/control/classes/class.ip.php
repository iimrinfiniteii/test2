<?php

/* Class File
----------------------------------------------------------*/

include(MM_BASE_PATH . 'control/lib/maxmind/autoload.php');
use MaxMind\Db\Reader;

class geoIP extends db {

  public $settings;

  public function lookup($ip,$lang) {
    $ar = array(
      'country' => $lang,
      'iso' => ''
    );
    // Check for localhost..
    if (in_array($ip, array('127.0.0.1','::1'))) {
      $ar = array(
        'country' => 'Localhost',
        'iso' => '1l'
      );
    } else {
      // Are GEO ip settings enabled?
      if ($this->settings->geoip == 'yes') {
        // Ipv4/Ipv6 detection..
        if (strpos($ip, ':') !== false) {
          $Q = db::db_query("SELECT `country`,`iso2` FROM `" . DB_PREFIX . "geo_ipv6`
               LEFT JOIN `" . DB_PREFIX . "countries`
               ON `" . DB_PREFIX . "geo_ipv6`.`country_iso` = `" . DB_PREFIX . "countries`.`iso2`
               WHERE HEX(INET6_ATON('" . mswSQL($ip, $this) . "')) BETWEEN HEX(INET6_ATON(`from_ip`)) AND HEX(INET6_ATON(`to_ip`))
               LIMIT 1
               ", true);
        } else {
          if (file_exists(MM_BASE_PATH . 'control/maxmind/GeoLite2-Country.mmdb')) {
            $reader = new Reader(MM_BASE_PATH . 'control/maxmind/GeoLite2-Country.mmdb');
            $data = $reader->get($ip);
            $reader->close();
            $geoID = (isset($data['country']['geoname_id']) ? (int) $data['country']['geoname_id'] : '0');
            $iso = (isset($data['country']['iso_code']) ? $data['country']['iso_code'] : 'xx');
            $Q = db::db_query("SELECT `name` AS `country`, `iso2` FROM `" . DB_PREFIX . "countries`
                 WHERE `geoname_id` = '{$geoID}'
                  OR LOWER(`iso2`) = '" . mswSQL(strtolower($iso), $this) . "'
                 LIMIT 1
                 ");
          }
        }
        if ($Q) {
          $IP = db::db_object($Q);
          if (isset($IP->country)) {
            $ar = array(
              'country' => $IP->country,
              'iso' => $IP->iso2
            );
          }
        }
      }
    }
    return $ar;
  }

  public function flag($data) {
    if ($data['iso']=='1l') {
      $string = '<i class="fas fa-th-large fa-fw" title="' . mswSH($data['country']) . '"></i> ' . ($data['showip'] == 'yes' ? $data['ip'] : '');
    } else {
      if ($data['iso']) {
        if ($data['conly'] == 'no' && file_exists(PATH . $data['path'] . $data['iso'] . '.png')) {
          $string = '<span style="background:url(' . $data['path'] . $data['iso'] . '.png) no-repeat left center;padding-left:20px" title="' . mswSH($data['country']) . '"></span> ' . ($data['showip'] == 'yes' ? $data['ip'] : '');
        } else {
          $string = '[' . mswSH($data['country']) . '] ' . ($data['showip'] == 'yes' ? $data['ip'] : '');
        }
      } else {
        $string = '<i class="fas fa-globe fa-fw" title="' . mswSH($data['unknown']) . '"></i> ' . ($data['showip'] == 'yes' ? $data['ip'] : '');
      }
    }
    return $string;
  }

}

?>