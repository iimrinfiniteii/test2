<?php

/* Gateway Class Controller File
----------------------------------------------------------*/

class mmGatewayController extends mmGateway {

  // Prefixed to file names..
  private $log_pfx  = '';

  public function __construct($info = array()) {
    $this->gwID     = $info['gwID'];
    $this->gwname   = $info['gwname'];
    $this->server   = $info['server'];
    $this->webpage  = $info['webpage'];
    $this->sandbox  = $info['sandbox'];
    $this->settings = $info['settings'];
    $this->account  = $info['account'];
    $this->lang     = $info['lang'];
    $this->iso4217  = (isset($info['iso4217']) ? $info['iso4217'] : array());
    $this->order    = array(
      'id' => $info['order']['id'],
      'code' => $info['order']['code'],
      'rcode' => (isset($info['order']['rcode']) ? $info['order']['rcode'] : '')
    );
    $this->seo      = $info['seo'];
    $this->hookevt  = array();
    $this->endpoints = array(
      'sandbox' => (isset($info['endpoints']['sandbox']) ? $info['endpoints']['sandbox'] : ''),
      'live' => (isset($info['endpoints']['live']) ? $info['endpoints']['live'] : '')
    );
  }

  public function payserver($type = '') {
    // Specific call..
    switch ($type) {
      case 'live':
        return $this->server;
        break;
      case 'sandbox':
        return $this->sandbox;
        break;
    }
    if ($this->endpoints['sandbox'] && $this->endpoints['live']) {
      if (isset($this->order['id']) && $this->order['id'] > 0) {
        $this->log($this->order['id'], 'Pinging endpoint: ' . ($this->settings->paymode == 'live' ? $this->endpoints['live'] : $this->endpoints['sandbox']));
      }
      return ($this->settings->paymode == 'live' ? $this->endpoints['live'] : $this->endpoints['sandbox']);
    }
    return ($this->settings->paymode == 'live' ? $this->server : $this->sandbox);
  }

  public function params() {
    $p = array();
    $q = db::db_query("SELECT * FROM `" . DB_PREFIX . "gateways_params`
         WHERE `gateway` = '{$this->gwID}'
         ORDER BY `id`
	   ");
    while ($PR = db::db_object($q)) {
      $p[$PR->param] = mswCD($PR->value);
    }
    return new ArrayObject($p);
  }

  public function log($id = 0, $debug = '') {
    if ($this->settings->responselog == 'yes' && is_dir(PATH . GW_LOG_FOLDER_NAME) && is_writeable(PATH . GW_LOG_FOLDER_NAME)) {
      $message = strtoupper(SCRIPT_NAME) . ' LOG @ ' . date("j F Y H:i:s") . mswNL();
      $message .= 'Database ID: ' . $id . mswNL();
      $message .= 'Action/Info: ' . $debug . mswNL();
      $message .= mswNL() . '= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =' . mswNL() . mswNL();
      // Attempt to create log directory if it doesn`t exist..
      if (!is_dir(PATH . GW_LOG_FOLDER_NAME)) {
        $oldumask = @umask(0);
        @mkdir(PATH . GW_LOG_FOLDER_NAME, 0777);
        @umask($oldumask);
      }
      // If it exists, write to it..
      if (is_dir(PATH . GW_LOG_FOLDER_NAME)) {
        $gate = preg_replace('/[^\w-]/', '', $this->gwname);
        $gate = str_replace(' ', '-', strtolower($gate));
        mswPUT(PATH . GW_LOG_FOLDER_NAME . '/' . $this->log_pfx . $gate . '-' . $id . '.log', $message);
      }
    }
  }

  // Clean post string and strip problematic characters..
  public function stripchars($string) {
    $s = array(
      '#',
      '\\',
      '>',
      '<',
      '"',
      '[',
      ']',
      '|'
    );
    return str_replace($s, '', $string);
  }

  // Transmits data back to gateway via curl..
  public function transmit($url, $fields = '') {
    if (isset($this->order['id']) && $this->order['id'] > 0) {
      $this->log($this->order['id'], 'Curl trigger confirmed: ' . $url);
    }
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
    curl_setopt($ch, CURLOPT_USERAGENT, 'PHP-Callback-Verification-Script');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
    curl_setopt($ch, CURLOPT_FORBID_REUSE, 1);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Connection: Close'));
    curl_setopt($ch, CURLOPT_CAINFO, dirname(__file__) . '/certs/cacert.pem');
    curl_setopt($ch, CURLOPT_TIMEOUT, 120);
    $r = curl_exec($ch);
    curl_close($ch);
    return $r;
  }

  public function getsale($id = 0, $code = '', $refcode = '') {
    $q  = db::db_query("SELECT *,
          (SELECT count(*) FROM `" . DB_PREFIX . "sales_items` WHERE `sale` = `" . DB_PREFIX . "sales`.`id` AND `type` = 'track') AS `trackCount`,
          (SELECT count(*) FROM `" . DB_PREFIX . "sales_items` WHERE `sale` = `" . DB_PREFIX . "sales`.`id` AND `type` = 'collection') AS `collectionCount`,
          (SELECT ROUND(SUM(`cost`),2) FROM `" . DB_PREFIX . "sales_items` WHERE `sale` = `" . DB_PREFIX . "sales`.`id`) AS `saleTotal`,
          `" . DB_PREFIX . "sales`.`id` AS `saleID`,
          `" . DB_PREFIX . "sales`.`shipping` AS `saleShipping`,
          `" . DB_PREFIX . "sales`.`enabled` AS `saleEnabled`,
          `" . DB_PREFIX . "sales`.`ip` AS `saleIP`
          FROM `" . DB_PREFIX . "sales`
          LEFT JOIN `" . DB_PREFIX . "accounts`
          ON  `" . DB_PREFIX . "accounts`.`id` = `" . DB_PREFIX . "sales`.`account`
          " . ($id > 0 ? 'WHERE `' . DB_PREFIX . 'sales`.`id` = \'' . $id . '\'' : '') . "
          " . ($code ? 'AND `' . DB_PREFIX . 'sales`.`code` = \'' . $code . '\'' : '') . "
          " . ($refcode ? 'WHERE `' . DB_PREFIX . 'sales`.`refcode` = \'' . $refcode . '\'' : ''));
    $SALE = db::db_object($q);
    // For guest checkout..
    if (isset($SALE->account) && $SALE->account == 0) {
      $SALE->name = $SALE->gname;
      $SALE->email = $SALE->gemail;
    }
    return (isset($SALE->saleID) ? $SALE : '');
  }

  public function firstLastName($input) {
    $string = explode(' ', $input);
    $other  = array();
    for ($i = 0; $i < count($string); $i++) {
      if ($i > 0) {
        $other[] = $string[$i];
      }
    }
    return array(
      'first-name' => $string[0],
      'last-name' => (!empty($other) ? implode(' ', $other) : '')
    );
  }

  public function gateAddr($country) {
    $a   = array();
    $a[] = mswCD($_POST['address1']);
    if ($_POST['address2']) {
      $a[] = mswCD($_POST['address2']);
    }
    $a[] = mswCD($_POST['city']);
    $a[] = mswCD($_POST['county']);
    $c   = mmGatewayController::country($country);
    $a[] = mswCD($c->name);
    return implode(mswNL(), $a);
  }

  public function country($id) {
    $id = (int) $id;
    $Q  = db::db_query("SELECT * FROM `" . DB_PREFIX . "countries` WHERE `id` = '{$id}'");
    return db::db_object($Q);
  }

  public function saletotal($sale) {
    // Was there a discount?
    if ($sale->coupon) {
      $cp = mswCD(unserialize($sale->coupon));
      if (isset($cp[0], $cp[1]) && $cp[1] > 0) {
        $discount = $cp[1];
      }
      $tot = ($sale->saleTotal > 0 ? mswFMPR($sale->saleTotal - $discount) : '0.00');
    } else {
      $tot = ($sale->saleTotal > 0 ? $sale->saleTotal : '0.00');
    }
    $tots  = ($sale->saleShipping > 0 ? $sale->saleShipping : '0.00');
    $totv  = ($sale->tax > 0 ? $sale->tax : '0.00');
    $totv2 = ($sale->tax2 > 0 ? $sale->tax2 : '0.00');
    $taxT  = mswFMPR($totv + $totv2);
    return $this->num_format(($tot + $tots + $taxT));
  }

  public function num_format($num) {
    return mswNFMDec($num, 2);
  }

  public function storeref($ref, $id) {
    db::db_query("UPDATE `" . DB_PREFIX . "sales` SET
    `refcode`    = '{$ref}'
    WHERE `id`   = '{$id}'
    ");
  }

  public function sysvalue($val, $id, $ref = '1') {
    $field = 'sys' . $ref;
    db::db_query("UPDATE `" . DB_PREFIX . "sales` SET
    `".$field."` = '".mswSQL($val, $this)."'
    WHERE `id`   = '{$id}'
    ");
  }

  // Build ppst data from input stream..
  public function postStream($str = array()) {
    $arr = array();
    if ($str['stream']) {
      foreach (explode($str['del'][0], $str['stream']) AS $var) {
        $params = explode($str['del'][1], $var);
        if (isset($params[0], $params[1])) {
          $arr[$params[0]] = urldecode($params[1]);
        }
      }
    }
    return $arr;
  }

  // Log gateway parameters..
  public function storeparams($id, $arr) {
    $p = array();
    if (!empty($arr)) {
      foreach ($arr AS $k => $v) {
        if (is_array($v)) {
          foreach ($v AS $k2 => $v2) {
            if (is_string($v2) && $v2) {
              $p[] = urldecode($k2) . '=>' . urldecode($v2);
            } else {
              if (is_array($v2)) {
                foreach ($v2 AS $k3 => $v3) {
                  if (is_string($v3) && $v3) {
                    $p[] = urldecode($k3) . '=>' . urldecode($v3);
                  }
                }
              }
            }
          }
        } else {
          $p[] = urldecode($k) . '=>' . urldecode($v);
        }
      }
      if (!empty($p)) {
        db::db_query("UPDATE `" . DB_PREFIX . "sales` SET
        `gateparams`  = '" . mswSQL(implode('<-->', $p), $this) . "'
        WHERE `id`    = '{$id}'
        AND (`gateparams` is null OR `gateparams` = '')
      ");
      }
    }
  }

}


?>