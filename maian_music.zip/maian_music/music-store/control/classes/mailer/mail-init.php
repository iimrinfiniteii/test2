<?php

/* MAIL OPERATIONS
   See notes below where applicable.

   DO NOT change this file unlessyou know what you are doing.
--------------------------------------------------------------------*/

if (!defined('PARENT')) { mswEcode($gblang[4],'403'); }
if (!defined('BASE_HREF')) { define('BASE_HREF', $SETTINGS->httppath); }

/* SMTP Parameters
----------------------------*/

$smtp = array(
  'smtp_host' => $SETTINGS->smtp_host,
  'smtp_port' => $SETTINGS->smtp_port,
  'smtp_user' => $SETTINGS->smtp_user,
  'smtp_pass' => $SETTINGS->smtp_pass,
  'smtp_security' => $SETTINGS->smtp_security,
  'smtp_certs' => $SETTINGS->smtp_certs,
  'smtp_protocol' => $SETTINGS->smtp_send,
  'smtp_debug' => $SETTINGS->smtp_debug,
  'alive' => (isset($alive) ? $alive : 'no')
);

/* Custom Mail Headers
--------------------------------------------------
   Key => Value pairs. Key must start X-

   $headers = array(
     'X-Header' => 'Value'
   );
--------------------------------------------------*/

$headers = array();

/* Mail Attachments
--------------------------------------------------
  Value = full attachment path

  $attachments = array(
    'c:\windows\attachment.jpg',
    'c:\windows\attachment2.jpg'
  );
--------------------------------------------------*/

$attachments = array();

/* Load Mail Class
-----------------------------------------------*/

include(MM_BASE_PATH . 'control/classes/mailer/class.mail.php');
$mmMail = new mailingSystem($smtp, $headers, $attachments);
$f_r = array(
  '{WEBSITE}'      => $SETTINGS->website,
  '{WEBSITE_URL}'  => BASE_HREF,
  '{ADMIN_FOLDER}' => MM_ADMIN_FOLDER
);

?>