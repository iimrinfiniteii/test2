<?php

/* Class File
----------------------------------------------------------*/

class cart extends db {

  public $settings;
  public $seo;
  public $datetime;
  public $costing;
  public $basketkey;
  public $guestkey;

  public function gwEn($gwclass) {
    $p = array('no', array());
    $q = db::db_query("SELECT * FROM `" . DB_PREFIX . "gateways`
         WHERE `class` = '{$gwclass}'
         AND `status` = 'yes'
         ");
    $G = db::db_object($q);
    if (isset($G->id)) {
      $q = db::db_query("SELECT * FROM `" . DB_PREFIX . "gateways_params`
           WHERE `gateway` = '{$G->id}'
           ORDER BY `id`
           ");
      while ($PR = db::db_object($q)) {
        switch($PR->param) {
          case 'image':
            $p[$PR->param] = (substr($PR->value, 0, 4) == 'http' ? mswCD($PR->value) : '');
            break;
          default:
            $p[$PR->param] = mswCD($PR->value);
            break;
        }
      }
      return array('yes', $p);
    }
    return $p;
  }

  public function taxBreakdown($b) {
    $breakdown = cart::basketItems($b, array(), true);
    $arr = array(
      'items' => $breakdown[2],
      'total' => mswCURF(mswFMPR($breakdown[0]), $this->settings->curdisplay),
      'coupon' => (isset($_SESSION[$this->basketkey][8][2]) ? mswCURF(mswFMPR($_SESSION[$this->basketkey][8][2]), $this->settings->curdisplay) : mswCURF(mswFMPR('0.00'), $this->settings->curdisplay)),
      'country' => (isset($_SESSION[$this->basketkey][7]) ? cart::country($_SESSION[$this->basketkey][7]) : '0'),
      'rate' => (isset($_SESSION[$this->basketkey][3]) && $_SESSION[$this->basketkey][3] > 0 ? $_SESSION[$this->basketkey][3] : '0'),
      'shipping' => (isset($_SESSION[$this->basketkey][1]) ? mswCURF(mswFMPR($_SESSION[$this->basketkey][1]), $this->settings->curdisplay) : mswCURF(mswFMPR('0.00'), $this->settings->curdisplay)),
      'amount' => (isset($_SESSION[$this->basketkey][2]) ? mswCURF(mswFMPR($_SESSION[$this->basketkey][2]), $this->settings->curdisplay) : mswCURF(mswFMPR('0.00'), $this->settings->curdisplay)),
      'ramount' => (isset($_SESSION[$this->basketkey][2]) && $_SESSION[$this->basketkey][2] > 0 ? $_SESSION[$this->basketkey][2] : '0.00'),
      'items2' => $breakdown[3],
      'total2' => mswCURF(mswFMPR($breakdown[1]), $this->settings->curdisplay),
      'coupon2' => (isset($_SESSION[$this->basketkey][8][3]) ? mswCURF(mswFMPR($_SESSION[$this->basketkey][8][3]), $this->settings->curdisplay) : mswCURF(mswFMPR('0.00'), $this->settings->curdisplay)),
      'country2' => (isset($_SESSION[$this->basketkey][9]) ? cart::country($_SESSION[$this->basketkey][9]) : '0'),
      'rate2' => (isset($_SESSION[$this->basketkey][5]) && $_SESSION[$this->basketkey][5] > 0 ? $_SESSION[$this->basketkey][5] : '0'),
      'amount2' => (isset($_SESSION[$this->basketkey][4]) ? mswCURF(mswFMPR($_SESSION[$this->basketkey][4]), $this->settings->curdisplay) : mswCURF(mswFMPR('0.00'), $this->settings->curdisplay)),
      'ramount2' => (isset($_SESSION[$this->basketkey][4]) && $_SESSION[$this->basketkey][4] > 0 ? $_SESSION[$this->basketkey][4] : '0.00')
    );
    $arr['total-tax'] = mswCURF(mswFMPR($arr['ramount'] + $arr['ramount2']), $this->settings->curdisplay);
    return $arr;
  }

  public function coupon($coupon, $account) {
    $arr = array(
      'invalid',
      ''
    );
    $now = $this->datetime->utcTime();
    $Q   = db::db_query("SELECT * FROM `" . DB_PREFIX . "coupons` WHERE `code` = '" . mswSQL($coupon, $this) . "' LIMIT 1");
    $CP  = db::db_object($Q);
    if (isset($CP->id) && $CP->enabled == 'yes') {
      $acc = ($CP->accounts ? explode(',', $CP->accounts) : '');
      if (!empty($acc) && !in_array($account, $acc)) {
        $arr = array(
          'invalid',
          ''
        );
      } else {
        if ($CP->expiry > 0 && date('Y-m-d', $CP->expiry) < date('Y-m-d', $now)) {
          $arr = array(
            'expired',
            $this->datetime->dateTimeDisplay($CP->expiry, $this->settings->dateformat)
          );
        } else {
          $arr = array(
            'ok',
            $CP->discount
          );
        }
      }
    }
    return $arr;
  }

  public function country($id) {
    $Q  = db::db_query("SELECT `name` FROM `" . DB_PREFIX . "countries` WHERE `id` = '{$id}'");
    $CN = db::db_object($Q);
    return (isset($CN->name) ? $CN->name : 'N/A');
  }

  public function totals($sale) {
    $t = array('0.00', '0.00');
    $Q = db::db_query("SELECT ROUND(SUM(`cost`), 2) AS `d` FROM `" . DB_PREFIX . "sales_items`
         WHERE `sale` = '{$sale}'
         AND `physical` = 'no'
         ");
    $D = db::db_object($Q);
    $Q = db::db_query("SELECT ROUND(SUM(`cost`), 2) AS `t` FROM `" . DB_PREFIX . "sales_items`
         WHERE `sale` = '{$sale}'
         AND `physical` = 'yes'
         ");
    $T = db::db_object($Q);
    return array(
      'digital' => mswCURF((isset($D->d) ? $D->d : $t[0]), $this->settings->curdisplay),
      'tangible' => mswCURF((isset($T->t) ? $T->t : $t[1]), $this->settings->curdisplay),
      'digital-raw' => (isset($D->d) ? $D->d : $t[0]),
      'tangible-raw' => (isset($T->t) ? $T->t : $t[1])
    );
  }

  public function music($b, $sale = array(), $type, $l) {
    $html = '';
    $ics  = array(0,0);
    $Q    = db::db_query("SELECT * FROM `" . DB_PREFIX . "sales_items`
            WHERE `sale` = '{$sale[0]}'
            " . ($type == 'shipped' ? 'AND `physical` = \'yes\'' : 'AND `physical` = \'no\'') . "
            ORDER BY FIELD(`type`,'collection','track'),`id` DESC
            ");
    while ($M = db::db_object($Q)) {
      // Type options..
      switch ($M->type) {
        case 'collection':
          $Q_C  = db::db_query("SELECT `id`,`slug`,`name`,`coverart`,`cost`,`costcd`,`bitrate`,`length` FROM `" . DB_PREFIX . "collections` WHERE `id` = '{$M->item}'");
          $COL  = db::db_object($Q_C);
          $info = array(
            'col' => mswSH($COL->name),
            'det' => ($M->physical == 'yes' ? $l[14] : str_replace(array(
              '{rate}',
              '{length}'
            ), array(
              $COL->bitrate,
              mswTrimTime($COL->length)
            ), $l[16]))
          );
          if ($M->physical == 'yes') {
            ++$ics[0];
          } else {
            ++$ics[1];
          }
          break;
        default:
          $Q_T = db::db_query("SELECT `collection`,`title`,`cost`,`bitrate`,`length` FROM `" . DB_PREFIX . "music` WHERE `id` = '{$M->item}'");
          $CTK = db::db_object($Q_T);
          if (isset($CTK->title)) {
            $Q_C  = db::db_query("SELECT `id`,`slug`,`name`,`coverart` FROM `" . DB_PREFIX . "collections` WHERE `id` = '{$CTK->collection}'");
            $COL  = db::db_object($Q_C);
            $info = array(
              'col' => mswSH($COL->name),
              'det' => str_replace(array(
                '{name}',
                '{rate}',
                '{length}'
              ), array(
                mswSH($CTK->title),
                $CTK->bitrate,
                mswTrimTime($CTK->length)
              ), $l[15])
            );
            ++$ics[1];
          }
          break;
      }
      if (isset($info['col'])) {
        // Build url..
        $url = array(
          'seo' => array(
            ($COL->slug ? $COL->slug : $this->seo->filter($COL->name)),
            ($COL->slug == '' ? $COL->id : '')
          ),
          'standard' => array(
            'id' => $COL->id
          )
        );
        // Load template..
        $fr  = array(
          '{url}' => BASE_HREF . $this->seo->url('collection', $url),
          '{coverart}' => BASE_HREF . $b->cover($COL->coverart),
          '{collection}' => $info['col'],
          '{detail}' => $info['det'],
          '{size}' => '',
          '{cost}' => mswCURF($M->cost, $this->settings->curdisplay),
          '{id}' => $M->id . (defined('IS_GUEST_VIEW') ? '-' . $sale[1] : ''),
          '{txt}' => mswJS($l[25]),
          '{path}' => 'content/' . THEME . '/'
        );
        $html .= $b->template($fr, 'order-detail-item-' . $type . '.tpl');
      }
    }
    return array($html, $ics);
  }

  public function orders($b, $id, $limit = 0, $pagelimit = array(), $justrows = false) {
    $html   = '';
    $Q      = db::db_query("SELECT SQL_CALC_FOUND_ROWS *,
              (SELECT `display` FROM `" . DB_PREFIX . "gateways` WHERE `id` = `" . DB_PREFIX . "sales`.`gateway`) AS `paymentMethod`,
              (SELECT ROUND(SUM(`cost`),2) FROM `" . DB_PREFIX . "sales_items` WHERE `sale` = `" . DB_PREFIX . "sales`.`id`) AS `saleTotal`
              FROM `" . DB_PREFIX . "sales`
              WHERE `account` = '{$id}'
              AND `enabled`   = 'yes'
              ORDER BY `id` DESC
              " . ($limit > 0 ? 'LIMIT ' . $limit : '') . "
              " . (isset($pagelimit[0]) && $pagelimit[0] > 0 ? 'LIMIT ' . $pagelimit[0] . ',' . $pagelimit[1] : ''));
    $c      = db::db_object(db::db_query("SELECT FOUND_ROWS() AS `rows`"));
    $cnRows = (isset($c->rows) ? $c->rows : '0');
    if ($justrows) {
      return $cnRows;
    }
    while ($ORD = db::db_object($Q)) {
      if ($ORD->coupon) {
        $discount = '0.00';
        $cp = mswCD(unserialize($ORD->coupon));
        if (isset($cp[0], $cp[1]) && $cp[1] > 0) {
          $discount = $cp[1];
        }
        $tot = ($ORD->saleTotal > 0 ? mswFMPR($ORD->saleTotal - $discount) : '0.00');
      } else {
        $tot = ($ORD->saleTotal > 0 ? $ORD->saleTotal : '0.00');
      }
      $tots  = ($ORD->shipping > 0 ? $ORD->shipping : '0.00');
      $totv  = ($ORD->tax > 0 ? $ORD->tax : '0.00');
      $totv2 = ($ORD->tax2 > 0 ? $ORD->tax2 : '0.00');
      $taxT  = mswFMPR($totv + $totv2);
      // Build url..
      $url  = array(
        'seo' => array(
          mswINV($ORD->id)
        ),
        'standard' => array(
          '#' => mswINV($ORD->id)
        )
      );
      $fr   = array(
        '{url}' => BASE_HREF . $this->seo->url('view-order', $url),
        '{invoice_no}' => mswINV($ORD->invoice),
        '{date}' => $this->datetime->dateTimeDisplay($ORD->ts, $this->settings->dateformat),
        '{method}' => (isset($ORD->paymentMethod) ? $ORD->paymentMethod : 'N/A'),
        '{total}' => mswCURF(($tot + $tots + $taxT), $this->settings->curdisplay)
      );
      $html .= $b->template($fr, 'order-item.tpl');
    }
    return $html;
  }

  public function add($data = array()) {
    if (!isset($_SESSION['cartItems'])) {
      $_SESSION['cartItems'] = array();
    }
    $_SESSION['cartItems'][] = array(
      'collection' => $data['collection'],
      'cost' => $data['cost'],
      'discount' => $data['discount'],
      'type' => $data['type'],
      'tracks' => $data['tracks'],
      'void' => 'no'
    );
  }

  public function basketItems($b, $lang = array(), $totals = false) {
    $html     = '';
    $taxgoods = array('0.00','0.00',0,0);
    if (!empty($_SESSION['cartItems'])) {
      for ($i = 0; $i < count($_SESSION['cartItems']); $i++) {
        if ($_SESSION['cartItems'][$i]['void'] == 'no') {
          $TS = array();
          $ID = (int) $_SESSION['cartItems'][$i]['collection'];
          $Q  = db::db_query("SELECT `name`,`coverart`,`slug` FROM `" . DB_PREFIX . "collections` WHERE `enabled` = 'yes' AND `id` = '{$ID}'");
          $C  = db::db_object($Q);
          // Change detail for tracks..
          if (!empty($_SESSION['cartItems'][$i]['tracks']) && !empty($lang)) {
            $QT = db::db_query("SELECT `title`,`length`,`bitrate`,`cost` FROM `" . DB_PREFIX . "music`
                  WHERE `id`       IN(" . mswSQL(implode(',', array_keys($_SESSION['cartItems'][$i]['tracks'])), $this) . ")
                  AND `collection`  = '{$ID}'
                  ORDER BY `order`
                  ");
            while ($TR = db::db_object($QT)) {
              $disc = $this->costing->offer($TR->cost, 'track', $ID);
              $t_fr = array(
                '{track}' => str_replace(array(
                  '{track}',
                  '{length}',
                  '{bitrate}',
                  '{cost}'
                ), array(
                  mswSH($TR->title),
                  mswTrimTime($TR->length),
                  $TR->bitrate,
                  mswCURF(($disc != 'no' && $disc != $TR->cost ? $disc : $TR->cost), $this->settings->curdisplay)
                ), $lang[23])
              );
              $TS[] = $b->template($t_fr, 'basket-item-track.tpl');
            }
          }
          // Build url..
          $url = array(
            'seo' => array(
              ($C->slug ? $C->slug : $this->seo->filter($C->name)),
              ($C->slug == '' ? $ID : '')
            ),
            'standard' => array(
              'id' => $ID
            )
          );
          if (isset($C->name)) {
            if (!empty($lang)) {
              $countData = ($_SESSION['cartItems'][$i]['type'] == 'CD' ? $lang[24] : $lang[22]);
              $countData = str_replace('{count}',cart::colTrackCount($ID),$countData);
              $fr = array(
                '{slot}' => $i,
                '{image}' => BASE_HREF . $b->cover($C->coverart),
                '{url}' => BASE_HREF . $this->seo->url('collection', $url),
                '{item}' => mswSH($C->name),
                '{detail}' => (!empty($TS) ? implode(mswNL(), $TS) : $countData),
                '{cost}' => mswCURF(($_SESSION['cartItems'][$i]['discount'] != 'no' && $_SESSION['cartItems'][$i]['discount'] != $_SESSION['cartItems'][$i]['cost'] ? $_SESSION['cartItems'][$i]['discount'] : $_SESSION['cartItems'][$i]['cost']), $this->settings->curdisplay)
              );
              $html .= $b->template($fr, 'basket-item.tpl');
            }
            // Totals..
            if ($_SESSION['cartItems'][$i]['type'] == 'CD') {
              ++$taxgoods[2];
              $taxgoods[0] = mswFMPR($taxgoods[0] + ($_SESSION['cartItems'][$i]['discount'] != 'no' && $_SESSION['cartItems'][$i]['discount'] != $_SESSION['cartItems'][$i]['cost'] ? $_SESSION['cartItems'][$i]['discount'] : $_SESSION['cartItems'][$i]['cost']));
            } else {
              if (empty($_SESSION['cartItems'][$i]['tracks'])) {
                ++$taxgoods[3];
              } else {
                $taxgoods[3] += count($_SESSION['cartItems'][$i]['tracks']);
              }
              $taxgoods[1] = mswFMPR($taxgoods[1] + ($_SESSION['cartItems'][$i]['discount'] != 'no' && $_SESSION['cartItems'][$i]['discount'] != $_SESSION['cartItems'][$i]['cost'] ? $_SESSION['cartItems'][$i]['discount'] : $_SESSION['cartItems'][$i]['cost']));
            }
          }
        }
      }
    }
    // Return breakdown totals..
    if ($totals) {
      return $taxgoods;
    }
    return $html;
  }

  public function colTrackCount($col) {
    $cnt = 0;
    $Q   = db::db_query("SELECT count(*) AS `trackCount` FROM `" . DB_PREFIX . "music` WHERE `collection` = '{$col}'");
    $C   = db::db_object($Q);
    if (isset($C->trackCount)) {
      return $C->trackCount;
    }
    return $cnt;
  }

  public function modalItems($b, $lang) {
    $html    = '';
    $wrapper = $b->template(array(), 'modal-basket.tpl');
    if (!empty($_SESSION['cartItems'])) {
      for ($i = 0; $i < count($_SESSION['cartItems']); $i++) {
        if ($_SESSION['cartItems'][$i]['void'] == 'no') {
          $TS = array();
          $ID = (int) $_SESSION['cartItems'][$i]['collection'];
          $Q  = db::db_query("SELECT `name`,`coverart`,`slug` FROM `" . DB_PREFIX . "collections` WHERE `enabled` = 'yes' AND `id` = '{$ID}'");
          $C  = db::db_object($Q); // Change detail for tracks..
          if (!empty($_SESSION['cartItems'][$i]['tracks'])) {
            $QT = db::db_query("SELECT `title`,`length`,`bitrate`,`cost` FROM `" . DB_PREFIX . "music`
                  WHERE `id`       IN(" . mswSQL(implode(',', array_keys($_SESSION['cartItems'][$i]['tracks'])), $this) . ")
                  AND `collection`  = '{$ID}'
                  ORDER BY `order`
                  ");
            while ($TR = db::db_object($QT)) {
              $disc = $this->costing->offer($TR->cost, 'track', $ID);
              $t_fr = array(
                '{track}' => str_replace(array(
                  '{track}',
                  '{length}',
                  '{bitrate}',
                  '{cost}'
                ), array(
                  mswSH($TR->title),
                  mswTrimTime($TR->length),
                  $TR->bitrate,
                  mswCURF(($disc != 'no' && $disc != $TR->cost ? $disc : $TR->cost), $this->settings->curdisplay)
                ), $lang[6])
              );
              $TS[] = $b->template($t_fr, 'basket-item-track.tpl');
            }
          }
          // Build url..
          $url = array(
            'seo' => array(
              ($C->slug ? $C->slug : $this->seo->filter($C->name)),
              ($C->slug == '' ? $ID : '')
            ),
            'standard' => array(
              'id' => $ID
            )
          );
          if (isset($C->name)) {
            $countData = ($_SESSION['cartItems'][$i]['type'] == 'CD' ? $lang[24] : $lang[22]);
            $countData = str_replace('{count}',cart::colTrackCount($ID),$countData);
            $fr = array(
              '{slot}' => $i,
              '{image}' => BASE_HREF . $b->cover($C->coverart),
              '{url}' => BASE_HREF . $this->seo->url('collection', $url),
              '{item}' => mswSH($C->name),
              '{detail}' => (!empty($TS) ? implode(mswNL(), $TS) : $countData),
              '{cost}' => mswCURF(($_SESSION['cartItems'][$i]['discount'] != 'no' && $_SESSION['cartItems'][$i]['discount'] != $_SESSION['cartItems'][$i]['cost'] ? $_SESSION['cartItems'][$i]['discount'] : $_SESSION['cartItems'][$i]['cost']), $this->settings->curdisplay)
            );
            $html .= $b->template($fr, 'modal-basket-item.tpl');
          }
        }
      }
    }
    return str_replace(array(
      '{items}',
      '{count}',
      '{text}',
      '{text2}',
      '{text3}',
      '{cost}',
      '{url}'
    ), array(
      $html,
      cart::count(),
      $lang[27],
      $lang[29],
      $lang[28],
      mswCURF(cart::total(), $this->settings->curdisplay),
      BASE_HREF . $this->seo->url('basket', array(), 'yes')
    ), $wrapper);
  }

  public function total() {
    $t = '0.00';
    if (!empty($_SESSION['cartItems'])) {
      for ($i = 0; $i < count($_SESSION['cartItems']); $i++) {
        if ($_SESSION['cartItems'][$i]['void'] == 'no') {
          $n = ($_SESSION['cartItems'][$i]['discount'] != 'no' && $_SESSION['cartItems'][$i]['discount'] != $_SESSION['cartItems'][$i]['cost'] ? $_SESSION['cartItems'][$i]['discount'] : $_SESSION['cartItems'][$i]['cost']);
          $t = mswFMPR(($t + $n));
        }
      }
    }
    return $t;
  }

  public function getTax($b, $country = 0, $type, $shipping = '0.00', $discount = array()) {
    $t         = '0.00';
    $tr        = '0';
    $dcnt      = '0.00';
    $cn        = ($type == 'tangible' ? $this->settings->defCountry : $this->settings->defCountry2);
    $breakdown = cart::basketItems($b, array(), true);
    $grandTot  = mswFMPR($breakdown[0] + $breakdown[1]);
    switch($type) {
      case 'tangible':
        // Was coupon applied..
        if (isset($discount[0]) && $discount[0] != 'no') {
          // Get percentage. If fixed, get percentage of total for fixed discount..
          switch(substr($discount[0],-1)) {
            case '%':
              $dperc = substr($discount[0], 0, -1);
              break;
            default:
              $dperc = mswNFMDec(($discount[0] / $grandTot) * 100, 5);
              break;
          }
          $dcnt  = mswFMPR(($dperc * $breakdown[0]) / 100);
          $total = mswFMPR(($breakdown[0] - $dcnt) + $shipping);
        } else {
          $total = mswFMPR($breakdown[0] + $shipping);
        }
        // Country overrides..
        if ($country > 0) {
          $Q = db::db_query("SELECT `tax` FROM `" . DB_PREFIX . "countries` WHERE `id` = '" . mswSQL($country, $this) . "'");
          $R = db::db_object($Q);
          if (isset($R->tax)) {
            // Is tax explicitly off for this country?
            if (strtolower($R->tax) == 'no') {
              $sum = mswFMPR($total / 100);
              $t   = mswFMPR('0.00', 2, '.', '');
              $tr  = '0%';
              $cn  = $country;
            } else {
              // Check country rate..
              if ($R->tax > 0) {
                $sum = mswFMPR($R->tax * $total / 100);
                $t   = mswFMPR($sum, 2, '.', '');
                $tr  = $R->tax . '%';
                $cn  = $country;
              } else {
                // Set fixed rate if applicable..
                if ($this->settings->deftax > 0) {
                  $sum = mswFMPR($this->settings->deftax * $total / 100);
                  $t   = mswFMPR($sum, 2, '.', '');
                  $tr  = $this->settings->deftax . '%';
                  $cn  = $this->settings->defCountry;
                }
              }
            }
          }
        } else {
          // Set fixed rate if applicable..
          if ($this->settings->deftax > 0) {
            $sum = mswFMPR($this->settings->deftax * $total / 100);
            $t   = mswFMPR($sum, 2, '.', '');
            $tr  = $this->settings->deftax . '%';
            $cn  = $this->settings->defCountry;
          }
        }
        break;
      case 'digital':
        // Was coupon applied..
        if (isset($discount[0]) && $discount[0] != 'no') {
          // Get percentage. If fixed, get percentage of total for fixed discount..
          switch(substr($discount[0],-1)) {
            case '%':
              $dperc = substr($discount[0], 0, -1);
              break;
            default:
              $dperc = mswNFMDec(($discount[0] / $grandTot) * 100, 5);
              break;
          }
          $dcnt  = mswFMPR(($dperc * $breakdown[1]) / 100);
          $total = mswFMPR($breakdown[1] - $dcnt);
        } else {
          $total = $breakdown[1];
        }
        // Country overrides..
        if ($country > 0) {
          $Q = db::db_query("SELECT `tax2` FROM `" . DB_PREFIX . "countries` WHERE `id` = '" . mswSQL($country, $this) . "'");
          $R = db::db_object($Q);
          if (isset($R->tax2)) {
            // Is tax explicitly off for this country?
            if (strtolower($R->tax2) == 'no') {
              $sum = mswFMPR($total / 100);
              $t   = mswFMPR('0.00', 2, '.', '');
              $tr  = '0%';
              $cn  = $country;
            } else {
              // Check country rate..
              if ($R->tax2 > 0) {
                $sum = mswFMPR($R->tax2 * $total / 100);
                $t   = mswFMPR($sum, 2, '.', '');
                $tr  = $R->tax2 . '%';
                $cn  = $country;
              } else {
                // Set fixed rate if applicable..
                if ($this->settings->deftax2 > 0) {
                  $sum = mswFMPR($this->settings->deftax2 * $total / 100);
                  $t   = mswFMPR($sum, 2, '.', '');
                  $tr  = $this->settings->deftax2 . '%';
                  $cn  = $this->settings->defCountry2;
                }
              }
            }
          }
        } else {
          // Set fixed rate if applicable..
          if ($this->settings->deftax2 > 0) {
            $sum = mswFMPR($this->settings->deftax2 * $total / 100);
            $t   = mswFMPR($sum, 2, '.', '');
            $tr  = $this->settings->deftax2 . '%';
            $cn  = $this->settings->defCountry2;
          }
        }
        break;
    }
    return array(
      $t,
      $tr,
      $cn,
      $dcnt
    );
  }

  public function getShipping($total, $method) {
    $c = '0.00';
    if (cart::isShipping() == 'yes') {
      $Q = db::db_query("SELECT * FROM `" . DB_PREFIX . "shipping` WHERE `id` = '{$method}'");
      $R = db::db_object($Q);
      if (isset($R->id)) {
        switch (substr($R->cost, -1)) {
          case '%':
            $per = substr($R->cost, 0, -1);
            $sum = mswFMPR($per * $total / 100);
            $c   = mswFMPR($sum, 2, '.', '');
            break;
          default:
            $c = $R->cost;
            break;
        }
      }
    }
    return $c;
  }

  public function isShipping() {
    if (!isset($_SESSION['cartItems'])) {
      return 'no';
    }
    for ($i = 0; $i < count($_SESSION['cartItems']); $i++) {
      if ($_SESSION['cartItems'][$i]['void'] == 'no' && $_SESSION['cartItems'][$i]['type'] == 'CD') {
        return 'yes';
      }
    }
    return 'no';
  }

  public function count() {
    $cnt = 0;
    if (!isset($_SESSION['cartItems'])) {
      return '0';
    }
    for ($i = 0; $i < count($_SESSION['cartItems']); $i++) {
      if ($_SESSION['cartItems'][$i]['void'] == 'no') {
        if (!empty($_SESSION['cartItems'][$i]['tracks'])) {
          $cnt = ($cnt + count($_SESSION['cartItems'][$i]['tracks']));
        } else {
          ++$cnt;
        }
      }
    }
    return $cnt;
  }

  public function clear() {
    $_SESSION['cartItems'] = array();
    $_SESSION[$this->basketkey] = array();
    $_SESSION[$this->guestkey] = array();
    unset($_SESSION['cartItems'], $_SESSION[$this->basketkey], $_SESSION[$this->guestkey]);
  }

}

?>