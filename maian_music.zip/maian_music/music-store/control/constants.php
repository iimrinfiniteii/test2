<?php

/* CONSTANTS
   Edit values on right, DO NOT change values in capitals
-------------------------------------------------------------*/

define('SCRIPT_VERSION', '2.7');
define('MSW_PHP_MIN_VER', '5.5');
define('SCRIPT_NAME', 'Maian Music');
define('SCRIPT_ID', 14);
define('SCRIPT_URL', 'maianmusic.com');
define('SCRIPT_RELEASE_YR', '2007');
define('SCRIPT_DESC', 'PHP Music Ecommerce System');

define('GLOBAL_PATH', substr(dirname(__file__), 0, strpos(dirname(__file__), 'control')-1) . '/');
define('MSW_PHP', (version_compare(PHP_VERSION, '7.1.0', '<') ? 'old' : 'new'));

?>