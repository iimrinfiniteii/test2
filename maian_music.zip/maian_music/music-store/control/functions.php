<?php

/* Functions
----------------------------------------------------------*/

if (!defined('PARENT')) {
  mswEcode($gblang[4], '403');
}

//---------------------------------
// Check tag reader file name
//---------------------------------

function mswCheckUnicodeTitle($t) {
  return (strstr($t, '????') ? '' : $t);
}

//---------------------------------
// Memory Overrides
//---------------------------------

function mswTO($m = '100', $l = 0) {
  @ini_set('memory_limit', $m . 'M');
  @set_time_limit($l);
}

//---------------------------------
// Template loader
//---------------------------------

function mswTmp($path, $loaded = 'no') {
  switch($loaded) {
    case 'ok':
      return file_get_contents($path);
      break;
    case 'no':
      return (file_exists($path) ? file_get_contents($path) : die('<div style="padding:10px;background:#ff9999;color:#fff;border:1px solid #555">[LOAD ERROR] Template file "' . $path . '" is missing!<br><br>Check your anti virus software hasn`t quarantined the file. Try adding the file again from the latest download zip.</div>'));
      break;
  }
}

//--------------------------------
// Sanitize user input
//--------------------------------

function mswSanitize($data) {
  return str_replace(array('<script>', '</script>'), array('&lt;script&gt;', '&lt;/script&gt;'), $data);
}

//---------------------------------
// Query string management
//---------------------------------

function qStringBuilder($skip = array()) {
  $qstring = array();
  if (!empty($_GET)) {
    foreach ($_GET AS $k => $v) {
      if (!in_array($k, $skip)) {
        $qstring[] = $k . '=' . mswSH(urlencode($v));
      }
    }
  }
  return (!empty($qstring) ? '&amp;' . implode('&amp;', $qstring) : '');
}

function qStringSelector($param,$value) {
  return (isset($_GET[$param]) && $_GET[$param] == $value ? ' selected="selected"' : '');
}

//-----------------------------------
// Accepted params
//-----------------------------------

function mswAcceptedParams() {
  return array(
    'home',
    'category',
    'product',
    'latest',
    'popular',
    'specials',
    'search',
    'support',
    'account',
    'basket',
    'style',
    '404',
    'profile',
    'page',
    'collection',
    'orders',
    'logout',
    'view-order',
    'view-guest-order',
    'login',
    'cancel',
    'success',
    'create',
    'check',
    '_ajax',
    'pg',
    'verify',
    'download',
    'message',
    'response'
  );
}

//-----------------------------------
// Overrides for certain params
//-----------------------------------

function mswParamOverRide($cmd, $seo) {
  $sef = array_flip($seo->converter('', true));
  if (isset($_GET['style'])) {
    return 'style';
  }
  if (isset($_GET['404'])) {
    return '404';
  }
  if (isset($_GET['music'])) {
    return 'home';
  }
  if (isset($_GET['ajax'])) {
    return '_ajax';
  }
  if (isset($_GET['collection'])) {
    $cmd = 'collection';
  }
  if (isset($_GET['style'])) {
    $cmd = 'style';
  }
  if (isset($_GET['view-order'])) {
    $cmd = 'view-order';
  }
  if (isset($_GET['view-guest-order'])) {
    $cmd = 'view-guest-order';
  }
  if (isset($_GET['search'])) {
    $cmd = 'search';
  }
  if (isset($_GET['pg'])) {
    $cmd = 'pg';
  }
  if (isset($_GET['ve'])) {
    $cmd = 'verify';
  }
  if (isset($_GET['dmf'])) {
    $cmd = 'download';
  }
  if (isset($_GET['msg'])) {
    $cmd = 'message';
  }
  if (isset($_GET['gw'])) {
    $cmd = 'response';
  }
  if (isset($_GET['orders'])) {
    $cmd = 'orders';
  }
  if (substr($cmd,0,3) == 'rss') {
    $cmd = 'rss';
  }
  // Must be last, checks for url name overrides..
  if (isset($sef[$cmd])) {
    $cmd = $sef[$cmd];
  }
  return $cmd;
}

//-----------------------------------
// Check valid email..
//-----------------------------------

function mswIsValidEmail($em) {
  if ($em == '') {
    return 'no';
  } else {
    if (function_exists('filter_var') && !filter_var($em, FILTER_VALIDATE_EMAIL)) {
      return 'no';
    } else {
      // HTML5 spec..
      if (!preg_match('/^[a-zA-Z0-9.!#$%&\'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}' .
        '[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/sD', $em)) {
        return 'no';
      }
    }
  }
  return 'ok';
}

//--------------------------
// Trim Time Display
//--------------------------

function mswTrimTime($t) {
  global $msw_public_int_2_5;
  $lg = explode(',', $msw_public_int_2_5[9]);
  if (isset($lg[0], $lg[1], $lg[2])) {
    $h = $lg[0];
    $m = $lg[1];
    $s = $lg[2];
  } else {
    $h = 'h';
    $m = 'm';
    $s = 's';
  }
  $l = explode(':', $t);
  if (isset($l[0], $l[1], $l[2])) {
    $t = ($l[0] > 0 ? ltrim($l[0], '0') . $h : '') . ($l[1] > 0 ? ' ' . ltrim($l[1], '0') . $m : '') . ($l[2] > 0 ? ' ' . ltrim($l[2], '0') . $s : '');
  }
  if (isset($l[0], $l[1]) && !isset($l[2])) {
    $t = ($l[0] > 0 ? ltrim($l[0], '0') . $m : '') . ($l[1] > 0 ? ' ' . ltrim($l[1], '0') . $s : '');
  }
  return trim($t);
}

//--------------------------
// Load cover art
//--------------------------

function mswCoverArtLoader($art, $path, $area = 'admin') {
  switch ($area) {
    case 'admin':
      if ($art && file_exists(MM_BASE_PATH . COVER_ART_FOLDER . '/' . $art)) {
        return $path . COVER_ART_FOLDER . '/' . $art;
      } else {
        return 'templates/images/tempart.png';
      }
      break;
    default:
      break;
  }
}

//---------------------------------------------------
// Get status
//---------------------------------------------------

function mswGetStatus($flag, $l) {
  return ($flag == 'yes' ? '<span class="msw-green">' . mswSH($l[36]) . '</span>' : '<span class="msw-red">' . mswSH($l[37]) . '</span>');
}

//----------------------------
// DB Schema..
//----------------------------

function mswDBSchemaArray($db) {
  $tbl = array();
  if (strlen(DB_PREFIX) > 0) {
    $q = $db->db_query("SHOW TABLES WHERE SUBSTRING(`Tables_in_" . DB_NAME . "`,1," . strlen(DB_PREFIX) . ") = '" . DB_PREFIX . "'");
  } else {
    $q = $db->db_query("SHOW TABLES");
  }
  while ($TABLES = $db->db_object($q)) {
    $field = 'Tables_in_' . DB_NAME;
    $tbl[] = $TABLES->{$field};
  }
  return $tbl;
}

//---------------------------------------------------
// Shipping Address
//---------------------------------------------------

function mswShippingAddress($id, $db_obj) {
  $ship = 'N/A';
  $Q    = $db_obj->db_query("SELECT count(*) AS `cd_count` FROM `" . DB_PREFIX . "sales_items`
          WHERE `sale`   = '{$id}'
          AND `physical` = 'yes'
		      ");
  $SI   = $db_obj->db_object($Q);
  if (isset($SI->cd_count) && $SI->cd_count > 0) {
    $Q2   = $db_obj->db_query("SELECT `shippingAddr` FROM `" . DB_PREFIX . "sales`
            WHERE `id` = '{$id}'
            ");
    $SL   = $db_obj->db_object($Q2);
    $ship = mswCD($SL->shippingAddr);
  }
  return $ship;
}

//---------------------------------------------------
// Get sale order
//---------------------------------------------------

function mswGetSaleOrderTotals($id, $db_obj) {
  $dc   = '0.00';
  $dcc  = '';
  $Q    = $db_obj->db_query("SELECT ROUND(SUM(`cost`),2) AS `sumSale` FROM `" . DB_PREFIX . "sales_items`
		       WHERE `sale` = '{$id}'
		       ");
  $SI   = $db_obj->db_object($Q);
  $Q2   = $db_obj->db_query("SELECT `shipping`,`tax`,`tax2`,`taxRate`,`taxRate2`,`coupon` FROM `" . DB_PREFIX . "sales`
		       WHERE `id` = '{$id}'
		       ");
  $SL   = $db_obj->db_object($Q2);
  $Q3   = $db_obj->db_query("SELECT count(*) AS `iCount` FROM `" . DB_PREFIX . "sales_items`
		       WHERE `sale`   = '{$id}'
           AND `physical` = 'yes'
		       ");
  $SIC1 = $db_obj->db_object($Q3);
  $Q4   = $db_obj->db_query("SELECT count(*) AS `iCount` FROM `" . DB_PREFIX . "sales_items`
		       WHERE `sale`   = '{$id}'
           AND `physical` = 'no'
		       ");
  $SIC2 = $db_obj->db_object($Q4);
  $sub  = (isset($SI->sumSale) ? mswFMPR($SI->sumSale) : '0.00');
  $ship = (isset($SL->shipping) ? mswFMPR($SL->shipping) : '0.00');
  $tax  = (isset($SL->tax) ? mswFMPR($SL->tax) : '0.00');
  $tax2 = (isset($SL->tax2) ? mswFMPR($SL->tax2) : '0.00');
  $cp   = mswCD(unserialize($SL->coupon));
  $tsub = $sub;
  if (isset($cp[0],$cp[1]) && $cp[1] > 0) {
    $dc   = $cp[1];
    $dcc  = $cp[0];
    $tsub = mswFMPR($sub-$dc);
  }
  return array(
    'sub' => $sub,
    'ship' => $ship,
    'tax' => $tax,
    'rate' => ($SL->taxRate > 0 ? $SL->taxRate : '0'),
    'tax2' => $tax2,
    'rate2' => ($SL->taxRate2 > 0 ? $SL->taxRate2 : '0'),
    'total' => mswFMPR(($tsub + $ship + $tax + $tax2)),
    'coupon' => $dc,
    'couponcode' => $dcc,
    'counts' => array(
      (isset($SIC1->iCount) ? $SIC1->iCount : '0'),
      (isset($SIC2->iCount) ? $SIC2->iCount : '0')
    )
  );
}

//----------------------------
// Get sale order
//----------------------------

function mswGetSaleOrder($id, $db_obj, $emvars, $reset = array()) {
  $sale = array(
    'dl' => array(),
    'cd' => array()
  );
  $Q    = $db_obj->db_query("SELECT * FROM `" . DB_PREFIX . "sales_items`
          WHERE `sale` = '{$id}'
          " . (!empty($reset) ? 'AND `id` IN(' . implode(',', $reset) . ')' : '') . "
          ORDER BY `type`,`id`
          ");
  while ($ITEMS = $db_obj->db_object($Q)) {
    switch ($ITEMS->type) {
      case 'collection':
        $Q_C    = $db_obj->db_query("SELECT * FROM `" . DB_PREFIX . "collections` WHERE `id` = '{$ITEMS->item}'");
        $CTION  = $db_obj->db_object($Q_C);
        $name   = mswCD($CTION->name);
        $sale[$ITEMS->physical == 'yes' ? 'cd' : 'dl'][] = str_replace(array(
          '{catalogue}',
          '{collection}',
          '{cost}'
        ), array(
          $CTION->catnumber,
          $name,
          $ITEMS->cost
        ), (!empty($reset) ? $emvars[2] : $emvars[0]));
        break;
      case 'track':
        $Q_T          = $db_obj->db_query("SELECT * FROM `" . DB_PREFIX . "music` WHERE `id` = '{$ITEMS->item}'");
        $CTK          = $db_obj->db_object($Q_T);
        $Q_C          = $db_obj->db_query("SELECT * FROM `" . DB_PREFIX . "collections` WHERE `id` = '{$CTK->collection}'");
        $CTION        = $db_obj->db_object($Q_C);
        $name         = mswCD($CTION->name);
        $track        = mswCD($CTK->title);
        $sale['dl'][] = str_replace(array(
          '{catalogue}',
          '{collection}',
          '{track}',
          '{cost}'
        ), array(
          $CTION->catnumber,
          $name,
          $track,
          $ITEMS->cost
        ), (!empty($reset) ? $emvars[3] : $emvars[1]));
        break;
    }
  }
  return $sale;
}

//-----------------------------------
// Sale order agreement
//-----------------------------------

function mswGetSaleOrderAgreement($id, $db_obj, $emvars) {
  $sale = array(
    'dl' => array(),
    'cd' => array(),
    'cdd' => array()
  );
  $Q    = $db_obj->db_query("SELECT * FROM `" . DB_PREFIX . "sales_items`
          WHERE `sale` = '{$id}'
          ORDER BY `type`,`id`
          ");
  while ($ITEMS = $db_obj->db_object($Q)) {
    switch ($ITEMS->type) {
      case 'collection':
        $Q_C    = $db_obj->db_query("SELECT * FROM `" . DB_PREFIX . "collections` WHERE `id` = '{$ITEMS->item}'");
        $CTION  = $db_obj->db_object($Q_C);
        $name   = mswCD($CTION->name);
        $sale[$ITEMS->physical == 'yes' ? 'cd' : 'cdd'][] = str_replace(array(
          '{catalogue}',
          '{collection}',
          '{cost}'
        ), array(
          ($CTION->catnumber ? $CTION->catnumber : '>'),
          $name,
          $ITEMS->cost
        ), $emvars[2]);
        break;
      case 'track':
        $Q_T    = $db_obj->db_query("SELECT * FROM `" . DB_PREFIX . "music` WHERE `id` = '{$ITEMS->item}'");
        $CTK    = $db_obj->db_object($Q_T);
        $Q_C    = $db_obj->db_query("SELECT * FROM `" . DB_PREFIX . "collections` WHERE `id` = '{$CTK->collection}'");
        $CTION  = $db_obj->db_object($Q_C);
        $name   = mswCD($CTION->name);
        $track  = mswCD($CTK->title);
        $sale['dl'][] = str_replace(array(
          '{catalogue}',
          '{collection}',
          '{track}',
          '{cost}'
        ), array(
          $CTION->catnumber,
          $name,
          $track,
          $ITEMS->cost
        ), $emvars[3]);
        break;
    }
  }
  return $sale;
}

//-----------------------------------
// Determine which doc topic to load
//-----------------------------------

function mswDocTopic($cmd, $gw_docs = '') {
  if ($gw_docs) {
    return $gw_docs;
  } else {
    switch ($cmd) {
      case 'purchase':
        return 'index.html';
        break;
      case 'msg':
        return ($_GET['code'] == 'test' ? 'ad-test' : 'index') . '.html';
        break;
      case 'gateways':
        return 'gateways.html';
        break;
      case 'new-gateway':
        if (defined('GW_HELP')) {
          return 'gw-' . GW_HELP . '.html';
        } else {
          return 'ad-new-gateway.html';
        }
        break;
      default:
        return 'ad-' . $cmd . '.html';
        break;
    }
  }
}

//-------------------------------
// Download expiry time
//-------------------------------

function mswDLExpiryTime($S, $DT) {
  $ts     = '0';
  $access = ($S->access ? unserialize($S->access) : array());
  if (isset($access[0], $access[1])) {
    $time = (int) $access[0];
    $apd  = ($time > 1 ? 's' : '');
    if ($time > 0) {
      $cur = $DT->utcTime();
      switch ($access[1]) {
        case 'min':
          $ts = strtotime(date('Y-m-d H:i:s', strtotime('+' . $time . ' minute' . $apd, $cur)));
          break;
        case 'hrs':
          $ts = strtotime(date('Y-m-d H:i:s', strtotime('+' . $time . ' hour' . $apd, $cur)));
          break;
        case 'day':
          $ts = strtotime(date('Y-m-d H:i:s', strtotime('+' . $time . ' day' . $apd, $cur)));
          break;
        case 'week':
          $ts = strtotime(date('Y-m-d H:i:s', strtotime('+' . $time . ' week' . $apd, $cur)));
          break;
        case 'month':
          $ts = strtotime(date('Y-m-d H:i:s', strtotime('+' . $time . ' month' . $apd, $cur)));
          break;
      }
    }
  }
  return $ts;
}

//---------------------------------
// New line to break..
//---------------------------------

function mswNL2BR($text) {
  // Second param added in 5.3.0, else its not available..
  if (version_compare(phpversion(), '5.3.0', '<')) {
    return str_replace(mswNL(), '<br>', $text);
  }
  return nl2br($text, false);
}

//-----------------------------------
// Round up bit rate
//-----------------------------------

function mswBitRate($rate) {
  $r = round($rate);
  return (strlen($r) > 3 ? substr($r, 0, -3) : $r);
}

//----------------------------------------------
// Get single country
//----------------------------------------------

function mswGetCountry($id, $db_obj) {
  $Q    = $db_obj->db_query("SELECT * FROM `" . DB_PREFIX . "countries`
          WHERE `id`   = '{$id}'
          ");
  return $db_obj->db_object($Q);
}

//---------------------------------------------------
// History logger
//---------------------------------------------------

function mswHistoryLog($data = array(), $obj) {
  $data = mswSQLIM($data, $obj);
  $obj->db_query("INSERT INTO `" . DB_PREFIX . "sales_click` (
  `sale`,
  `trackcol`,
  `ip`,
  `ts`,
  `action`,
  `type`,
  `iso`,
  `country`
  ) VALUES (
  '{$data['sale']}',
  '{$data['trackcol']}',
  '" . $_SERVER['REMOTE_ADDR'] . "',
  UNIX_TIMESTAMP(UTC_TIMESTAMP),
  '{$data['action']}',
  '{$data['type']}',
  '{$data['iso']}',
  '{$data['country']}'
  )");
}

//---------------------------------------------------
// Invoice number
//---------------------------------------------------

function mswINV($num) {
  $zeros = '';
  if (MIN_INVOICE_DIGITS > 0 && MIN_INVOICE_DIGITS > strlen($num)) {
    for ($i = 0; $i < MIN_INVOICE_DIGITS - strlen($num); $i++) {
      $zeros .= 0;
    }
  }
  return ($zeros . $num);
}

//---------------------------------------------------
// JS Data Filters
//---------------------------------------------------

function mswJS($data) {
  return str_replace("'", "\'", $data);
}

//---------------------------------------------------
// Cleans output data..
//---------------------------------------------------

function mswCD($data) {
  if (function_exists('get_magic_quotes_gpc') && get_magic_quotes_gpc()) {
    $sybase = strtolower(@ini_get('magic_quotes_sybase'));
    if (empty($sybase) || $sybase == 'off') {
      // Fixes issue of new line chars not parsing between single quotes..
      $data = str_replace('\n', '\\\n', $data);
      return stripslashes($data);
    }
  }
  return $data;
}

//---------------------------------------------------
// Re-enable site
//---------------------------------------------------

function mswSiteOnline($db_obj) {
  $db_obj->db_query("UPDATE `" . DB_PREFIX . "settings` SET
  `sysstatus`  = 'yes',
  `autoenable` = '0'
  ");
}

//---------------------------------------------------
// Cleans output data with character entities..
//---------------------------------------------------

function mswSH($data) {
  $data = htmlspecialchars($data);
  $data = str_replace('&amp;#', '&#', $data);
  $data = str_replace('&amp;amp;', '&amp;', $data);
  return mswCD($data);
}

//---------------------------------------------------
// Clean CSV
//---------------------------------------------------

function mswCSV($data, $del) {
  return '"' . mswCD($data) . '"';
}

//---------------------------------------------------
// Prepare CSV Array
//---------------------------------------------------

function mswPrepCSV($data) {
  return "'{$data}'";
}

//---------------------------------------------------
// Format currency display..
//---------------------------------------------------

function mswCURF($p, $f, $c = false) {
  return str_replace('{AMOUNT}', mswFMPR($p, $c), $f);
}

//---------------------------------------------------
// Format price..
//---------------------------------------------------

function mswFMPR($price, $comma = false) {
  $sep = '';
  if (PRICE_THOUSANDS_SEPARATORS && $comma) {
    $sep = PRICE_THOUSANDS_SEPARATORS;
  }
  $price = mswNFMDec($price, 2);
  $price = preg_replace("/[^0-9\.]/", "", str_replace(',', '.', $price));
  if (substr($price, -3, 1) == '.') {
    $pennies = '.' . substr($price, -2);
    $price   = substr($price, 0, strlen($price) - 3);
  } elseif (substr($price, -2, 1) == '.') {
    $pennies = '.' . substr($price, -1);
    $price   = substr($price, 0, strlen($price) - 2);
  } else {
    $pennies = '.00';
  }
  $price = preg_replace("/[^0-9]/", "", $price);
  // Prevent formatting errors during imports..
  if ($price == '') {
    $price = '0';
  }
  if (rtrim($pennies, '.') == '') {
    $pennies = '.00';
  }
  return ($price . $pennies > 0 ? mswNFMDec($price . $pennies, 2, '.', ($sep ? $sep : '')) : '0.00');
}

function mswNFM($num, $dec = 0) {
  return @number_format($num, $dec);
}

function mswNFMDec($num, $dec = 0, $dot = '.', $sep = '') {
  return @number_format($num, $dec, $dot, $sep);
}

//---------------------------------------------------
// Generates 60 character product key..
//---------------------------------------------------

function mswPRKEY() {
  $_SERVER['HTTP_HOST']   = (isset($_SERVER['HTTP_HOST']) && $_SERVER['HTTP_HOST'] ? $_SERVER['HTTP_HOST'] : uniqid(rand(), 1));
  $_SERVER['REMOTE_ADDR'] = (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] ? $_SERVER['REMOTE_ADDR'] : uniqid(rand(), 1));
  if (function_exists('sha1')) {
    $c1      = sha1($_SERVER['HTTP_HOST'] . date('YmdHis') . $_SERVER['REMOTE_ADDR'] . time());
    $c2      = sha1(uniqid(rand(), 1) . time());
    $prodKey = substr($c1 . $c2, 0, 60);
  } elseif (function_exists('md5')) {
    $c1      = md5($_SERVER['HTTP_POST'] . date('YmdHis') . $_SERVER['REMOTE_ADDR'] . time());
    $c2      = md5(uniqid(rand(), 1), time());
    $prodKey = substr($c1 . $c2, 0, 60);
  } else {
    $c1      = str_replace('.', '', uniqid(rand(), 1));
    $c2      = str_replace('.', '', uniqid(rand(), 1));
    $c3      = str_replace('.', '', uniqid(rand(), 1));
    $prodKey = substr($c1 . $c2 . $c3, 0, 60);
  }
  return strtoupper($prodKey);
}

//---------------------------------------------------
// Define new line per op system..
//---------------------------------------------------

function mswNL() {
  if (defined('PHP_EOL')) {
    return PHP_EOL;
  }
  $nl = "\r\n";
  if (isset($_SERVER["HTTP_USER_AGENT"]) && strstr(strtolower($_SERVER["HTTP_USER_AGENT"]), 'win')) {
    $nl = "\r\n";
  } else if (isset($_SERVER["HTTP_USER_AGENT"]) && strstr(strtolower($_SERVER["HTTP_USER_AGENT"]), 'mac')) {
    $nl = "\r";
  } else {
    $nl = "\n";
  }
  return $nl;
}

//---------------------------------------------------
// File size..
//---------------------------------------------------

function mswFSCN($size = 0, $precision = 2) {
  if ($size > 0) {
    $base     = log($size) / log(1024);
    $suffixes = array(
      'Bytes',
      'KB',
      'MB',
      'GB',
      'TB'
    );
    return round(pow(1024, $base - floor($base)), $precision) . $suffixes[floor($base)];
  } else {
    return '0Bytes';
  }
}

//---------------------------------------------------
// SSL Detection
//---------------------------------------------------

function mswSSL() {
  return (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on' ? 'yes' : 'no');
}

//---------------------------------------------------
// Gets visitor IP address..
//---------------------------------------------------

function mswIP($ar = false) {
  $ips = array();
  $types = array(
    'HTTP_CLIENT_IP',
    'HTTP_X_FORWARDED_FOR',
    'HTTP_X_FORWARDED',
    'HTTP_X_CLUSTER_CLIENT_IP',
    'HTTP_FORWARDED_FOR',
    'HTTP_FORWARDED',
    'REMOTE_ADDR'
  );
  foreach ($types AS $key) {
    if (array_key_exists($key, $_SERVER) === true) {
      foreach (array_map('trim', explode(',', $_SERVER[$key])) AS $ipA) {
        if (!in_array($ipA, $ips) && filter_var($ipA, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
          $ips[] = $ipA;
        } else {
          // Double check for localhost..
          if (!in_array($ipA, $ips) && in_array($ipA, array('::1','127.0.0.1'))) {
            $ips[] = $ipA;
          }
        }
      }
    }
  }
  if ($ar) {
    return $ips;
  }
  return (!empty($ips) ? implode(',', $ips) : '');
}

//---------------------------------------------------
// Returns encrypted data..
//---------------------------------------------------

function mswEncrypt($data) {
  return (function_exists('sha1') ? sha1($data) : md5($data));
}

//---------------------------------------------------
// Safe mysql import..
//---------------------------------------------------

function mswSQLIM($data, $obj) {
  if (function_exists('get_magic_quotes_gpc') && get_magic_quotes_gpc()) {
    $sybase = strtolower(@ini_get('magic_quotes_sybase'));
    if (empty($sybase) || $sybase == 'off') {
      $data = mswMDAM('stripslashes', $data, $obj);
    } else {
      $data = mswMDAM('removeDoubleApostrophes', $data, $obj);
    }
  }
  $data = mswMDAM('escapeString', $data, $obj);
  return $data;
}

//---------------------------------------------------
// Safe import string..
//---------------------------------------------------

function mswSQL($data, $obj) {
  if (function_exists('get_magic_quotes_gpc') && get_magic_quotes_gpc()) {
    $sybase = strtolower(@ini_get('magic_quotes_sybase'));
    if (empty($sybase) || $sybase == 'off') {
      $data = stripslashes($data);
    } else {
      $data = mswRMDBLA($data);
    }
  }
  return $obj->db_escape($data);
}

//---------------------------------------------------
// Clean double quotes
//---------------------------------------------------

function mswRMDBLA($data) {
  return str_replace("''", "'", $data);
}

//---------------------------------------------------
// Recursive way of handling multi dimensional arrays..
//---------------------------------------------------

function mswMDAM($func, $arr, $obj = '') {
  $newArr = array();
  if (!empty($arr)) {
    foreach ($arr AS $key => $value) {
      switch($func) {
        case 'escapeString':
          $newArr[$key] = (is_array($value) ? mswMDAM($func, $value, $obj) : $obj->db_escape($value));
          break;
        default:
          $newArr[$key] = (is_array($value) ? mswMDAM($func, $value, $obj) : $func($value));
          break;
      }
    }
  }
  return $newArr;
}

//---------------------------------------------------
// Put files
//---------------------------------------------------

function mswPUT($file, $data) {
  file_put_contents($file, $data, FILE_APPEND);
}

//---------------------------------------------------
// Theme loader
//---------------------------------------------------

function mswThemeLoader($folder) {
  return (is_dir(MM_BASE_PATH . 'content/' . $folder) ? $folder : '_theme_default');
}

//---------------------------------------------------
// Schema check for manual DB dump
//---------------------------------------------------

function mswSchemaCheck($s, $obj, $admin = false) {
  if ($s->httppath == 'Manual') {
    $root = 'http://www.example.com/music-store';
    $key  = mswPRKEY();
    if (isset($_SERVER['HTTP_HOST'], $_SERVER['PHP_SELF'])) {
      if ($admin) {
        $root  = 'http'.(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS']=='on' ? 's' : '').'://' . $_SERVER['HTTP_HOST'].substr($_SERVER['PHP_SELF'],0,strpos($_SERVER['PHP_SELF'],'admin')-1).'/';
      } else {
        $root  = 'http'.(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS']=='on' ? 's' : '').'://' . $_SERVER['HTTP_HOST'].substr($_SERVER['PHP_SELF'],0,-10).'/';
      }
    }
    $obj->db_query("UPDATE `" . DB_PREFIX . "settings` SET
    `httppath`  = '{$root}',
    `prodkey`   = '{$key}',
    `version`   = '" . SCRIPT_VERSION . "'
    ");
    header("Location: index.php");
    exit;
  }
}

//---------------------------------------------------
// Forbidden
//---------------------------------------------------

function mswEcode($msg, $code) {
  switch ($code) {
    case '200':
      header('HTTP/1.0 200 OK');
      break;
    case '400':
      header('HTTP/1.0 400 Bad Request');
      break;
    case '403':
      header('HTTP/1.0 403 Forbidden');
      break;
    case '404':
      header('HTTP/1.0 404 Not Found');
      break;
  }
  header('content-type: text/plain; charset=utf-8');
  echo $msg;
  exit;
}

//-----------------------------------------------
// Controller
//-----------------------------------------------

function mswfileController() {
  if (!file_exists(MM_BASE_PATH . 'control/system/core/sys-controller.php')) {
    die('[FATAL ERROR] The "control/system/core/sys-controller.php" file does NOT exist in your installation. It may have been auto deleted by your anti virus software. If
    this is the case, this is a false positive. Please add the file to your anti virus whitelist, re-add and refresh page.');
  }
}

//-----------------------------------------------
// Password hashing
//-----------------------------------------------

function mswPassHash($d = array()) {
  switch($d['type']) {
    case 'add':
      return password_hash($d['pass'], PASSWORD_BCRYPT);
      break;
    case 'calc':
      return password_verify($d['val'], $d['hash']);
      break;
  }
}

//---------------------------------------------------
// Global filtering on post and get input..
//---------------------------------------------------

$_GET  = mswMDAM('htmlspecialchars', $_GET);
$_POST = mswMDAM('trim', $_POST);

?>