<?php

/* USER DEFINED
   Edit values on right, DO NOT change values in capitals
-------------------------------------------------------------*/

/* Admin folder name. If changed, enter new name here */
define('MM_ADMIN_FOLDER', 'admin');

/* Frontend track search. 1 = On, 0 = Off */
define('SEARCH_TRACKS', 1);

/* Price thousands separator */
define('PRICE_THOUSANDS_SEPARATORS', ',');

/* Allowed tags. Pipe delimit. */
define('SUPPORTED_MUSIC', 'mp3|mp4|wav');

/* Supported image extensions for covers, Pipe delimit */
define('SUPPORTED_IMAGES', 'jpg|jpeg|gif|png|tiff|bmp');

/* Enable auto reading of MP3 tags. 1 = On, 0 = Off */
define('READ_MP3_TAGS', 1);

/* Unicode value for reading tags */
define('READ_MP3_UNICODE', 'UTF-8');

/* Minimum version of GetID3 for tag reading. No need to change this */
define('MIN_VERSION_MP3_TAG', '5.0.5');

/* Default track cost on page load */
define('DEFAULT_TRACK_COST', '0.50');

/* Recent View Limit */
define('RECENTLY_VIEWED_COLLECTIONS_LIMIT', 10);

/* Popular products Limit */
define('POPULAR_COLLECTIONS_LIMIT', 10);

/* Enable jquery auto complete. 1 = On, 0 = Off */
define('AUTO_COMPLETE_ENABLE', 1);

/* Auto complete min data length. */
define('AUTO_COMPLETE_MIN_LENGTH', 3);

/* Max name character display for collection names in frontend interface. 0 for full name */
define('NAME_CHAR_DISPLAY', 0);

/* Minimum search word length for frontend interface */
define('MIN_SEARCH_WORD_LENGTH', 2);

/* Display counts after style names. 1 = On, 0 = Off */
define('DISPLAY_STYLE_COUNTS', 1);
define('DISPLAY_STYLE_COUNTS_LINKED', 1);

/* Redirect time for payment gateways */
define('REDIRECT_TIME', 5);

/* Maximum latest orders to show on account homescreen */
define('ORDER_LIMIT_ACCOUNT_HOMESCREEN', 5);

/* Enable none verified accounts after a successful sale */
define('ENABLE_NONE_VERIFIED_AFTER_SALE', 1);

/* Name for logs folder */
define('GW_LOG_FOLDER_NAME', 'logs');

/* Page refresh interval for payment gateways */
define('RESPONSE_PAGE_REFRESHES', 15);

/* Data to show per page */
define('PER_PAGE', 25);
define('ORDERS_PER_PAGE', 15);
define('COLLECTIONS_PER_PAGE', 10);
define('SEARCH_PER_PAGE', 10);

/* Limits for data on frontend interface */
define('FEATURED_HOME_LIMIT', 10);
define('LATEST_LIMIT', 10);
define('POPULAR_LIMIT', 10);

/* DEFAULT DATA TRUNCATION
   Truncates certain text
   Not applicable on tablets / mobiles
   Enable: 1 = Yes, 0 = No
-------------------------------------------------------*/

define('ENABLE_DATA_TRUNCATION', 1);
define('DEFAULT_DATA_TRUNCATION_BOXES', 45);
define('DEFAULT_DATA_TRUNCATION_FOOTER', 80);
define('DATA_TRUNCATION_ELIPSES', '...');

/* Activate emails. 1 = On, 0 = Off */
define('MAIL_ACTIVATE', 1);

/* By default the X-Mailer header shows the PHP Mailer has been used, the version number and link to their github page
   To override this, enter your own custom text if applicable */
define('MAIL_X_MAIL_HEADER', '');

/* Server path to music system. DO NOT change unless you know what you are doing. */
define('MM_BASE_PATH', substr(dirname(__file__),0,strpos(dirname(__file__),'control')-1) . '/');

/* Minimum digits for invoice */
define('MIN_INVOICE_DIGITS', 5);

/* Folders for data. Can be changed if preferred. */
define('PREVIEW_FOLDER', 'content/previews');
define('COVER_ART_FOLDER', 'content/cover-art');

/* Defines the operating system. DO NOT change */
define('MM_OS', PHP_OS);

?>