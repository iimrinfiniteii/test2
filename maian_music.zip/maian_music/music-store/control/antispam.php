<?php

/* ANTI SPAM
   Simple anti spam questions - Add as many as you like,
   but do not leave any blank entries. Blank arrays should
   be removed. At least 2 entries must exist.
-----------------------------------------------------------*/

// 0 = Off, 1 = On
define('ENABLE_ANTI_SPAM', 1);

// Questions / Answers
// q = Question
// a = Answer
$antiSpam = array(
  array(
    'q' => 'Please type the third and fifth characters from the capital of England',
    'a' => 'no'
  ),
  array(
    'q' => 'What country would you be in if you were in Taipei?',
    'a' => 'taiwan'
  ),
  array(
    'q' => 'Please enter the word "encapsulate".',
    'a' => 'encapsulate'
  ),
  array(
    'q' => 'What is seven multiplied by twenty minus 3 (7 x 20 - 3)?',
    'a' => '137'
  ),
  array(
    'q' => 'Is Finland in Asia? Enter yes or no.',
    'a' => 'no'
  )
);

?>
