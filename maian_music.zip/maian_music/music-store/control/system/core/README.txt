PLEASE READ, THANK YOU
----------------------------------------------

Please DO NOT MAKE CHANGES to the 'sys-controller.php' file, thank you

This software is protected by UK laws. To modify this file to bypass the licence system is strictly forbidden.

If you like the system, please consider a commercial licence to help continue development of this software.

A one off payment, no subscriptions and all updates are free.

Thank you.