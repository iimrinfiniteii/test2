<?php

/* System Module
----------------------------------------------------------*/

if (!defined('PARENT') || !defined('BASE_HREF')) {
  mswEcode($gblang[4],'403');
}

// Footer..
$footer  =  $pblang[11] . ': <a href="https://www.' . SCRIPT_URL . '" title="' . mswSH(SCRIPT_NAME) . '" onclick="window.open(this);return false">' . SCRIPT_NAME . '</a><br>';
$footer .= '&copy;2007-' . date('Y', $DT->timeStamp()) . ' <a href="https://www.maianscriptworld.co.uk" onclick="window.open(this);return false" title="Maian Script World">Maian Script World</a>. ' . $pblang[12] . ' . ';

// Commercial version..
if (LICENCE_VER=='unlocked' && $SETTINGS->pfoot) {
  $footer = $SETTINGS->pfoot;
}

$config = array(
 'template_path' => array(PATH)
);

$tpl  = new Savant3($config);
$tpl->assign('FOOTER', $footer);
$tpl->assign('TXT', array(
  $gblang[22],
  $pbaccount,
  $pblang,
  $checklang
));
$tpl->assign('URL', array(
  BASE_HREF,
  BASE_HREF . $SEO->url('account', array(), 'yes'), //account
  BASE_HREF . $SEO->url('latest', array(), 'yes'), //latest
  BASE_HREF . $SEO->url('popular', array(), 'yes'), //popular
  BASE_HREF . $SEO->url('specials', array(), 'yes'), //specials
  BASE_HREF . $SEO->url('basket', array(), 'yes'), // basket
  BASE_HREF . $SEO->url('profile', array(), 'yes'), // profile
  BASE_HREF . $SEO->url('orders', array(), 'yes'), //orders
  BASE_HREF . $SEO->url('logout', array(), 'yes') //logout
));
$tpl->assign('KEYS', (isset($keys) ? mswSH($keys) : ''));
$tpl->assign('SOCIAL_BUTTONS', $BUILDER->socialbuttons());
$tpl->assign('PLUGIN_LOADER', $BUILDER->plugins('footer', $pluginLoader));
$tpl->assign('GATEWAY_LOADED', (defined('GATEWAY_LOADED') ? 'yes' : 'no'));

// Only needed for basket ops..
if (defined('BASKET_SCREEN_LOADED')) {
  $stripe = $CART->gwEn('class.stripe.php');
  $tpl->assign('GATEWAYS_ENABLED', array(
    'stripe' => array(
      'enabled' => $stripe[0],
      'params' => $stripe[1]
    )
  ));
}

// Global template vars..
include(PATH . 'control/lib/global.php');

// Load template..
$tpl->display('content/' . THEME . '/footer.tpl.php');

?>