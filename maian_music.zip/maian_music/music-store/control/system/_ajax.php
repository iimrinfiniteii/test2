<?php

/* AJAX OPS
--------------------------------------------------------*/

// All these things should always be present..fail if not..
if (!defined('PARENT') || !isset($_GET['ajax']) || !isset($_GET['id']) || !defined('BASE_HREF')) {
  exit;
}

define('TAX_HTML_TAGS', 1);

include(PATH . 'control/antispam.php');
include(PATH . 'control/classes/mailer/mail-init.php');
include(PATH . 'control/classes/class.json.php');
$JSON = new jsonHandler();
$arr  = array(
  'resp' => 'err',
  'msg' => $jslang[12],
  'title' => $jslang[13],
  'image' => BASE_HREF . 'content/' . THEME . '/images/warning.png',
  'sys' => array(),
  'basket' => 'wait'
);

switch ($_GET['ajax']) {
  case 'basket-coupon':
    $coupon = (isset($_POST['coupon']) && $_POST['coupon'] ? $_POST['coupon'] : 'no_coupon_code');
    $method = (isset($_POST['method']) && $_POST['method'] ? $_POST['method'] : '');
    $text   = array(
     'expired' => $pbbasket[26],
     'invalid' => $pbbasket[25]
    );
    if ($coupon) {
      $disCalc  = 'no';
      $discount = 'no';
      // Is guest checkout enabled?
      if (!isset($systemAcc['accID'])) {
        $systemAcc['accID'] = 0;
      }
      $CP       = ($coupon != 'no_coupon_code' ? $CART->coupon($coupon, $systemAcc['accID']) : array('none',''));
      switch($CP[0]) {
        case 'ok':
        case 'none':
          // Adjust if coupon applied..
          if ($CP[0]=='ok') {
            $discount = (substr($CP[1], -1) == '%' ? mswFMPR((substr($CP[1], 0, -1) * CART_TOTAL) / 100) : $CP[1]);
            $disCalc = $CP[1];
            // If discount is higher, total cost is max discount..
            if ($discount > CART_TOTAL) {
              $newPrice = '0.00';
              $discount = CART_TOTAL;
            } else {
              $newPrice = mswFMPR(CART_TOTAL - $discount);
            }
            // Coupon HTML..
            $fr = array(
              '{txt}' => $pbbasket[27],
              '{total}' => mswCURF(mswFMPR($discount),$SETTINGS->curdisplay)
            );
            $html  = $BUILDER->template($fr, 'basket-coupon.tpl');
            $hidden = array(
              $coupon,
              $discount
            );
          } else {
            $newPrice = CART_TOTAL;
            $html     = '';
            $hidden   = array();
          }
          if (!isset($systemAcc['accCountry'])) {
            $systemAcc['accCountry'] = 0;
            // Is guest checkout set?
            if (isset($_SESSION[$g_sess_ky]['country'])) {
              $systemAcc['accCountry'] = $_SESSION[$g_sess_ky]['country'];
            }
          }
          $ship = ($method ? $CART->getShipping($newPrice, $method) : '0.00');
          $tax  = $CART->getTax($BUILDER, $systemAcc['accCountry'], 'tangible', $ship, array($disCalc, $discount));
          $tax2 = $CART->getTax($BUILDER, $systemAcc['accCountry'], 'digital', '0.00', array($disCalc, $discount));
          // If coupon was applied, add discounts to array..
          if (!empty($hidden)) {
            $hidden[]  = $tax[3];
            $hidden[]  = $tax2[3];
          }
          $arr['resp'] = 'OK';
          $arr['sys']  = array(
            'sub' => mswCURF(CART_TOTAL, $SETTINGS->curdisplay),
            'ship' => ($ship > 0 ? mswCURF($ship, $SETTINGS->curdisplay) : $pbprofile[14]),
            'tax' => (mswFMPR($tax[0] + $tax2[0]) > 0 ? mswCURF(mswFMPR($tax[0] + $tax2[0]), $SETTINGS->curdisplay) : 'no'),
            'total' => mswCURF(mswFMPR($newPrice + $ship + mswFMPR($tax[0] + $tax2[0])), $SETTINGS->curdisplay),
            'rawtotal' => mswFMPR($newPrice + $ship + mswFMPR($tax[0] + $tax2[0])),
            'couponhtml' => $html
          );
          // Set total session vars..
          $_SESSION[$bskitm_ky] = array(
            $newPrice,
            ($ship > 0 ? mswFMPR($ship) : '0.00'),
            ($tax[0] > 0 ? mswFMPR($tax[0]) : '0.00'),
            substr($tax[1], 0, -1),
            ($tax2[0] > 0 ? mswFMPR($tax2[0]) : '0.00'),
            substr($tax2[1], 0, -1),
            mswFMPR($newPrice + $ship + mswFMPR($tax[0] + $tax2[0])),
            $tax[2],
            $hidden,
            $tax2[2]
          );
          break;
        case 'expired':
          $arr['msg'] = str_replace('{expired}', $CP[1], $text['expired']);
          break;
        case 'invalid':
          $arr['msg'] = $text['invalid'];
          break;
      }
    } else {
      $arr['resp'] = 'CLEARED';
    }
    break;
  case 'basket-shipping':
    $vars = array(
      'method' => (isset($_POST['method']) ? $_POST['method'] : ''),
      'address1' => (isset($_POST['address1']) ? $_POST['address1'] : ''),
      'address2' => (isset($_POST['address2']) ? $_POST['address2'] : ''),
      'city' => (isset($_POST['city']) ? $_POST['city'] : ''),
      'county' => (isset($_POST['county']) ? $_POST['county'] : ''),
      'postcode' => (isset($_POST['postcode']) ? $_POST['postcode'] : ''),
      'country' => (isset($_POST['country']) ? $_POST['country'] : ''),
      'shipping' => (isset($_POST['is_shipping']) ? $_POST['is_shipping'] : 'no')
    );
    switch ($vars['shipping']) {
      case 'yes':
        if ($vars['method'] == '' || $vars['address1'] == '' || $vars['city'] == '' ||
            $vars['county'] == '' || $vars['postcode'] == '' || in_array($vars['country'] ,array('', '0'))) {
          $eString[]  = $pbbasket[21];
          $arr['msg'] = implode('<br>', $eString);
        }
        break;
      default:
        break;
    }
    if (empty($eString)) {
      // For account, we update shipping address..
      if (isset($systemAcc['accID'])) {
        $ACC->update(array(
          'shipping' => $vars['method']
        ), $systemAcc['accID'], array(
          'address1' => $vars['address1'],
          'address2' => $vars['address2'],
          'city' => $vars['city'],
          'county' => $vars['county'],
          'postcode' => $vars['postcode'],
          'country' => $vars['country']
        ));
      }
      $ship = $CART->getShipping(CART_TOTAL, $vars['method']);
      if (!isset($systemAcc['accCountry'])) {
        $systemAcc['accCountry'] = 0;
        // Is guest checkout set?
        if (isset($_SESSION[$g_sess_ky]['country'])) {
          $systemAcc['accCountry'] = $_SESSION[$g_sess_ky]['country'];
        }
      }
      $tax  = $CART->getTax($BUILDER, $systemAcc['accCountry'], 'tangible', $ship, array('no','no'));
      $tax2 = $CART->getTax($BUILDER, $systemAcc['accCountry'], 'digital', '0.00', array('no','no'));
      $arr['resp'] = 'OK';
      $arr['sys']  = array(
        'sub' => mswCURF(CART_TOTAL, $SETTINGS->curdisplay),
        'ship' => ($ship > 0 ? mswCURF($ship, $SETTINGS->curdisplay) : $pbprofile[14]),
        'tax' => (mswFMPR($tax[0] + $tax2[0]) > 0 ? mswCURF(mswFMPR($tax[0] + $tax2[0]), $SETTINGS->curdisplay) : 'no'),
        'total' => mswCURF(mswFMPR(CART_TOTAL + $ship + mswFMPR($tax[0] + $tax2[0])), $SETTINGS->curdisplay),
        'rawtotal' => mswFMPR(CART_TOTAL + $ship + mswFMPR($tax[0] + $tax2[0])),
        'couponhtml' => ''
      );
      // Set total session vars..
      $_SESSION[$bskitm_ky] = array(
        CART_TOTAL,
        ($ship > 0 ? mswFMPR($ship) : '0.00'),
        ($tax[0] > 0 ? mswFMPR($tax[0]) : '0.00'),
        substr($tax[1], 0, -1),
        ($tax2[0] > 0 ? mswFMPR($tax2[0]) : '0.00'),
        substr($tax2[1], 0, -1),
        mswFMPR(CART_TOTAL + $ship + mswFMPR($tax[0] + $tax2[0])),
        $tax[2],
        array(),
        $tax2[2]
      );
    }
    break;
  case 'basket-login':
    $vars = array(
      'email' => (isset($_POST['em']) && $_POST['em'] ? $_POST['em'] : (isset($systemAcc['email']) ? $systemAcc['email'] : '')),
      'pass' => (isset($_POST['ps']) && $_POST['ps'] ? $_POST['ps'] : ''),
      'name' => (isset($_POST['nm']) && $_POST['nm'] ? $_POST['nm'] : (isset($systemAcc['name']) ? $systemAcc['name'] : '')),
      'method' => (isset($_POST['mthd']) ? $_POST['mthd'] : ''),
      'rescnt' => (isset($_POST['rescountry']) ? (int) $_POST['rescountry'] : (isset($systemAcc['country']) ? $systemAcc['country'] : '0')),
      'guest' => (isset($_POST['guest']) ? 'yes' : 'no')
    );
    // Check min purchase amount..
    if ($SETTINGS->minpurchase > 0) {
      if (CART_TOTAL < $SETTINGS->minpurchase) {
        $arr['msg'] = str_replace('{min}', mswCURF(mswFMPR($SETTINGS->minpurchase), $SETTINGS->curdisplay), $pbbasket[28]);
        echo $JSON->encode($arr);
        exit;
      }
    }
    // For 2.5+, first check only for min purchase above..
    // If min purchase not set or ok, we just proceed..
    if (isset($_GET['min'])) {
      $arr['resp'] = 'ok';
      // Check if user already logged in..
      if (isset($systemAcc['email'])) {
        $EX = $ACC->account(array(
          'email' => $systemAcc['email']
        ));
        $arr['logged_in'] = (isset($EX['accID']) ? 'yes' : 'no');
      } else {
        $arr['logged_in'] = 'no';
      }
      echo $JSON->encode($arr);
      exit;
    }
    // Guest checkout or standard..
    switch($vars['guest']) {
      case 'yes':
        $vars = array(
          'name' => (isset($_POST['g_nm']) ? $_POST['g_nm'] : ''),
          'email' => (isset($_POST['g_em']) ? $_POST['g_em'] : ''),
          'country' => (isset($_POST['g_rescountry']) ? (int) $_POST['g_rescountry'] : '0')
        );
        if ($vars['name'] == '' || mswIsValidEmail($vars['email']) == 'no' || $vars['country'] == '0') {
          $eString[]  = $msw_public_checkout_2_5[10];
          $arr['msg'] = implode('<br>', $eString);
        } else {
          // Does this email address exist as an account?
          $EX = $ACC->account(array(
            'email' => $vars['email']
          ));
          if (isset($EX['accID'])) {
            $arr['resp'] = 'GUEST-EXIST';
            $eString[]  = $msw_public_checkout_2_5[11];
            $arr['msg'] = implode('<br>', $eString);
          } else {
            // No more checks required, so we store information in session..
            $arr['resp'] = 'GUEST-OK';
            // Clear account session if set..
            if (isset($_SESSION[$accent_ky])) {
              unset($_SESSION[$accent_ky]);
            }
            $_SESSION[$g_sess_ky] = array(
              'name' => $vars['name'],
              'email' => $vars['email'],
              'country' => (int) $vars['country']
            );
          }
        }
        break;
      default:
        if (mswIsValidEmail($vars['email']) == 'no' || $vars['pass'] == '') {
          $eString[]  = $pbbasket[16];
          $arr['msg'] = implode('<br>', $eString);
        } else {
          $EX = $ACC->account(array(
            'email' => $vars['email']
          ));
          // Is this a valid account?
          if (isset($EX['accID']) && mswPassHash(array(
            'type' => 'calc',
            'val' => $vars['pass'],
            'hash' => $EX['pass']
          ))) {
            $e     = strtolower($vars['email']);
            $token = mswEncrypt(SECRET_KEY . $e . mswEncrypt(SECRET_KEY . $EX['accID']));
            $ACC->update(array(
              'token' => $token
            ), $EX['accID']);
            $_SESSION[$accent_ky] = array(
              'id' => $token,
              'email' => $e
            );
            // Are login events enabled?
            // Don`t add if already logged in..
            if (!isset($systemAcc['accID']) && $EX['login'] == 'yes') {
              include(PATH . 'control/classes/class.ip.php');
              $IPGEO           = new geoIP();
              $IPGEO->settings = $SETTINGS;
              $lookup          = $IPGEO->lookup($_SERVER['REMOTE_ADDR'], $gblang[19]);
              $ipAddress       = mswIP(true);
              if (isset($ipAddress[0])) {
                $ACC->loginevent(array(
                  'account' => $EX['accID'],
                  'ip' => $ipAddress[0],
                  'ts' => $DT->utcTime(),
                  'iso' => strtolower($lookup['iso']),
                  'country' => $lookup['country']
                ));
                // Are we notifying admin about multiple ips?
                if ($SETTINGS->accloginflag > 0) {
                  $diffIP = $ACC->ipclicks($EX['accID']);
                  if (count($diffIP) >= $SETTINGS->accloginflag) {
                    $newIPLog        = $ACC->ipclicks($EX['accID']);
                    $f_r['{REPORT}'] = $ACC->ipReport($newIPLog, $DT);
                    $f_r['{LIMIT}']  = $SETTINGS->accloginflag;
                    $f_r['{NAME}']   = $EX['name'];
                    $msg             = strtr(mswTmp(PATH . 'content/language/email-templates/wm-account-ip-alert.txt'), $f_r);
                    $sbj             = str_replace('{website}', $SETTINGS->website, $emlang[18]);
                    $mmMail->sendMail(array(
                      'to_name' => $SETTINGS->website,
                      'to_email' => $SETTINGS->email,
                      'from_name' => ($SETTINGS->smtp_from ? $SETTINGS->smtp_from : $SETTINGS->website),
                      'from_email' => ($SETTINGS->smtp_email ? $SETTINGS->smtp_email : $SETTINGS->email),
                      'subject' => $sbj,
                      'msg' => $mmMail->htmlWrapper(array(
                        'global' => $gblang,
                        'title' => $sbj,
                        'header' => $sbj,
                        'content' => mswNL2BR($msg),
                        'footer' => (!defined('LICENCE_VER') || LICENCE_VER == 'locked' ? $gblang[41] : '')
                      )),
                      'reply-to' => array(
                        'name' => ($SETTINGS->smtp_rfrom ? $SETTINGS->smtp_rfrom : ($SETTINGS->smtp_from ? $SETTINGS->smtp_from : $SETTINGS->website)),
                        'email' => ($SETTINGS->smtp_remail ? $SETTINGS->smtp_remail : ($SETTINGS->smtp_email ? $SETTINGS->smtp_email : $SETTINGS->email))
                      ),
                      'other' => $SETTINGS->smtp_other,
                      'plain' => $msg,
                      'htmlWrap' => 'yes'
                    ), $gblang);
                    $mmMail->smtpClose();
                  }
                }
              }
            }
            $fr = array(
              '{name}' => mswSH($EX['name']),
              '{email}' => mswSH($vars['email'])
            );
            $ship = $CART->getShipping(CART_TOTAL, $EX['shipping']);
            $tax  = $CART->getTax($BUILDER, $EX['accCountry'], 'tangible', $ship, array('no','no'));
            $tax2 = $CART->getTax($BUILDER, $EX['accCountry'], 'digital', '0.00', array('no','no'));
            $arr['resp'] = 'VALID';
            $arr['sys']  = array(
              'method' => $EX['shipping'],
              'address1' => mswSH($EX['address1']),
              'address2' => mswSH($EX['address2']),
              'city' => mswSH($EX['city']),
              'county' => mswSH($EX['county']),
              'postcode' => mswSH($EX['postcode']),
              'country' => $EX['addCountry'],
              'sub' => mswCURF(CART_TOTAL, $SETTINGS->curdisplay),
              'ship' => ($ship > 0 ? mswCURF($ship, $SETTINGS->curdisplay) : $pbprofile[14]),
              'tax' => (mswFMPR($tax[0] + $tax2[0]) > 0 ? mswCURF(mswFMPR($tax[0] + $tax2[0]), $SETTINGS->curdisplay) : 'no'),
              'total' => mswCURF(mswFMPR(CART_TOTAL + $ship + mswFMPR($tax[0] + $tax2[0])), $SETTINGS->curdisplay),
              'rawtotal' => mswFMPR(CART_TOTAL + $ship + mswFMPR($tax[0] + $tax2[0])),
              'couponhtml' => ''
            );
            // Set total session vars..
            $_SESSION[$bskitm_ky] = array(
              CART_TOTAL,
              ($ship > 0 ? mswFMPR($ship) : '0.00'),
              ($tax[0] > 0 ? mswFMPR($tax[0]) : '0.00'),
              substr($tax[1], 0, -1),
              ($tax2[0] > 0 ? mswFMPR($tax2[0]) : '0.00'),
              substr($tax2[1], 0, -1),
              mswFMPR(CART_TOTAL + $ship + mswFMPR($tax[0] + $tax2[0])),
              $tax[2],
              array(),
              $tax2[2]
            );
          } else {
            // New account..
            if (!isset($EX['accID'])) {
              if ($vars['name'] == '') {
                $eString[]  = $pbbasket[17];
                $arr['msg'] = implode('<br>', $eString);
              } elseif ($vars['rescnt'] == '0') {
                $eString[]  = $pbbasket[30];
                $arr['msg'] = implode('<br>', $eString);
              } elseif (strlen($vars['pass']) < $SETTINGS->minpass) {
                $eString[]  = str_replace('{min}', $SETTINGS->minpass, $pbprofile[20]);
                $arr['msg'] = implode('<br>', $eString);
              } else {
                $code  = $ACC->password(15, true);
                $ID    = $ACC->add(array(
                  'system1' => $code,
                  'ts' => $DT->utcTime(),
                  'enabled' => 'no',
                  'name' => $vars['name'],
                  'email' => $vars['email'],
                  'country' => $vars['rescnt'],
                  'timezone' => $SETTINGS->timezone,
                  'pass' => mswPassHash(array('type' => 'add', 'pass' => $vars['pass'])),
                  'ip' => $_SERVER['REMOTE_ADDR'],
                  'login' => $SETTINGS->acclogin
                ), array(
                  'address1' => ''
                ));
                $e     = strtolower($vars['email']);
                $token = mswEncrypt(SECRET_KEY . $e . mswEncrypt(SECRET_KEY . $ID));
                $ACC->update(array(
                  'token' => $token
                ), $ID);
                $_SESSION[$accent_ky] = array(
                  'id' => $token,
                  'email' => $e
                );
                $f_r['{NAME}'] = $vars['name'];
                $f_r['{CODE}'] = $code;
                $f_r['{ID}']   = $ID;
                $msg           = strtr(mswTmp(PATH . 'content/language/email-templates/account-verification.txt'), $f_r);
                $sbj           = str_replace('{website}', $SETTINGS->website, $emlang[9]);
                $mmMail->sendMail(array(
                  'to_name' => $vars['name'],
                  'to_email' => $vars['email'],
                  'from_name' => ($SETTINGS->smtp_from ? $SETTINGS->smtp_from : $SETTINGS->website),
                  'from_email' => ($SETTINGS->smtp_email ? $SETTINGS->smtp_email : $SETTINGS->email),
                  'subject' => $sbj,
                  'msg' => $mmMail->htmlWrapper(array(
                    'global' => $gblang,
                    'title' => $sbj,
                    'header' => $sbj,
                    'content' => mswNL2BR($msg),
                    'footer' => (!defined('LICENCE_VER') || LICENCE_VER == 'locked' ? $gblang[41] : '')
                  )),
                  'reply-to' => array(
                    'name' => ($SETTINGS->smtp_rfrom ? $SETTINGS->smtp_rfrom : ($SETTINGS->smtp_from ? $SETTINGS->smtp_from : $SETTINGS->website)),
                    'email' => ($SETTINGS->smtp_remail ? $SETTINGS->smtp_remail : ($SETTINGS->smtp_email ? $SETTINGS->smtp_email : $SETTINGS->email))
                  ),
                  'plain' => $msg,
                  'htmlWrap' => 'yes'
                ), $gblang);
                $mmMail->smtpClose();
                $fr = array(
                  '{name}' => mswSH($vars['name']),
                  '{email}' => mswSH($vars['email'])
                );
                $arr['resp'] = 'NEW';
                $ship        = $CART->getShipping(CART_TOTAL, $vars['method']);
                $tax         = $CART->getTax($BUILDER, $vars['rescnt'], 'tangible', $ship, array('no','no'));
                $tax2        = $CART->getTax($BUILDER, $vars['rescnt'], 'digital', '0.00', array('no','no'));
                $arr['sys']  = array(
                  'sub' => mswCURF(CART_TOTAL, $SETTINGS->curdisplay),
                  'ship' => ($ship > 0 ? mswCURF($ship, $SETTINGS->curdisplay) : $pbprofile[14]),
                  'tax' => (mswFMPR($tax[0] + $tax2[0]) > 0 ? mswCURF(mswFMPR($tax[0] + $tax2[0]), $SETTINGS->curdisplay) : 'no'),
                  'total' => mswCURF(mswFMPR(CART_TOTAL + $ship + mswFMPR($tax[0] + $tax2[0])), $SETTINGS->curdisplay),
                  'rawtotal' => mswFMPR(CART_TOTAL + $ship + mswFMPR($tax[0] + $tax2[0])),
                  'couponhtml' => ''
                );
                // Set total session vars..
                $_SESSION[$bskitm_ky] = array(
                  CART_TOTAL,
                  ($ship > 0 ? mswFMPR($ship) : '0.00'),
                  ($tax[0] > 0 ? mswFMPR($tax[0]) : '0.00'),
                  substr($tax[1], 0, -1),
                  ($tax2[0] > 0 ? mswFMPR($tax2[0]) : '0.00'),
                  substr($tax2[1], 0, -1),
                  mswFMPR(CART_TOTAL + $ship + mswFMPR($tax[0] + $tax2[0])),
                  $tax[2],
                  array(),
                  $tax2[2]
                );
              }
            } else {
              $arr['msg'] = $jslang[17];
            }
          }
        }
        break;
    }
    break;
  case 'basket-checkout':
    $total = (isset($_SESSION[$bskitm_ky][6]) ? mswFMPR($_SESSION[$bskitm_ky][6]) : '0.00');
    if ($total > 0 && (!isset($_POST['payment']) || $_POST['payment'] == 0)) {
      $arr['msg'] = $msw_public_checkout_2_5[14];
    } elseif ($SETTINGS->termsenable == 'yes' && !isset($_POST['terms'])) {
      $arr['msg'] = $jslang[22];
    } else {
      // Get the stripe gateway id..
      $Q  = $DB->db_query("SELECT `id` FROM `" . DB_PREFIX . "gateways` WHERE `class` = 'class.stripe.php'");
      $GW = $DB->db_object($Q);
      $arr['resp'] = 'OK';
      $arr['stripe'] = (isset($GW->id) ? $GW->id : '0');
      $arr['url'] = BASE_HREF . $SEO->url('basket', array(), 'yes');
      $arr['basket'] = 'process';
    }
    break;
  case 'create':
    $vars = array(
      'name' => (isset($_POST['name']) ? $_POST['name'] : ''),
      'email' => (isset($_POST['email']) ? $_POST['email'] : ''),
      'timezone' => (isset($_POST['timezone']) ? $_POST['timezone'] : ''),
      'country' => (isset($_POST['accCountry']) ? (int) $_POST['accCountry'] : ''),
      'passwd' => (isset($_POST['passwd']) ? $_POST['passwd'] : ''),
      'passwd2' => (isset($_POST['passwd2']) ? $_POST['passwd2'] : ''),
      'method' => (isset($_POST['method']) ? (int) $_POST['method'] : ''),
      'address1' => (isset($_POST['address1']) ? $_POST['address1'] : ''),
      'address2' => (isset($_POST['address2']) ? $_POST['address2'] : ''),
      'city' => (isset($_POST['city']) ? $_POST['city'] : ''),
      'county' => (isset($_POST['county']) ? $_POST['county'] : ''),
      'postcode' => (isset($_POST['postcode']) ? $_POST['postcode'] : ''),
      'scountry' => (isset($_POST['addCountry']) ? (int) $_POST['addCountry'] : '')
    );
    if ($vars['name'] == '') {
      $eString[] = $pbprofile[15];
    }
    if (mswIsValidEmail($vars['email']) == 'no') {
      $eString[] = $pbprofile[16];
    } else {
      $EX = $ACC->account(array(
        'email' => $vars['email']
      ));
      if (isset($EX['accID'])) {
        $eString[] = $pbprofile[17];
      }
    }
    if (!in_array($vars['timezone'], array_keys($timezones))) {
      $eString[] = $pbprofile[18];
    }
    if ($vars['passwd'] == '') {
      $eString[] = str_replace('{min}', $SETTINGS->minpass, $pbprofile[23]);
    } else {
      if (strlen($vars['passwd']) < $SETTINGS->minpass) {
        $eString[] = str_replace('{min}', $SETTINGS->minpass, $pbprofile[20]);
      } else {
        if ($vars['passwd'] != $vars['passwd2']) {
          $eString[] = $pbprofile[19];
        }
      }
    }
    if (empty($eString)) {
      // Add..
      $code = $ACC->password(15, true);
      // Insert with basics to get ID..
      $ID   = $ACC->add(array(
        'system1' => $code,
        'ts' => $DT->utcTime(),
        'enabled' => 'no',
        'login' => $SETTINGS->acclogin
      ), array(
        'address1' => $vars['address1']
      ));
      // Update..
      if ($ID > 0) {
        $affRows = $ACC->update(array(
          'name' => $vars['name'],
          'email' => $vars['email'],
          'timezone' => $vars['timezone'],
          'country' => $vars['country'],
          'pass' => mswPassHash(array('type' => 'add', 'pass' => $vars['passwd'])),
          'shipping' => $vars['method'],
          'ip' => $_SERVER['REMOTE_ADDR']
        ), $ID, array(
          'address1' => $vars['address1'],
          'address2' => $vars['address2'],
          'city' => $vars['city'],
          'county' => $vars['county'],
          'postcode' => $vars['postcode'],
          'country' => $vars['scountry']
        ));
      }
      // Send verification email..
      if ($ID > 0) {
        $f_r['{NAME}'] = $vars['name'];
        $f_r['{CODE}'] = $code;
        $f_r['{ID}']   = $ID;
        $msg           = strtr(mswTmp(PATH . 'content/language/email-templates/account-verification.txt'), $f_r);
        $sbj           = str_replace('{website}', $SETTINGS->website, $emlang[9]);
        $mmMail->sendMail(array(
          'to_name' => $vars['name'],
          'to_email' => $vars['email'],
          'from_name' => ($SETTINGS->smtp_from ? $SETTINGS->smtp_from : $SETTINGS->website),
          'from_email' => ($SETTINGS->smtp_email ? $SETTINGS->smtp_email : $SETTINGS->email),
          'subject' => $sbj,
          'msg' => $mmMail->htmlWrapper(array(
            'global' => $gblang,
            'title' => $sbj,
            'header' => $sbj,
            'content' => mswNL2BR($msg),
            'footer' => (!defined('LICENCE_VER') || LICENCE_VER == 'locked' ? $gblang[41] : '')
          )),
          'reply-to' => array(
            'name' => ($SETTINGS->smtp_rfrom ? $SETTINGS->smtp_rfrom : ($SETTINGS->smtp_from ? $SETTINGS->smtp_from : $SETTINGS->website)),
            'email' => ($SETTINGS->smtp_remail ? $SETTINGS->smtp_remail : ($SETTINGS->smtp_email ? $SETTINGS->smtp_email : $SETTINGS->email))
          ),
          'plain' => $msg,
          'htmlWrap' => 'yes'
        ), $gblang);
        $mmMail->smtpClose();
      }
      $arr['resp'] = 'OK';
      $arr['title'] = $pbprofile[24];
      $arr['msg'] = str_replace('{email}', mswSH($vars['email']), $pbprofile[25]);
    } else {
      $arr['msg'] = implode('<br>', $eString);
    }
    break;
  // Account profile..
  case 'profile':
    if (LOGGED_IN == 'yes' && isset($systemAcc['accID'])) {
      $vars = array(
        'name' => (isset($_POST['name']) ? $_POST['name'] : ''),
        'email' => (isset($_POST['email']) ? $_POST['email'] : ''),
        'timezone' => (isset($_POST['timezone']) ? $_POST['timezone'] : ''),
        'country' => (isset($_POST['accCountry']) ? $_POST['accCountry'] : ''),
        'passwd' => (isset($_POST['passwd']) ? $_POST['passwd'] : ''),
        'passwd2' => (isset($_POST['passwd2']) ? $_POST['passwd2'] : ''),
        'method' => (isset($_POST['method']) ? (int) $_POST['method'] : ''),
        'address1' => (isset($_POST['address1']) ? $_POST['address1'] : ''),
        'address2' => (isset($_POST['address2']) ? $_POST['address2'] : ''),
        'city' => (isset($_POST['city']) ? $_POST['city'] : ''),
        'county' => (isset($_POST['county']) ? $_POST['county'] : ''),
        'postcode' => (isset($_POST['postcode']) ? $_POST['postcode'] : ''),
        'scountry' => (isset($_POST['addCountry']) ? $_POST['addCountry'] : '')
      );
      if ($vars['name'] == '') {
        $eString[] = $pbprofile[15];
      }
      if (mswIsValidEmail($vars['email']) == 'no') {
        $eString[] = $pbprofile[16];
      } else {
        if ($vars['email'] != $systemAcc['email']) {
          $EX = $ACC->account(array(
            'email' => $vars['email'],
            'compare' => 'AND `' . DB_PREFIX . 'accounts`.`id` != \'' . $systemAcc['accID'] . '\''
          ));
          if (isset($EX['accID'])) {
            $eString[] = $pbprofile[17];
          }
        }
      }
      if (!in_array($vars['timezone'], array_keys($timezones))) {
        $eString[] = $pbprofile[18];
      }
      if ($vars['passwd']) {
        if (strlen($vars['passwd']) < $SETTINGS->minpass) {
          $eString[] = str_replace('{min}', $SETTINGS->minpass, $pbprofile[20]);
        } else {
          if ($vars['passwd'] != $vars['passwd2']) {
            $eString[] = $pbprofile[19];
          }
        }
      }
      if (empty($eString)) {
        // Update..
        $affRows = $ACC->update(array(
          'name' => $vars['name'],
          'email' => $vars['email'],
          'timezone' => $vars['timezone'],
          'country' => $vars['country'],
          'pass' => ($vars['passwd'] ? mswPassHash(array('type' => 'add', 'pass' => $vars['passwd'])) : $systemAcc['pass']),
          'shipping' => $vars['method'],
          'ip' => $_SERVER['REMOTE_ADDR']
        ), $systemAcc['accID'], array(
          'address1' => $vars['address1'],
          'address2' => $vars['address2'],
          'city' => $vars['city'],
          'county' => $vars['county'],
          'postcode' => $vars['postcode'],
          'country' => $vars['scountry']
        ));
        // Send emails..
        if ($affRows > 0) {
          $f_r['{NAME}']  = $vars['name'];
          $f_r['{EMAIL}'] = $vars['email'];
          $f_r['{IP}']    = $_SERVER['REMOTE_ADDR'];
          // Customer email..
          if (isset($notify['cusprof'])) {
            $msg = strtr(mswTmp(PATH . 'content/language/email-templates/cus-profile-update.txt'), $f_r);
            $sbj = str_replace('{website}', $SETTINGS->website, $emlang[7]);
            $mmMail->sendMail(array(
              'to_name' => $vars['name'],
              'to_email' => $vars['email'],
              'from_name' => ($SETTINGS->smtp_from ? $SETTINGS->smtp_from : $SETTINGS->website),
              'from_email' => ($SETTINGS->smtp_email ? $SETTINGS->smtp_email : $SETTINGS->email),
              'subject' => $sbj,
              'msg' => $mmMail->htmlWrapper(array(
                'global' => $gblang,
                'title' => $sbj,
                'header' => $sbj,
                'content' => mswNL2BR($msg),
                'footer' => (!defined('LICENCE_VER') || LICENCE_VER == 'locked' ? $gblang[41] : '')
              )),
              'reply-to' => array(
                'name' => ($SETTINGS->smtp_rfrom ? $SETTINGS->smtp_rfrom : ($SETTINGS->smtp_from ? $SETTINGS->smtp_from : $SETTINGS->website)),
                'email' => ($SETTINGS->smtp_remail ? $SETTINGS->smtp_remail : ($SETTINGS->smtp_email ? $SETTINGS->smtp_email : $SETTINGS->email))
              ),
              'plain' => $msg,
              'htmlWrap' => 'yes'
            ), $gblang);
            $mmMail->smtpClose();
          }
          // Webmaster email..
          if (isset($notify['webprof'])) {
            $msg = strtr(mswTmp(PATH . 'content/language/email-templates/wm-profile-update.txt'), $f_r);
            $sbj = str_replace('{website}', $SETTINGS->website, $emlang[8]);
            $mmMail->sendMail(array(
              'to_name' => $SETTINGS->website,
              'to_email' => $SETTINGS->email,
              'from_name' => ($SETTINGS->smtp_from ? $SETTINGS->smtp_from : $SETTINGS->website),
              'from_email' => ($SETTINGS->smtp_email ? $SETTINGS->smtp_email : $SETTINGS->email),
              'subject' => $sbj,
              'msg' => $mmMail->htmlWrapper(array(
                'global' => $gblang,
                'title' => $sbj,
                'header' => $sbj,
                'content' => mswNL2BR($msg),
                'footer' => (!defined('LICENCE_VER') || LICENCE_VER == 'locked' ? $gblang[41] : '')
              )),
              'reply-to' => array(
                'name' => ($SETTINGS->smtp_rfrom ? $SETTINGS->smtp_rfrom : ($SETTINGS->smtp_from ? $SETTINGS->smtp_from : $SETTINGS->website)),
                'email' => ($SETTINGS->smtp_remail ? $SETTINGS->smtp_remail : ($SETTINGS->smtp_email ? $SETTINGS->smtp_email : $SETTINGS->email))
              ),
              'other' => $SETTINGS->smtp_other,
              'plain' => $msg,
              'htmlWrap' => 'yes'
            ), $gblang);
            $mmMail->smtpClose();
          }
        }
        $arr['resp'] = 'OK';
        $arr['msg'] = $pbprofile[22];
        $arr['title'] = $pbprofile[21];
      } else {
        $arr['msg'] = implode('<br>', $eString);
      }
    }
    break;
  // Add to basket..
  case 'add':
  case 'add-tracks':
    $chop = explode('_', $_GET['id']);
    if (isset($chop[0], $chop[1])) {
      $ID = (int) $chop[0];
      if ($ID > 0 && in_array($chop[1], array(
        'CD',
        'MP3'
      ))) {
        if ($_GET['ajax'] == 'add-tracks' && empty($_POST['track'])) {
          $arr['msg'] = $jslang[14];
        } else {
          // For tracks, sum total is cost..
          $trackAr = array();
          if ($_GET['ajax'] == 'add-tracks') {
            $typ     = 'track';
            $costing = '0.00';
            $redx    = array();
            $Q       = $DB->db_query("SELECT `id`, `cost` FROM `" . DB_PREFIX . "music`
                       WHERE `id` IN(" . mswSQL(implode(',', array_keys($_POST['track'])), $DB) . ")
                       AND `collection`  = '{$ID}'
                       ");
            while ($T = $DB->db_object($Q)) {
              $costing = mswFMPR($costing + $T->cost);
              $offert  = $COSTING->offer($T->cost, 'track', $ID);
              if ($offert != 'no') {
                $trackAr[$T->id] = $offert;
                $redx[]  = $offert;
              } else {
                $trackAr[$T->id] = $T->cost;
              }
            }
            $disc = (!empty($redx) ? mswFMPR(array_sum($redx)) : 'no');
          } else {
            $Q       = $DB->db_query("SELECT `cost`,`costcd` FROM `" . DB_PREFIX . "collections` WHERE `id` = '{$ID}'");
            $C       = $DB->db_object($Q);
            $costing = ($chop[1] == 'CD' ? $C->costcd : $C->cost);
            $typ     = ($chop[1] == 'CD' ? 'cd' : 'col');
            $disc    = ($chop[1] == 'CD' ? $COSTING->offer($C->costcd, 'cd', $ID) : $COSTING->offer($C->cost, 'col', $ID));
          }
          $CART->add(array(
            'collection' => $ID,
            'cost' => $costing,
            'discount' => $disc,
            'type' => $chop[1],
            'tracks' => ($_GET['ajax'] == 'add-tracks' ? $trackAr : array())
          ));
          $items = $CART->modalItems($BUILDER, array_merge($pbcatlang, $msw_public_checkout_2_5));
          $arr['resp'] = 'OK';
          $arr['title'] = $pbcatlang[3];
          $arr['msg'] = $items;
          $arr['tracks'] = $msw_public_music_2_5[0];
          $arr['cart'] = array(
            'count' => $CART->count(),
            'total' => mswCURF($CART->total(), $SETTINGS->curdisplay),
            'url' => BASE_HREF . $SEO->url('basket', array(), 'yes')
          );
        }
      }
    }
    break;
  case 'basket':
    $items = $CART->modalItems($BUILDER, array_merge($pbcatlang, $msw_public_checkout_2_5));
    $arr['resp'] = 'basket';
    $arr['title'] = $pblang[15];
    $arr['msg'] = $items;
    $arr['nothing'] = str_replace('{text}', $pbbasket[5], $BUILDER->empBskt());
    $arr['cart'] = array(
      'count' => $CART->count(),
      'total' => mswCURF($CART->total(), $SETTINGS->curdisplay),
      'url' => BASE_HREF . $SEO->url('basket', array(), 'yes')
    );
    break;
  case 'rem-modal':
    if (isset($_GET['id']) && isset($_SESSION['cartItems'][$_GET['id']]['void']) && $_SESSION['cartItems'][$_GET['id']]['void'] == 'no') {
      $_SESSION['cartItems'][$_GET['id']]['void'] = 'yes';
    }
    $cc  = $CART->count();
    $arr = array(
      'resp' => 'OK',
      'modal' => array(
        'footer' => str_replace(array(
          '{count}',
          '{total}'
        ), array(
          $cc,
          mswCURF($CART->total(), $SETTINGS->curdisplay)
        ), $pbcatlang[5])
      ),
      'count' => $cc
    );
    break;
  case 'rem-basket':
    switch($_GET['id']) {
      case 'all':
        $_SESSION['cartItems'] = array();
        break;
      default:
        if (isset($_GET['id']) && isset($_SESSION['cartItems'][$_GET['id']]['void']) && $_SESSION['cartItems'][$_GET['id']]['void'] == 'no') {
          $_SESSION['cartItems'][$_GET['id']]['void'] = 'yes';
        }
        break;
    }
    $t = mswCURF($CART->total(), $SETTINGS->curdisplay);
    $c = $CART->count();
    $arr['resp'] = 'OK';
    $arr['total'] = $t;
    $arr['count'] = $c;
    $arr['nothing'] = str_replace('{text}', $pbbasket[5], $BUILDER->empBskt());
    $arr['cart'] = array(
      'count' => $c,
      'total' => $t,
      'url' => BASE_HREF . $SEO->url('basket', array(), 'yes'),
      'is_ship' => $CART->isShipping()
    );
    break;
  case 'login':
    if (isset($_POST['e']) && isset($_POST['p']) && in_array($_GET['id'], array(
      'forgot',
      'enter'
    ))) {
      switch ($_GET['id']) {
        case 'enter':
          if ($_POST['e'] == '' || $_POST['p'] == '') {
            $arr['msg'] = $jslang[16];
          } else {
            if (mswIsValidEmail($_POST['e']) == 'ok') {
              $ACNT = $ACC->account(array(
                'email' => $_POST['e']
              ));
              if (isset($ACNT['accID']) && mswPassHash(array('type' => 'calc', 'val' => $_POST['p'], 'hash' => $ACNT['pass']))) {
                $e     = strtolower($_POST['e']);
                $token = mswEncrypt(SECRET_KEY . $e . mswEncrypt(SECRET_KEY . $ACNT['accID']));
                $ACC->update(array(
                  'token' => $token
                ), $ACNT['accID']);
                $_SESSION[$accent_ky] = array(
                  'id' => $token,
                  'email' => $e
                );
                // Are login events enabled?
                if ($ACNT['login'] == 'yes') {
                  include(PATH . 'control/classes/class.ip.php');
                  $IPGEO           = new geoIP();
                  $IPGEO->settings = $SETTINGS;
                  $lookup          = $IPGEO->lookup($_SERVER['REMOTE_ADDR'],$gblang[19]);
                  $ipAddress       = mswIP(true);
                  if (isset($ipAddress[0])) {
                    $ACC->loginevent(array(
                      'account' => $ACNT['accID'],
                      'ip' => $ipAddress[0],
                      'ts' => $DT->utcTime(),
                      'iso' => strtolower($lookup['iso']),
                      'country' => $lookup['country']
                    ));
                    // Are we notifying admin about multiple ips?
                    if ($SETTINGS->accloginflag > 0) {
                      $diffIP = $ACC->ipclicks($ACNT['accID']);
                      if (count($diffIP) >= $SETTINGS->accloginflag) {
                        $newIPLog        = $ACC->ipclicks($ACNT['accID']);
                        $f_r['{REPORT}'] = $ACC->ipReport($newIPLog, $DT);
                        $f_r['{LIMIT}']  = $SETTINGS->accloginflag;
                        $f_r['{NAME}']   = $ACNT['name'];
                        $msg             = strtr(mswTmp(PATH . 'content/language/email-templates/wm-account-ip-alert.txt'), $f_r);
                        $sbj             = str_replace('{website}', $SETTINGS->website, $emlang[18]);
                        $mmMail->sendMail(array(
                          'to_name' => $SETTINGS->website,
                          'to_email' => $SETTINGS->email,
                          'from_name' => ($SETTINGS->smtp_from ? $SETTINGS->smtp_from : $SETTINGS->website),
                          'from_email' => ($SETTINGS->smtp_email ? $SETTINGS->smtp_email : $SETTINGS->email),
                          'subject' => $sbj,
                          'msg' => $mmMail->htmlWrapper(array(
                            'global' => $gblang,
                            'title' => $sbj,
                            'header' => $sbj,
                            'content' => mswNL2BR($msg),
                            'footer' => (!defined('LICENCE_VER') || LICENCE_VER == 'locked' ? $gblang[41] : '')
                          )),
                          'reply-to' => array(
                            'name' => ($SETTINGS->smtp_rfrom ? $SETTINGS->smtp_rfrom : ($SETTINGS->smtp_from ? $SETTINGS->smtp_from : $SETTINGS->website)),
                            'email' => ($SETTINGS->smtp_remail ? $SETTINGS->smtp_remail : ($SETTINGS->smtp_email ? $SETTINGS->smtp_email : $SETTINGS->email))
                          ),
                          'other' => $SETTINGS->smtp_other,
                          'plain' => $msg,
                          'htmlWrap' => 'yes'
                        ), $gblang);
                        $mmMail->smtpClose();
                      }
                    }
                  }
                }
                $arr = array(
                  'resp' => 'rdr',
                  'wind' => BASE_HREF . $SEO->url('account', array(), 'yes')
                );
              } else {
                $arr['msg'] = $jslang[17];
              }
            } else {
              $arr['msg'] = $jslang[15];
            }
          }
          break;
        case 'forgot':
          if ($_POST['e'] == '') {
            $arr['msg'] = $jslang[15];
          } else {
            if (mswIsValidEmail($_POST['e']) == 'ok') {
              $ACNT = $ACC->account(array(
                'email' => $_POST['e']
              ));
              // Valid account, so reset password and send email..
              if (isset($ACNT['id'])) {
                $newPass = $ACC->password();
                $ACC->update(array(
                  'pass' => mswPassHash(array('type' => 'add', 'pass' => $newPass))
                ), $ACNT['id']);
                $f_r['{NAME}']  = $ACNT['name'];
                $f_r['{EMAIL}'] = $ACNT['email'];
                $f_r['{PASS}']  = $newPass;
                $f_r['{ACC_LOGIN}'] = BASE_HREF . $SEO->url('account', array(), 'yes');
                $msg            = strtr(mswTmp(PATH . 'content/language/email-templates/password-reset.txt'), $f_r);
                $sbj            = str_replace('{website}', $SETTINGS->website, $emlang[6]);
                $mmMail->sendMail(array(
                  'to_name' => $ACNT['name'],
                  'to_email' => $ACNT['email'],
                  'from_name' => ($SETTINGS->smtp_from ? $SETTINGS->smtp_from : $SETTINGS->website),
                  'from_email' => ($SETTINGS->smtp_email ? $SETTINGS->smtp_email : $SETTINGS->email),
                  'subject' => $sbj,
                  'msg' => $mmMail->htmlWrapper(array(
                    'global' => $gblang,
                    'title' => $sbj,
                    'header' => $sbj,
                    'content' => mswNL2BR($msg),
                    'footer' => (!defined('LICENCE_VER') || LICENCE_VER == 'locked' ? $gblang[41] : '')
                  )),
                  'reply-to' => array(
                    'name' => ($SETTINGS->smtp_rfrom ? $SETTINGS->smtp_rfrom : ($SETTINGS->smtp_from ? $SETTINGS->smtp_from : $SETTINGS->website)),
                    'email' => ($SETTINGS->smtp_remail ? $SETTINGS->smtp_remail : ($SETTINGS->smtp_email ? $SETTINGS->smtp_email : $SETTINGS->email))
                  ),
                  'plain' => $msg,
                  'htmlWrap' => 'yes'
                ), $gblang);
                $mmMail->smtpClose();
              }
              // Return message..
              $arr['resp'] = 'OK';
              $arr['title'] = $pbaccount[14];
              $arr['msg'] = str_replace('{email}', mswSH($_POST['e']), $pbaccount[15]);
            } else {
              $arr['msg'] = $jslang[15];
            }
          }
          break;
      }
    }
    break;
  case 'method-reload':
    $ID = (int) $_GET['id'];
    if ($ID > 0) {
      $method = $BUILDER->methods($ID);
      $arr    = array(
        'resp' => 'OK',
        'method' => $method
      );
    }
    break;
  case 'address':
    $ID = (int) $_GET['id'];
    if (isset($systemAcc['email']) && $ID > 0) {
      $EX = $ACC->account(array(
        'email' => $systemAcc['email']
      ));
      if (isset($EX['shipping'])) {
        $arr['resp'] = 'OK';
        $arr['sys']  = array(
          'method' => $EX['shipping'],
          'address1' => mswSH($EX['address1']),
          'address2' => mswSH($EX['address2']),
          'city' => mswSH($EX['city']),
          'county' => mswSH($EX['county']),
          'postcode' => mswSH($EX['postcode']),
          'country' => $EX['addCountry'],
          'couponhtml' => ''
        );
      }
    }
    break;
  case 'resend-verification':
    if (isset($systemAcc['email'])) {
      $ACNT = $ACC->account(array(
        'email' => $systemAcc['email']
      ));
      if (isset($ACNT['accID'])) {
        if ($ACNT['enabled'] == 'no') {
          $code = $ACC->password(15, true);
          $ACC->update(array(
            'system1' => $code,
            'system2' => 'resend'
          ), $systemAcc['accID']);
          $f_r['{NAME}'] = $systemAcc['name'];
          $f_r['{CODE}'] = $code;
          $f_r['{ID}']   = $systemAcc['accID'];
          $msg           = strtr(mswTmp(PATH . 'content/language/email-templates/account-verification.txt'), $f_r);
          $sbj           = str_replace('{website}', $SETTINGS->website, $emlang[9]);
          $mmMail->sendMail(array(
            'to_name' => $systemAcc['name'],
            'to_email' => $systemAcc['email'],
            'from_name' => ($SETTINGS->smtp_from ? $SETTINGS->smtp_from : $SETTINGS->website),
            'from_email' => ($SETTINGS->smtp_email ? $SETTINGS->smtp_email : $SETTINGS->email),
            'subject' => $sbj,
            'msg' => $mmMail->htmlWrapper(array(
              'global' => $gblang,
              'title' => $sbj,
              'header' => $sbj,
              'content' => mswNL2BR($msg),
              'footer' => (!defined('LICENCE_VER') || LICENCE_VER == 'locked' ? $gblang[41] : '')
            )),
            'reply-to' => array(
              'name' => ($SETTINGS->smtp_rfrom ? $SETTINGS->smtp_rfrom : ($SETTINGS->smtp_from ? $SETTINGS->smtp_from : $SETTINGS->website)),
              'email' => ($SETTINGS->smtp_remail ? $SETTINGS->smtp_remail : ($SETTINGS->smtp_email ? $SETTINGS->smtp_email : $SETTINGS->email))
            ),
            'plain' => $msg,
            'htmlWrap' => 'yes'
          ), $gblang);
          $mmMail->smtpClose();
          $arr['resp'] = 'OK';
          $arr['msg'] = str_replace('{email}', mswSH($systemAcc['email']), $pbaccount[22]);
          $arr['title'] = $pbaccount[21];
        } else {
          $arr['msg'] = $msw_public_int_2_5[2];
        }
      }
    }
    break;
  case 'tac':
    if ($SETTINGS->termsenable == 'yes') {
      $arr['resp'] = 'info';
      $arr['title'] = $checklang[12];
      $arr['msg'] = mswNL2BR($SETTINGS->termsmsg);
    }
    break;
  case 'clear-all-basket':
    $_SESSION['cartItems'] = array();
    unset($_SESSION['cartItems']);
    $arr  = array(
       'resp' => 'OK-BASKET',
       'nothing' => str_replace('{text}', $pbbasket[5], $BUILDER->empBskt()),
       'count' => 0
    );
    break;
  case 'tax-info':
    $tax  = $CART->taxBreakdown($BUILDER);
    $frep = array(
      '{ITEMS}' => (TAX_HTML_TAGS ? '<span class="highlight">' : '') . $tax['items'] . (TAX_HTML_TAGS ? '</span>' : ''),
      '{TOTAL}' => (TAX_HTML_TAGS ? '<span class="highlight">' : '') . $tax['total'] . (TAX_HTML_TAGS ? '</span>' : ''),
      '{COUPON}' => (TAX_HTML_TAGS ? '<span class="highlight">' : '') . $tax['coupon'] . (TAX_HTML_TAGS ? '</span>' : ''),
      '{COUNTRY}' => (TAX_HTML_TAGS ? '<span class="highlight">' : '') . $tax['country'] . (TAX_HTML_TAGS ? '</span>' : ''),
      '{RATE}' => (TAX_HTML_TAGS ? '<span class="highlight">' : '') . $tax['rate'] . (TAX_HTML_TAGS ? '</span>' : ''),
      '{SHIPPING}' => (TAX_HTML_TAGS ? '<span class="highlight">' : '') . $tax['shipping'] . (TAX_HTML_TAGS ? '</span>' : ''),
      '{AMOUNT}' => (TAX_HTML_TAGS ? '<span class="highlight">' : '') . $tax['amount'] . (TAX_HTML_TAGS ? '</span>' : ''),
      '{ITEMS2}' => (TAX_HTML_TAGS ? '<span class="highlight">' : '') . $tax['items2'] . (TAX_HTML_TAGS ? '</span>' : ''),
      '{TOTAL2}' => (TAX_HTML_TAGS ? '<span class="highlight">' : '') . $tax['total2'] . (TAX_HTML_TAGS ? '</span>' : ''),
      '{COUPON2}' => (TAX_HTML_TAGS ? '<span class="highlight">' : '') . $tax['coupon2'] . (TAX_HTML_TAGS ? '</span>' : ''),
      '{COUNTRY2}' => (TAX_HTML_TAGS ? '<span class="highlight">' : '') . $tax['country2'] . (TAX_HTML_TAGS ? '</span>' : ''),
      '{RATE2}' => (TAX_HTML_TAGS ? '<span class="highlight">' : '') . $tax['rate2'] . (TAX_HTML_TAGS ? '</span>' : ''),
      '{AMOUNT2}' => (TAX_HTML_TAGS ? '<span class="highlight">' : '') . $tax['amount2'] . (TAX_HTML_TAGS ? '</span>' : ''),
      '{TOTAL-TAX}' => (TAX_HTML_TAGS ? '<span class="highlight" style="font-size:22px">' : '') . $tax['total-tax'] . (TAX_HTML_TAGS ? '</span>' : '')
    );
    $html = strtr(mswTmp(PATH . 'content/language/tax-info.txt'), $frep);
    $arr['resp'] = 'info';
    $arr['title'] = $pbbasket[31];
    $arr['msg'] = mswNL2BR($html);
    break;
  // Contact page..
  case 'support':
    // Assign data variables..
    $send = 'yes';
    $er   = 0;
    $data   = array(
      'name' => (isset($_POST['nm']) ? $_POST['nm'] : ''),
      'email' => (isset($_POST['em']) ? $_POST['em'] : ''),
      'subject' => (isset($_POST['sb']) ? $_POST['sb'] : ''),
      'comments' => (isset($_POST['cm']) ? $_POST['cm'] : ''),
      'antispam' => (isset($_POST['as']) ? $_POST['as'] : ''),
      'message' => (isset($_POST['mg']) ? $_POST['mg'] : '')
    );
    // Basic error check..
    foreach ($data AS $k => $v) {
      if ($k != 'message') {
        switch($k) {
          case 'antispam':
            // Check spam answer is correct if enabled..
            if (ENABLE_ANTI_SPAM && isset($_SESSION[$spmky]['slot'])) {
              if (isset($antiSpam[$_SESSION[$spmky]['slot']]['a'])) {
                if ($data['antispam'] == '' || strtolower($antiSpam[$_SESSION[$spmky]['slot']]['a']) != strtolower($data['antispam'])) {
                  $arr['msg'] = $msw_public_int_2_5[18];
                  echo $JSON->encode($arr);
                  exit;
                }
              }
            }
            // If enabled, session slot should always exist. If it doesn`t fatal error..
            if (ENABLE_ANTI_SPAM && !isset($_SESSION[$spmky]['slot'])) {
              echo $JSON->encode($arr);
              exit;
            }
            break;
          default:
            if ($v == '') {
              ++$er;
            }
            break;
        }
      }
    }
    if ($er > 0) {
      $arr['msg'] = $pbcontact[8];
    } else {
      // If the message var ever has a value, don`t send email, but show ok message
      if ($data['message'] != '') {
        $send = 'no';
      }
      if ($send == 'yes') {
        // Send message..
        $mmMail->sendMail(array(
          'to_name' => $SETTINGS->website,
          'to_email' => $SETTINGS->email,
          'from_name' => $data['name'],
          'from_email' => $data['email'],
          'subject' => $data['subject'],
          'msg' => $mmMail->htmlWrapper(array(
            'global' => $gblang,
            'title' => $data['subject'],
            'header' => $data['subject'],
            'content' => mswNL2BR($data['comments']),
            'footer' => (!defined('LICENCE_VER') || LICENCE_VER == 'locked' ? $gblang[41] : '')
          )),
          'reply-to' => array(
            'name' => $data['name'],
            'email' => $data['email']
          ),
          'other' => $SETTINGS->smtp_other,
          'plain' => $data['comments'],
          'htmlWrap' => 'yes'
        ), $gblang);
        $mmMail->smtpClose();
      }
      $arr['resp'] = 'OK';
      $arr['title'] = $pbcontact[6];
      $arr['msg'] = mswNL2BR($pbcontact[7]);
    }
    break;
  // Spam reloaded..
  case 'spm-rld':
    $_SESSION[$spmky] = array();
    if (ENABLE_ANTI_SPAM && count($antiSpam) > 1) {
      $slt = rand(0, (count($antiSpam) - 1));
      $_SESSION[$spmky]['q'] = (isset($antiSpam[$slt]['q']) ? $antiSpam[$slt]['q'] : '');
      $_SESSION[$spmky]['slot'] = $slt;
    }
    $arr['spamreloaded'] = (isset($_SESSION[$spmky]['q']) ? $_SESSION[$spmky]['q'] : '');
    break;
  // Search filters
  case 'search-filters':
    include(PATH . 'control/system/filters.php');
    if (isset($_POST['filter']) && in_array($_POST['filter'], array_keys($listFilters))) {
      $_SESSION['mmFilters'] = $_POST['filter'];
    } else {
      if (isset($_SESSION['mmFilters'])) {
        $_SESSION['mmFilters'] = '';
        unset($_SESSION['mmFilters']);
      }
    }
    break;
}

echo $JSON->encode($arr);
exit;

?>