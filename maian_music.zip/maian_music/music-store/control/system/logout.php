<?php

/* System Module
----------------------------------------------------------*/

if (!defined('PARENT') || !defined('BASE_HREF')) {
  mswEcode($gblang[4],'403');
}

if (isset($_SESSION[$accent_ky])) {
  $_SESSION[$accent_ky] = array();
  unset($_SESSION[$accent_ky]);
}

header("Location: " . BASE_HREF . $SEO->url('login', array(),'yes'));

?>