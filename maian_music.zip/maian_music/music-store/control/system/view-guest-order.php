<?php

/* System Module
----------------------------------------------------------*/

define('IS_GUEST_VIEW', 1);

if (!defined('PARENT')) {
  mswEcode($gblang[4], '403');
}

$pluginLoader[] = 'mmusic';

$ORDER = $BUILDER->load('order');

if (!isset($ORDER->id)) {
  mswEcode($gblang[4], '403');
}

if ($ORDER->account > 0) {
  header("Location: " . BASE_HREF . $SEO->url('login', array(), 'yes'));
  exit;
}

if ($ORDER->locked == 'yes') {
  header("Location: index.php?msg=6&id=" . $ORDER->id);
  exit;
}

if ($SETTINGS->approve == 'yes' && $ORDER->approved == 'no') {
  header("Location: index.php?msg=11");
  exit;
}

$title = $pbaccount[6] . ' (#' . mswINV($ORDER->invoice) . ')';

include(PATH . 'control/system/header.php');

$tpl = new Savant3();
$tpl->assign('TXT', array(
  $pbaccount[6],
  $pborders[7],
  $pborders[8],
  $pborders[9],
  $pborders[10],
  $pborders[11],
  $pborders[12],
  $pborders[13],
  $pborders[5],
  $pborders[17],
  $pborders[18],
  $pborders[19],
  $pborders[20],
  $pborders[21],
  $pborders[22],
  $pborders[23],
  $pborders[24],
  $pborders[26],
  $msw_public_int_2_5,
  $msw_sales_2_5
));
$tpl->assign('URL', array(
  BASE_HREF . $SEO->url('orders', array(), 'yes')
));
$tpl->assign('INVOICE_NO', mswINV($ORDER->invoice));
$tpl->assign('ORDER', $ORDER);

$ship = ($ORDER->shipping > 0 ? $ORDER->shipping : '0.00');
$tax  = ($ORDER->tax > 0 ? $ORDER->tax : '0.00');
$tax2 = ($ORDER->tax2 > 0 ? $ORDER->tax2 : '0.00');
$taxT = mswFMPR($tax + $tax2);
if ($ORDER->coupon) {
  $cp = mswCD(unserialize($ORDER->coupon));
  if (isset($cp[0], $cp[1], $cp[2], $cp[3]) && $cp[1] > 0) {
    $discount   = $cp[1];
    $couponCode = $cp[0];
    $disctang   = $cp[2];
    $discdigl   = $cp[3];
  }
  $tot = ($ORDER->saleTotal > 0 ? mswFMPR($ORDER->saleTotal - $discount) : '0.00');
} else {
  $tot = ($ORDER->saleTotal > 0 ? $ORDER->saleTotal : '0.00');
}

$orderDataT = $CART->music($BUILDER, array($ORDER->id, $ORDER->code), 'shipped', $pborders);
$orderDataD = $CART->music($BUILDER, array($ORDER->id, $ORDER->code), 'download', $pborders);
$totalsBreakdown = $CART->totals($ORDER->id);

$tpl->assign('ORDER_DETAIL', $orderDataD[0]);
$tpl->assign('ORDER_DETAIL2', $orderDataT[0]);
$tpl->assign('GUEST', (defined('IS_GUEST_VIEW') ? 'yes' : 'no'));
$tpl->assign('COMPANY', mswNL2BR(mswSanitize(mswCD($SETTINGS->company))));
$tpl->assign('INFO', array(
  'order-id' => $ORDER->id,
  'date' => $DT->dateTimeDisplay($ORDER->ts, $SETTINGS->dateformat),
  'method' => mswSH($ORDER->paymentMethod),
  'guest_name' => mswSH($ORDER->gname),
  'guest_email' => mswSH($ORDER->gemail),
  'sub' => mswCURF($ORDER->saleTotal, $SETTINGS->curdisplay),
  'dig-sub' => $totalsBreakdown['digital'],
  'tang-sub' => $totalsBreakdown['tangible'],
  'shipping' => mswCURF($ship, $SETTINGS->curdisplay),
  'taxrate' => ($ORDER->taxRate > 0 ? $ORDER->taxRate : ''),
  'taxrate2' => ($ORDER->taxRate2 > 0 ? $ORDER->taxRate2 : ''),
  'tax' => mswCURF($tax, $SETTINGS->curdisplay),
  'tax2' => mswCURF($tax2, $SETTINGS->curdisplay),
  'total' => mswCURF(($tot + $ship + $taxT), $SETTINGS->curdisplay),
  'coupon' => (isset($discount) ? '-' . mswCURF($discount, $SETTINGS->curdisplay) : mswCURF('0.00', $SETTINGS->curdisplay)),
  'coupon-discounts' => array(
    'tangible' => (isset($disctang) ? '-' . mswCURF($disctang, $SETTINGS->curdisplay) : mswCURF('0.00', $SETTINGS->curdisplay)),
    'digital' => (isset($discdigl) ? '-' . mswCURF($discdigl, $SETTINGS->curdisplay) : mswCURF('0.00', $SETTINGS->curdisplay))
  ),
  'itemcnt' => array(
    $orderDataT[1][0],
    $orderDataD[1][1]
  ),
  'sub-raw' => array(
    $totalsBreakdown['digital-raw'],
    $totalsBreakdown['tangible-raw'],
    $ship,
    $tax,
    $tax2,
    (isset($discount) ? $discount : '0.00'),
    array(
      'tangible' => (isset($disctang) ? $disctang : '0.00'),
      'digital' => (isset($discdigl) ? $discdigl : '0.00')
    )
  )
));

// Global template vars..
include(PATH . 'control/lib/global.php');

// Load template..
$tpl->display('content/' . THEME . '/order-view.tpl.php');

include(PATH . 'control/system/footer.php');


?>