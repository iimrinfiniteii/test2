<?php

/* System Module
----------------------------------------------------------*/

if (!defined('PARENT') || !defined('BASE_HREF')) {
  mswEcode($gblang[4],'403');
}

$pluginLoader[] = 'mmusic';
$pluginLoader[] = 'music-ops';
$pluginLoader[] = 'soundmanager';

$COL = $BUILDER->load('collection');

if (!isset($COL->id)) {
  include(PATH . 'control/system/404.php');
  exit;
}

if ($COL->metakeys) {
  $metaData[1] = mswSH($COL->metakeys);
}
if ($COL->metadesc) {
  $metaData[0] = mswSH($COL->metadesc);
}

$title = ($COL->title ? $COL->title : $COL->name);

// Update collection hits count..
$BUILDER->hitcounter($COL->id);

$url = array(
  'seo' => array(
    ($COL->slug ? $COL->slug : $SEO->filter($COL->name)),
    ($COL->slug=='' ? $COL->id : '')
  ),
  'standard' => array(
    '#' => $COL->id
  )
);

// Recent view..
$BUILDER->recentview($COL->id);

// Open graph..
$og['title'] = $title;
$og['url']   = BASE_HREF . $SEO->url('collection', $url);
if ($COL->coverart) {
  $cArt = $BUILDER->cover($COL->coverart);
  $og['image'] = BASE_HREF . $cArt;
  $og['img-path'] = PATH . $cArt;
}

// Add this api..
$addthisapi = $BUILDER->params('addthis');

include(PATH . 'control/system/header.php');

$tpl  = new Savant3();
$tpl->assign('TXT', array(
  mswSH($COL->name),
  $pbcatlang[7],
  $pbcatlang[8],
  $pbcatlang[9],
  $pbcatlang[1],
  $pbcatlang[2],
  $pbcatlang[10],
  $pbcatlang[11],
  $pbcatlang[12],
  $pbcatlang[13],
  $pbcatlang[14],
  $pbcatlang[15],
  $pbcatlang[16],
  $pbcatlang[17],
  $pbcatlang[19],
  $pbcatlang[21],
  $pbcatlang[25],
  $pbcatlang[26]
));

// Offer check..
$disc  = ($COL->cost!='' ? $COSTING->offer($COL->cost,'col',$COL->id) : '');
$disc2 = ($COL->costcd!='' ? $COSTING->offer($COL->costcd,'cd',$COL->id) : '');

$tpl->assign('COST', ($COL->cost!='' ? mswCURF((!in_array($disc,array('no','')) && $COL->cost!=$disc ? $disc : $COL->cost),$SETTINGS->curdisplay) : ''));
$tpl->assign('COSTCD', ($COL->costcd!='' ? mswCURF((!in_array($disc2,array('no','')) && $COL->costcd!=$disc2 ? $disc2 : $COL->costcd),$SETTINGS->curdisplay) : ''));
$tpl->assign('TRACKS', $BUILDER->tracks($COL->id));
$tpl->assign('COMMENTS', $BUILDER->comments($COL));
$tpl->assign('RELATED', $BUILDER->related($COL->related, $cmd, array_merge($pbcatlang, $msw_public_int_2_5)));
$tpl->assign('TAGS', $BUILDER->tags($COL->searchtags, $page));
$tpl->assign('STYLES', $BUILDER->colStyles($COL->id));
$tpl->assign('SOCIAL', ($COL->social ? unserialize($COL->social) : array()));
$tpl->assign('HIT_COUNTER', str_replace('{counter}', mswNFM($COL->views), $pbcatlang[18]));
$tpl->assign('API', array_map('mswSanitize', $addthisapi));

// Global template vars..
include(PATH . 'control/lib/global.php');

// Load template..
$tpl->display('content/' . THEME . '/collection.tpl.php');

include(PATH . 'control/system/footer.php');

?>