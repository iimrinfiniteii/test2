<?php

/* System Module
----------------------------------------------------------*/

if (!defined('PARENT') || !defined('BASE_HREF')) {
  mswEcode($gblang[4],'403');
}

$title = $msw_public_int_2_5[10];

include(PATH . 'control/antispam.php');
include(PATH . 'control/system/header.php');

$tpl  = new Savant3();
$tpl->assign('TXT', array(
  $msw_public_int_2_5
));

$_SESSION[$spmky] = array();
if (ENABLE_ANTI_SPAM && !empty($antiSpam)) {
  $slt = rand(0, (count($antiSpam) - 1));
  $_SESSION[$spmky]['q'] = (isset($antiSpam[$slt]['q']) ? $antiSpam[$slt]['q'] : '');
  $_SESSION[$spmky]['slot'] = $slt;
}

$tpl->assign('ANTI_SPAM', (isset($_SESSION[$spmky]['q']) ? $_SESSION[$spmky]['q'] : ''));

// Global template vars..
include(PATH . 'control/lib/global.php');

// Load template..
$tpl->display('content/' . THEME . '/support.tpl.php');

include(PATH . 'control/system/footer.php');


?>