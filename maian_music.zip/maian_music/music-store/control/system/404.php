<?php

/* System Module
----------------------------------------------------------*/

if (!defined('PARENT') || !defined('BASE_HREF')) {
  mswEcode($gblang[4], '403');
}

$title = $gblang[43];

include(PATH . 'control/system/header.php');

$tpl = new Savant3();
$tpl->assign('TXT', array(
  $gblang[43],
  $gblang[44],
  $msw_public_int_2_5
));

// Global template vars..
include(PATH . 'control/lib/global.php');

// Load template..
$tpl->display('content/' . THEME . '/404.tpl.php');

include(PATH . 'control/system/footer.php');

?>