<?php

/* System Module
----------------------------------------------------------*/

if (!defined('PARENT') || !defined('BASE_HREF')) {
  mswEcode($gblang[4],'403');
}

if (defined('NO_HEADER')) {
  exit;
}

// Always load RSS if on..
if (!isset($pluginData['rss']) && $SETTINGS->rss == 'yes') {
  $pluginData['rss'] = BASE_HREF . $SEO->url('rss-home',array(),'yes');
}

// Is open graph enabled?
$openGraph = $BUILDER->structured(array(
  'url'      => (isset($og['url']) ? $og['url'] : BASE_HREF),
  'site'     => mswSH($SETTINGS->website),
  'image'    => (isset($og['image']) ? $og['image'] : BASE_HREF . 'content/' . THEME . '/images/fb-default.png'),
  'img-path' => (isset($og['img-path']) ? $og['img-path'] : PATH . 'content/' . THEME . '/images/fb-default.png'),
  'desc'     => mswSH((isset($og['desc']) ? $og['desc'] : str_replace('{website}', $SETTINGS->website, $msw_public_global_2_5[0]))),
  'title'    => mswSH((isset($og['title']) ? $og['title'] . ': ' . $SETTINGS->website : $SETTINGS->website))
));
if ($openGraph) {
  $pluginLoader[] = 'open-graph';
  $pluginData['open-graph'] = $openGraph;
}

$config = array(
 'template_path' => array(PATH)
);

$tpl  = new Savant3($config);
$tpl->assign('CHARSET', $gblang[0]);
$tpl->assign('LANG', $gblang[2]);
$tpl->assign('DIR', $gblang[1]);
$tpl->assign('TITLE', ($title ? mswSH($title) . ': ' : '') . mswSH($SETTINGS->website) . (LICENCE_VER != 'unlocked' ? ' (' . SCRIPT_NAME . ')' : '') . (LICENCE_VER != 'unlocked' ? ' - Free Version' : '') . (defined('DEV_BETA') && DEV_BETA == 'yes' ? ' - BETA VERSION' : ''));
$tpl->assign('META_DESC', mswSH($metaData[0]));
$tpl->assign('META_KEYS', mswSH($metaData[1]));
$tpl->assign('STORE', mswSH($SETTINGS->website));
$tpl->assign('TAGLINE', mswSH($pblang[0]));
$tpl->assign('BASKET_COUNT', CART_COUNT);
$tpl->assign('META_REFRESH', (isset($loadMetaRefresh) ? $loadMetaRefresh : ''));
$tpl->assign('TXT', array(
  $pblang[5],
  $pblang[6],
  $pblang[8],
  $pblang[1],
  $pblang[2],
  $pblang[3],
  $pblang[4],
  str_replace('{count}', CART_COUNT, $pblang[7]),
  $pblang[9],
  $pblang[10],
  $pbaccount[0],
  $pbaccount[1],
  $pbaccount[2],
  $pbaccount[3],
  $pbaccount[16],
  $msw_public_int_2_5
));
$tpl->assign('URL', array(
  BASE_HREF,
  BASE_HREF . $SEO->url('account', array(), 'yes'), //account
  BASE_HREF . $SEO->url('latest', array(), 'yes'), //latest
  BASE_HREF . $SEO->url('popular', array(), 'yes'), //popular
  BASE_HREF . $SEO->url('specials', array(), 'yes'), //specials
  BASE_HREF . $SEO->url('basket', array(), 'yes'), // basket
  BASE_HREF . $SEO->url('profile', array(), 'yes'), // profile
  BASE_HREF . $SEO->url('orders', array(), 'yes'), //orders
  BASE_HREF . $SEO->url('logout', array(), 'yes'), //logout
  BASE_HREF . $SEO->url('support', array(), 'yes') //logout
));
$tpl->assign('KEYS', (isset($keys) ? mswSH($keys) : ''));
$tpl->assign('TOTAL', str_replace('{cost}', 0, $pblang[16]));
$tpl->assign('PLUGIN_LOADER', $BUILDER->plugins('header', $pluginLoader, $pluginData));

// Global template vars..
include(PATH . 'control/lib/global.php');

// Load template..
$tpl->display('content/' . THEME . '/header.tpl.php');

?>
