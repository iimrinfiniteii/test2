<?php

/* GLOBAL VARS
   Sent to all .tpl.php template files
-----------------------------------------------------------------*/

if (!defined('PARENT') || !isset($SETTINGS->id)) {
  mswEcode($gblang[4], '403');
}

$tpl->assign('SETTINGS', $SETTINGS);
// JS Loader..
switch($cmd) {
  case 'view-guest-order':
    $jsLoader = 'view-order';
    break;
  default:
    $jsLoader = $cmd;
    break;
}
$tpl->assign('JS_LOADER', ($SETTINGS->sysstatus == 'yes' && isset($cmd, $jsLoader) ? $jsLoader : ''));
$tpl->assign('ACCOUNT', (isset($systemAcc) ? $systemAcc : ''));
$tpl->assign('COLLECTION', (isset($COL->id) ? $COL : ''));
$tpl->assign('FILTERS', (isset($listFilters) ? $listFilters : ''));
$tpl->assign('MENU_STYLES', (isset($styles_arr) ? $styles_arr : array()));
$tpl->assign('OTHER', (isset($pages_arr) ? $pages_arr : array()));
$tpl->assign('TXT_GLOBAL', (isset($pbglobalfront) ? $pbglobalfront : ''));
$tpl->assign('DEF_PANEL', (isset($systemAcc['accID']) ? '_acc' : '_styles'));
$tpl->assign('BOXES', (isset($boxes_arr) ? $boxes_arr : array()));
$tpl->assign('PLATFORM', (defined('MSW_PFDTCT') ? MSW_PFDTCT : 'pc'));
$tpl->assign('CONF_MSG', (isset($confMsg) ? mswJS($confMsg) : ''));

$tpl->assign('DT', (isset($DT) && method_exists($DT, 'tsToDate') ? $DT : ''));
$tpl->assign('BUILD', (isset($BUILDER) && method_exists($BUILDER, 'boxes') ? $BUILDER : ''));
$tpl->assign('SEO', (isset($SEO) && method_exists($SEO, 'url') ? $SEO : ''));
$tpl->assign('MMPD', (isset($PDTC) && method_exists($PDTC, 'setHttpHeaders') ? $PDTC : ''));

$tpl->assign('POPULAR_MUSIC', (isset($BUILDER) && method_exists($BUILDER, 'popular') ? $BUILDER->popular() : ''));
$tpl->assign('RECENTLY_VIEWED', (isset($BUILDER) && method_exists($BUILDER, 'recentview') ? $BUILDER->recentview() : ''));

?>