<?php

/* INSTALLER
------------------------------------------------*/

header('Expires: Sun, 01 Jan 2014 00:00:00 GMT');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Cache-Control: post-check=0, pre-check=0', FALSE);
header('Pragma: no-cache');
header('Content-type: text/html; charset=utf-8');

@ini_set('session.cookie_httponly', 1);

if (function_exists('date_default_timezone_get') && @date_default_timezone_get()) {
  date_default_timezone_set(@date_default_timezone_get());
}

if (!function_exists('mysqli_connect')) {
  die('!!! <b>The mysqli functions are not enabled on your server. Your must enable these functions before you can continue.</b><br><br>
  <a href="http://php.net/manual/en/book.mysqli.php">http://php.net/manual/en/book.mysqli.php</a>');
}

define('PARENT', 1);
define('PATH', dirname(__file__) . '/');
define('REL_PATH', substr(PATH, 0, strpos(PATH, 'install') - 1) . '/');

include(PATH . 'control/config.php');
include(REL_PATH . 'control/timezones.php');
include(REL_PATH . 'control/defined.php');
include(REL_PATH . 'control/connect.php');
include(REL_PATH . 'control/functions.php');
include(PATH . 'control/functions.php');
include(REL_PATH . 'control/constants.php');
include(REL_PATH . 'control/classes/class.db.php');
include(REL_PATH . 'control/classes/class.json.php');

//---------------------------------------------------
// Error reporting
//---------------------------------------------------

include(REL_PATH . 'control/classes/class.errors.php');
if (ERR_HANDLER_ENABLED) {
  register_shutdown_function('msFatalErr');
  set_error_handler('msErrorhandler');
}

$DB = new db();
$JSON = new jsonHandler();
$DB->db_conn();

include(PATH . 'control/arrays.php');

$cmd     = (isset($_GET['s']) ? $_GET['s'] : '1');
$title   = SCRIPT_NAME . ': Upgrade';
$count   = 0;
$dcount  = 0;
$defChar = 'utf8_general_ci';
$sqlVer  = $DB->db_version();

$Q = $DB->db_query("SELECT * FROM `" . DB_PREFIX . "settings`", false);
$SETTINGS = $DB->db_object($Q);

// Legacy version..
if (!isset($SETTINGS->id)) {
  die('<div style="font:15px arial;background:#ff9999;color:#fff;padding:20px;border:2px dashed #555">[ FATAL ERROR ] Invalid database connection, please check your connection parameters.</div>');
} else {
  if (!isset($SETTINGS->httppath)) {
    die('<div style="font:15px arial;background:#ff9999;color:#fff;padding:20px;border:2px dashed #555">
    Your version of ' . SCRIPT_NAME . ' appears to be older than v2.0, so an upgrade is not possible.<br><br>
    Please install a fresh copy of the latest version of ' . SCRIPT_NAME . '.<br><br>
    <a href="https://www.maianmusic.com/download.html">https://www.maianmusic.com/download.html</a><br><br>
    Thank you and sorry for any inconvenience.</div>');
  }
}

if (isset($_GET['ajax-ops'])) {
  include(PATH . 'control/_ajax.php');
  exit;
}

include(PATH . 'content/header.php');
include(PATH . 'content/upgrade.php');
include(PATH . 'content/footer.php');

?>