<?php

/* INSTALLER - SQL TABLES
--------------------------------------------------------*/

if (!defined('PARENT') && defined('INSTALL_RUN')) {
  exit;
}

if (is_dir(PATH . 'control/sql/tables')) {
  $dir = opendir(PATH . 'control/sql/tables');
  while (false !== ($read = readdir($dir))) {
    if (substr(strtolower($read), -4) == '.sql') {
      $table = substr($read, 0, -4);
      $tbdta = str_replace(array('{prefix}', '{tabletype}'), array(DB_PREFIX, $tableType), file_get_contents(PATH . 'control/sql/tables/' . $read));
      $DB->db_query("DROP TABLE IF EXISTS `" . DB_PREFIX . $table . "`");
      $query = $DB->db_query($tbdta, true);
      if ($query === 'err') {
        $tableD[] = DB_PREFIX . $table;
        $ERR      = $DB->db_error(true);
        mswInsLog(DB_PREFIX . $table, $ERR[1], $ERR[0], __LINE__, __FILE__, $DB);
        ++$count;
      }
    }
  }
  closedir($dir);
}

?>