<?php

/* INSTALLER - MODULES
--------------------------------------------------*/

$modules = array(
  array(
    'CURL',
    'curl_init',
    'function',
    'http://php.net/manual/en/book.curl.php'
  ),
  array(
    'MYSQLI',
    'mysqli_connect',
    'function',
    'http://php.net/manual/en/book.mysqli.php'
  ),
  array(
    'JSON',
    'json_encode',
    'function',
    'http://php.net/manual/en/book.json.php'
  ),
  array(
    'ZipArchive',
    'ZipArchive',
    'class',
    'http://php.net/manual/en/class.ziparchive.php'
  ),
  array(
    'SimpleXML',
    'simplexml_load_string',
    'function',
    'http://php.net/manual/en/book.simplexml.php'
  ),
  array(
    'PASSWORD HASH API',
    'password_hash',
    'function',
    'http://php.net/manual/en/book.password.php'
  )
);

switch(MSW_PHP) {
  case 'old':
    $modules[] = array(
      'MCRYPT',
      'mcrypt_decrypt',
      'function',
      'http://php.net/manual/en/book.mcrypt.php'
    );
    break;
  case 'new':
    $modules[] = array(
      'OPENSSL',
      'openssl_encrypt',
      'function',
      'http://php.net/manual/en/ref.openssl.php'
    );
    break;
}

/* PERMISSIONS
---------------------------------------------------*/

$permissions = array(
 MM_ADMIN_FOLDER . '/backup',
 'control/maxmind',
 'logs'
);

/* CHARACTER SETS
---------------------------------------------------*/

$cSets = $DB->db_charsets();

/* UPGRADE OPS
---------------------------------------------------*/

$ops   = array();
$ops[] = 'Add New Database Tables';
$ops[] = 'Updating Collections, Tracks &amp; Styles';
$ops[] = 'Updating Accounts';
$ops[] = 'Updating Payment Gateways';
$ops[] = 'Updating Sales';
$ops[] = 'Updating General &amp; Social Network Settings';
$ops[] = 'Updating GeoIP &amp; Country Database';
$ops[] = 'Updating Pages &amp; Layout';
$ops[] = 'Check Indexes and Finalise';

?>