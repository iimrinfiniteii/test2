<?php

/* INSTALLER - SQL DATA
--------------------------------------------------------*/

if (!defined('PARENT')) {
  exit;
}

$dataE = array();
$dtcount = 0;

// Path / zone checks..
$root = 'http://www.example.com/music-store';
$zone = (isset($_POST['timezone']) ? $_POST['timezone'] : 'Europe/London');
if (isset($_SERVER['HTTP_HOST'], $_SERVER['PHP_SELF'])) {
  $root = 'http' . (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on' ? 's' : '') . '://' . $_SERVER['HTTP_HOST'] . substr($_SERVER['PHP_SELF'], 0, strpos($_SERVER['PHP_SELF'], 'install') - 1) . '/';
}
if (!isset($_POST['timezone'])) {
  if (function_exists('date_default_timezone_get')) {
    $zone = date_default_timezone_get();
  }
  if ($zone == '' & @ini_get('date.timezone')) {
    $zone = @ini_get('date.timezone');
  }
}

// Find / replace tags..
$f_r = array(
  '{prefix}' => DB_PREFIX,
  '{date}' => date('Y-m-d'),
  '{script}' => SCRIPT_NAME,
  '{version}' => SCRIPT_VERSION,
  '{ts}' => strtotime(date('Y-m-d H:i:s')),
  '{rss}' => date('r'),
  '{path}' => mswSQL($root, $DB),
  '{zone}' => mswSQL($zone, $DB),
  '{store}' => (isset($_POST['store']) && $_POST['store'] ? mswSQL($_POST['store'], $DB) : 'My Music Shop'),
  '{email}' => (isset($_POST['em']) && mswIsValidEmail($_POST['em']) == 'ok' ? mswSQL($_POST['em'], $DB) : 'email@example.com'),
  '{key}' => $prodKey
);

// Data..
$sTables = array(
  'boxes', 'countries', 'gateways', 'gateways_params', 'pages', 'settings', 'social'
);

// Install styles?
if (isset($_POST['styles'])) {
  $sTables[] = 'music_styles';
}

// Clear existing data..
$DB->db_truncate($sTables);

// Import new data..
foreach ($sTables AS $sql_file) {
  if (file_exists(PATH . 'control/sql/' . $sql_file . '.sql')) {
    $qD = $DB->db_query(strtr(@file_get_contents(PATH . 'control/sql/' . $sql_file . '.sql'), $f_r));
    if (!$qD) {
      $ERR = $DB->db_error(true);
      mswInsLog(DB_PREFIX . $sql_file, $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Insert Standard Data (' . $sql_file . '.sql)');
      ++$dcount;
    }
  } else {
    mswInsLog(DB_PREFIX . $sql_file, $sql_file . '.sql - file does not exist', 0, __LINE__, __FILE__, $DB, 'Insert Standard Data (' . $sql_file . '.sql)');
    ++$dcount;
  }
}

// Import geo IPV6 data..
// NO need for IPV4, it already exists..
if ($dcount == 0) {
  $sql_file = 'GeoIPv6.csv';
  if (file_exists(PATH . 'control/geo/' . $sql_file)) {
    $qIPV6 = $DB->db_query("LOAD DATA LOCAL INFILE '" . mswSQL(PATH . 'control/geo/' . $sql_file, $DB) . "' INTO TABLE `" . DB_PREFIX . "geo_ipv6`
    FIELDS TERMINATED BY ', '
    OPTIONALLY ENCLOSED BY '\"'
    ESCAPED BY '\"'
    LINES TERMINATED BY '\n'
    IGNORE 0 LINES (`from_ip`, `to_ip`, `loc_start`, `loc_end`, `country_iso`, `country`)
    ");
    if (!$qIPV6) {
      $ERR = $DB->db_error(true);
      mswInsLog(DB_PREFIX . $sql_file, $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Insert Standard Data (' . $sql_file . '.sql)');
      ++$dcount;
    } else {
      if ($DB->db_rowcount('geo_ipv6') == 0) {
        $qIPV6 = $DB->db_query("LOAD DATA LOCAL INFILE '" . mswSQL(PATH . 'control/geo/' . $sql_file, $DB) . "' INTO TABLE `" . DB_PREFIX . "geo_ipv6`
        FIELDS TERMINATED BY ','
        OPTIONALLY ENCLOSED BY '\"'
        ESCAPED BY '\"'
        LINES TERMINATED BY '\n'
        IGNORE 0 LINES (`from_ip`, `to_ip`, `loc_start`, `loc_end`, `country_iso`, `country`)
        ");
        if (!$qIPV6) {
          $ERR = $DB->db_error(true);
          mswInsLog(DB_PREFIX . $sql_file, $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Insert Standard Data (' . $sql_file . '.sql)');
          ++$dcount;
        }
      }
    }
  }
}

?>