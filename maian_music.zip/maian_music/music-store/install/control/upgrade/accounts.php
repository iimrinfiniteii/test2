<?php

/* INSTALLER - UPGRADE
---------------------------------------------------*/

if (!defined('UPGRADE_RUN')) {
  exit;
}

mswUpLog('Starting account updates', 'instruction');

if (mswCheckColumnType('accounts', 'pass', '40', $DB) == 'yes') {
  $q = $DB->db_query("alter table `" . DB_PREFIX . "accounts` change column `pass` `pass` varchar(250) not null default '' after `email`");
  if ($q === 'err') {
    $ERR = $DB->db_error(true);
    mswUpLog(DB_PREFIX . 'accounts', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Change Column');
  }
}

mswUpLog('Account updates completed', 'instruction');

?>