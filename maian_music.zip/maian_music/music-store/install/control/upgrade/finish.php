<?php

/* INSTALLER - UPGRADE
---------------------------------------------------*/

if (!defined('UPGRADE_RUN')) {
  exit;
}

mswUpLog('Starting index updates', 'instruction');

// Add indexes to ipv6 table if they don`t exist..
if (mswCheckIndex('geo_ipv6', 'from_ip', $DB) == 'no') {
  $q = $DB->db_query("alter table `" . DB_PREFIX . "geo_ipv6` add index `from_ip` (`from_ip`)");
  if ($q === 'err') {
    $ERR = $DB->db_error(true);
    mswUpLog(DB_PREFIX . 'geo_ipv6', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Add Index');
  }
}

if (mswCheckIndex('geo_ipv6', 'to_ip', $DB) == 'no') {
  $q = $DB->db_query("alter table `" . DB_PREFIX . "geo_ipv6` add index `to_ip` (`to_ip`)");
  if ($q === 'err') {
    $ERR = $DB->db_error(true);
    mswUpLog(DB_PREFIX . 'geo_ipv6', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Add Index');
  }
}

// Check other indexes..
if (mswCheckIndex('collections', 'name', $DB) == 'no') {
  $q = $DB->db_query("alter table `" . DB_PREFIX . "collections` add index `name` (`name`)");
  if ($q === 'err') {
    $ERR = $DB->db_error(true);
    mswUpLog(DB_PREFIX . 'collections', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Add Index');
  }
}

if (mswCheckIndex('music', 'title', $DB) == 'no') {
  $q = $DB->db_query("alter table `" . DB_PREFIX . "music` add index `title` (`title`)");
  if ($q === 'err') {
    $ERR = $DB->db_error(true);
    mswUpLog(DB_PREFIX . 'music', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Add Index');
  }
}

mswUpLog('Index updates completed', 'instruction');

?>