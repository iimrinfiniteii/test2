<?php

/* INSTALLER - UPGRADE
---------------------------------------------------*/

if (!defined('UPGRADE_RUN')) {
  exit;
}

mswUpLog('Starting payment gateway updates', 'instruction');

// Add stripe gateway info if it doesn`t exist..
if ($DB->db_rowcount('gateways', ' WHERE `class` = \'class.stripe.php\'') == 0) {
  $q = $DB->db_query("insert into `" . DB_PREFIX . "gateways` (`display`, `liveserver`, `sandboxserver`, `image`, `webpage`, `status`, `class`, `default`) VALUES ('Stripe', '', '', 'stripe.png', 'https://stripe.com/gb', 'yes', 'class.stripe.php', 'no')");
  if ($q === 'err') {
    $ERR = $DB->db_error(true);
    mswUpLog(DB_PREFIX . 'gateways', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Insert Data');
  } else {
    $Q  = $DB->db_query("SELECT `id` FROM `" . DB_PREFIX . "gateways` WHERE `class` = 'class.stripe.php'");
    $GW = $DB->db_object($Q);
    if (isset($GW->id)) {
      $DB->db_query("insert into `" . DB_PREFIX . "gateways_params` (`gateway`, `param`, `value`) VALUES ({$GW->id}, 'perishable-key', ''), ({$GW->id}, 'secret-key', ''), ({$GW->id}, 'image', 'stripe.png'), ({$GW->id}, 'locale', 'auto')");
    }
  }
}

// Update Iridium Corporation info if it exists..
$q = $DB->db_query("update `" . DB_PREFIX . "gateways` set
     `display` = 'Pay Vector',
     `liveserver` = 'http://mms.payvector.net/Pages/PublicPages/PaymentForm.aspx',
     `sandboxserver` = 'http://mms.payvector.net/Pages/PublicPages/PaymentForm.aspx',
     `image` = 'payvector.png',
     `webpage` = 'http://www.payvector.co.uk',
     `class` = 'class.payvector.php'
     where `class` = 'class.iridium.php'
     ");
if ($q === 'err') {
  $ERR = $DB->db_error(true);
  mswUpLog(DB_PREFIX . 'gateways', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Data Update');
}

// Update Skrill..
$q = $DB->db_query("update `" . DB_PREFIX . "gateways` set
     `liveserver` = 'https://pay.skrill.com',
     `sandboxserver` = 'https://pay.skrill.com'
     where `class` = 'class.skrill.php'
     ");
if ($q === 'err') {
  $ERR = $DB->db_error(true);
  mswUpLog(DB_PREFIX . 'gateways', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Data Update');
}

// Update Payza live / sandbox urls..
$q = $DB->db_query("update `" . DB_PREFIX . "gateways` set
     `liveserver` = 'https://secure.payza.com/checkout',
     `sandboxserver` = 'https://secure.payza.com/checkout'
     where `class` = 'class.payza.php'
     ");
if ($q === 'err') {
  $ERR = $DB->db_error(true);
  mswUpLog(DB_PREFIX . 'gateways', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Data Update');
}

// For sagepay, encryption method must be xor if mcrypt isn`t available..
if (!function_exists('mcrypt_encrypt')) {
  $Q  = $DB->db_query("SELECT `id` FROM `" . DB_PREFIX . "gateways` WHERE `class` = 'class.sagepay.php'");
  $GW = $DB->db_object($Q);
  if (isset($GW->id)) {
    $q = $DB->db_query("update `" . DB_PREFIX . "gateways_params` set
         `value` = 'xor'
         where `param` = 'encryption'
         and `gateway` = '{$GW->id}'
         ");
    if ($q === 'err') {
      $ERR = $DB->db_error(true);
      mswUpLog(DB_PREFIX . 'gateways_params', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Data Update');
    }
  }
}

// Add docs links..
if (mswCheckColumn('gateways', 'docs', $DB) == 'no') {
  $q = $DB->db_query("alter table `" . DB_PREFIX . "gateways` add column `docs` varchar(200) not null default ''");
  if ($q === 'err') {
    $ERR = $DB->db_error(true);
    mswUpLog(DB_PREFIX . 'gateways', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Add Column');
  }
  $q = $DB->db_query("update `" . DB_PREFIX . "gateways` set `docs` = concat('gw-', replace(`image`, substring(`image`, -4), ''), '.html')");
  if ($q === 'err') {
    $ERR = $DB->db_error(true);
    mswUpLog(DB_PREFIX . 'gateways', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Update Column');
  }
  $q = $DB->db_query("update `" . DB_PREFIX . "gateways` set `docs` = 'gw-jambo2.html' where `class` = 'class.jambo2.php'");
  if ($q === 'err') {
    $ERR = $DB->db_error(true);
    mswUpLog(DB_PREFIX . 'gateways', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Update Column');
  }
} else {
  // Make sure docs field is populated for gateways..
  $q = $DB->db_query("update `" . DB_PREFIX . "gateways` set
       `docs` = concat('gw-', replace(`image`, substring(`image`, -4), ''), '.html')
       where `docs` = ''
       ");
  if ($q === 'err') {
    $ERR = $DB->db_error(true);
    mswUpLog(DB_PREFIX . 'gateways', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Update Column');
  }
}

// We don`t support these gateways anymore..
$gwDL = array();
$Q  = $DB->db_query("SELECT `id` FROM `" . DB_PREFIX . "gateways` WHERE `class` IN('class.paypoint.php', 'class.beanstream.php','class.eway.php','class.fetch.php','class.iris.php','class.realex.php')");
while ($GW = $DB->db_object($Q)) {
  $gwDL[] = $GW->id;
}
if (!empty($gwDL)) {
  $DB->db_query("delete from `" . DB_PREFIX . "gateways` where `id` IN(" . implode(',', $gwDL) . ")");
  $DB->db_query("delete from `" . DB_PREFIX . "gateways_params` where `gateway` IN(" . implode(',', $gwDL) . ")");
}

mswUpLog('Payment gateway updates completed', 'instruction');

?>