<?php

/* INSTALLER - UPGRADE
---------------------------------------------------*/

if (!defined('UPGRADE_RUN')) {
  exit;
}

$q = $DB->db_query("UPDATE `" . DB_PREFIX . "settings` SET `version` = '" . SCRIPT_VERSION . "'");
if ($q === 'err') {
  $ERR = $DB->db_error(true);
  mswUpLog(DB_PREFIX . 'settings', $ERR[1], $ERR[0], __line__, __file__, $DB, 'Column Update');
}

?>