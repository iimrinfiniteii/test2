<?php

/* INSTALLER - UPGRADE
---------------------------------------------------*/

if (!defined('UPGRADE_RUN')) {
  exit;
}

mswUpLog('Starting sales updates', 'instruction');

// New columns..
if (mswCheckColumn('sales', 'gname', $DB) == 'no') {
  $q = $DB->db_query("alter table `" . DB_PREFIX . "sales` add column `gname` varchar(250) not null default ''");
  if ($q === 'err') {
    $ERR = $DB->db_error(true);
    mswUpLog(DB_PREFIX . 'sales', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Add Column');
  }
}

if (mswCheckColumn('sales', 'gemail', $DB) == 'no') {
  $q = $DB->db_query("alter table `" . DB_PREFIX . "sales` add column `gemail` varchar(250) not null default ''");
  if ($q === 'err') {
    $ERR = $DB->db_error(true);
    mswUpLog(DB_PREFIX . 'sales', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Add Column');
  }
}

if (mswCheckColumn('sales', 'approved', $DB) == 'no') {
  $q = $DB->db_query("alter table `" . DB_PREFIX . "sales` add column `approved` enum('yes', 'no') not null default 'yes'");
  if ($q === 'err') {
    $ERR = $DB->db_error(true);
    mswUpLog(DB_PREFIX . 'sales', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Add Column');
  }
}

// Column changes..
if (mswCheckColumnType('sales', 'code', '40', $DB) == 'yes') {
  $q = $DB->db_query("alter table `" . DB_PREFIX . "sales` change column `code` `code` varchar(100) not null default '' after `notes`");
  if ($q === 'err') {
    $ERR = $DB->db_error(true);
    mswUpLog(DB_PREFIX . 'sales', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Change Column');
  }
}

mswUpLog('Sales updates completed', 'instruction');


?>