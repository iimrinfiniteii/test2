<?php

/* INSTALLER - UPGRADE
---------------------------------------------------*/

if (!defined('UPGRADE_RUN')) {
  exit;
}

mswUpLog('Starting music updates', 'instruction');

// Adjust collection length column..
if (mswCheckColumnType('collections', 'length', '10', $DB) == 'yes') {
  $q = $DB->db_query("alter table `" . DB_PREFIX . "collections` change column `length` `length` varchar(200) not null default '' after `related`");
  if ($q === 'err') {
    $ERR = $DB->db_error(true);
    mswUpLog(DB_PREFIX . 'collections', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Change Column');
  }
}
// Adjust collection slug column..
if (mswCheckColumnType('collections', 'slug', '50', $DB) == 'yes') {
  $q = $DB->db_query("alter table `" . DB_PREFIX . "collections` change column `slug` `slug` text default null after `metadesc`");
  if ($q === 'err') {
    $ERR = $DB->db_error(true);
    mswUpLog(DB_PREFIX . 'collections', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Change Column');
  }
}
// Adjust music_styles slug column..
if (mswCheckColumnType('music_styles', 'slug', '50', $DB) == 'yes') {
  $q = $DB->db_query("alter table `" . DB_PREFIX . "music_styles` change column `slug` `slug` text default null after `name`");
  if ($q === 'err') {
    $ERR = $DB->db_error(true);
    mswUpLog(DB_PREFIX . 'music_styles', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Change Column');
  }
}

// New columns..
if (mswCheckColumn('music_styles', 'title', $DB) == 'no') {
  $q = $DB->db_query("alter table `" . DB_PREFIX . "music_styles` add column `title` text default null");
  if ($q === 'err') {
    $ERR = $DB->db_error(true);
    mswUpLog(DB_PREFIX . 'music_styles', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Add Column');
  }
}

if (mswCheckColumn('music_styles', 'metakeys', $DB) == 'no') {
  $q = $DB->db_query("alter table `" . DB_PREFIX . "music_styles` add column `metakeys` text default null");
  if ($q === 'err') {
    $ERR = $DB->db_error(true);
    mswUpLog(DB_PREFIX . 'music_styles', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Add Column');
  }
}

if (mswCheckColumn('music_styles', 'metadesc', $DB) == 'no') {
  $q = $DB->db_query("alter table `" . DB_PREFIX . "music_styles` add column `metadesc` text default null");
  if ($q === 'err') {
    $ERR = $DB->db_error(true);
    mswUpLog(DB_PREFIX . 'music_styles', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Add Column');
  }
}

// For versions less than 2.5, nothing will exist in top level categories, so add all sub category collections to their top level..
if ($SETTINGS->version < 2.5) {
  $q = $DB->db_query("select *,
       `" . DB_PREFIX . "music_styles`.`id` AS `styleID`,
       `" . DB_PREFIX . "music_styles`.`type` AS `parentID`,
       `" . DB_PREFIX . "collection_styles`.`collection` AS `colID`
       from `" . DB_PREFIX . "collection_styles`
       left join `" . DB_PREFIX . "music_styles`
       on `" . DB_PREFIX . "collection_styles`.`style` = `" . DB_PREFIX . "music_styles`.`id`
       where `" . DB_PREFIX . "music_styles`.`type` != 0
       ");
  while ($ST = $DB->db_object($q)) {
    if ($DB->db_rowcount('collection_styles', ' WHERE `style` = \'' . $ST->parentID . '\' AND `collection` = \'' . $ST->colID . '\'') == 0) {
      $DB->db_query("insert into `" . DB_PREFIX . "collection_styles` (
      `style`, `collection`
      ) values (
      '{$ST->parentID}', '{$ST->colID}'
      )");
    }
  }
}

mswUpLog('Music updates completed', 'instruction');

?>