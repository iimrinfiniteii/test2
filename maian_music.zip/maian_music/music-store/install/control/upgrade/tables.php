<?php

if (!defined('UPGRADE_RUN')) { exit; }

/* UPGRADE - TABLES
------------------------------------------------------*/

mswUpLog('Upgrade routine started', 'instruction');

// imap table..
if (mswCheckTable('boxes', $DB) == 'no') {
  $q = $DB->db_query("CREATE TABLE `" . DB_PREFIX . "boxes` (
  `id` int(7) not null auto_increment,
  `title` varchar(250) not null default '',
  `info` text default null,
  `ordr` int(5) not null default '0',
  `en` enum('yes','no') not null default 'yes',
  `tmp` varchar(250) not null default '',
  `icon` varchar(200) not null default '',
  primary key (`id`)
  ) $tableType");
  if ($q === 'err') {
    $ERR = $DB->db_error(true);
    mswUpLog(DB_PREFIX . 'boxes', $ERR[1], $ERR[0], __line__, __file__, 'Add Table');
  } else {
    mswUpLog('Completed: new table added: `' . DB_PREFIX . 'boxes`', '', '', __line__, __file__, $DB, 'New Table');
    // Add default data..
    if (file_exists(PATH . 'control/sql/boxes.sql')) {
      $f_r = array(
        '{prefix}' => DB_PREFIX
      );
      $q = $DB->db_query(strtr(@file_get_contents(PATH . 'control/sql/boxes.sql'), $f_r));
      if (!$q) {
        $ERR = $DB->db_error(true);
        mswInsLog(DB_PREFIX . 'boxes', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Insert Standard Data for Upgrade (boxes.sql)');
      }
    }
  }
}

mswUpLog('New tables completed', 'instruction');

?>