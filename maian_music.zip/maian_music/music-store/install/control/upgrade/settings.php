<?php

/* INSTALLER - UPGRADE
---------------------------------------------------*/

if (!defined('UPGRADE_RUN')) {
  exit;
}

mswUpLog('Starting settings updates', 'instruction');

// New columns..
if (mswCheckColumn('settings', 'smtp_debug', $DB) == 'no') {
  $q = $DB->db_query("alter table `" . DB_PREFIX . "settings` add column `smtp_debug` enum('yes','no') not null default 'no'");
  if ($q === 'err') {
    $ERR = $DB->db_error(true);
    mswUpLog(DB_PREFIX . 'settings', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Add Column');
  }
}

if (mswCheckColumn('settings', 'smtp_rfrom', $DB) == 'no') {
  $q = $DB->db_query("alter table `" . DB_PREFIX . "settings` add column `smtp_rfrom` varchar(250) not null default ''");
  if ($q === 'err') {
    $ERR = $DB->db_error(true);
    mswUpLog(DB_PREFIX . 'settings', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Add Column');
  }
}

if (mswCheckColumn('settings', 'smtp_remail', $DB) == 'no') {
  $q = $DB->db_query("alter table `" . DB_PREFIX . "settings` add column `smtp_remail` varchar(250) not null default ''");
  if ($q === 'err') {
    $ERR = $DB->db_error(true);
    mswUpLog(DB_PREFIX . 'settings', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Add Column');
  }
}

if (mswCheckColumn('settings', 'smtp_send', $DB) == 'no') {
  $q = $DB->db_query("alter table `" . DB_PREFIX . "settings` add column `smtp_send` enum('smtp','mail') not null default 'smtp'");
  if ($q === 'err') {
    $ERR = $DB->db_error(true);
    mswUpLog(DB_PREFIX . 'settings', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Add Column');
  }
}

if (mswCheckColumn('settings', 'smtp_certs', $DB) == 'no') {
  $q = $DB->db_query("alter table `" . DB_PREFIX . "settings` add column `smtp_certs` enum('yes','no') not null default 'no'");
  if ($q === 'err') {
    $ERR = $DB->db_error(true);
    mswUpLog(DB_PREFIX . 'settings', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Add Column');
  }
}

if (mswCheckColumn('settings', 'approve', $DB) == 'no') {
  $q = $DB->db_query("alter table `" . DB_PREFIX . "settings` add column `approve` enum('yes', 'no') not null default 'no'");
  if ($q === 'err') {
    $ERR = $DB->db_error(true);
    mswUpLog(DB_PREFIX . 'settings', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Add Column');
  }
}

if (mswCheckColumn('settings', 'company', $DB) == 'no') {
  $q = $DB->db_query("alter table `" . DB_PREFIX . "settings` add column `company` text default null");
  if ($q === 'err') {
    $ERR = $DB->db_error(true);
    mswUpLog(DB_PREFIX . 'settings', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Add Column');
  }
}

// Rename api table..
if (mswCheckTable('social', $DB) == 'no' && mswCheckTable('api', $DB) == 'yes') {
  $q = $DB->db_query("rename table `" . DB_PREFIX . "api` to `" . DB_PREFIX . "social`");
  if ($q === 'err') {
    $ERR = $DB->db_error(true);
    mswUpLog(DB_PREFIX . 'social', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Table Rename');
  }
}

// Port social settings to social table if they still exist in settings..
// Also, add new social parameters..
if (mswCheckTable('social', $DB) == 'yes' && property_exists($SETTINGS, 'social')) {
  $social = ($SETTINGS->social ? unserialize($SETTINGS->social) : array());
  if (!empty($social)) {
    foreach ($social AS $k => $v) {
      $faw = '';
      switch($k) {
        case 'fb':
          $faw = 'fab fa-facebook';
          break;
        case 'gg':
          $faw = 'fab fa-google';
          break;
        case 'tw':
          $faw = 'fab fa-twitter';
          break;
        case 'li':
          $faw = 'fab fa-linkedin';
          break;
        case 'yt':
          $faw = 'fab fa-youtube';
          break;
        case 'sc':
          $faw = 'fab fa-soundcloud';
          break;
        case 'sp':
          $faw = 'fab fa-spotify';
          break;
        case 'fm':
          $faw = 'fab fa-lastfm';
          break;
      }
      if ($v) {
        $v = mswSQL($v, $DB);
        $q = $DB->db_query("insert into `" . DB_PREFIX . "social` (`desc`, `param`, `value`) values ('links', '{$faw}', '{$v}')");
        if ($q === 'err') {
          $ERR = $DB->db_error(true);
          mswUpLog(DB_PREFIX . 'social', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Social Links Port');
        }
      }
    }
  }
  if (property_exists($SETTINGS, 'facebook')) {
    $q = $DB->db_query("insert into `" . DB_PREFIX . "social` (`desc`, `param`, `value`) values ('struct', 'fb', '{$SETTINGS->facebook}')");
    if ($q === 'err') {
      $ERR = $DB->db_error(true);
      mswUpLog(DB_PREFIX . 'social', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Facebook Settings Port');
    }
  }
  $q = $DB->db_query("alter table `" . DB_PREFIX . "settings` drop column `social`");
  if ($q === 'err') {
    $ERR = $DB->db_error(true);
    mswUpLog(DB_PREFIX . 'settings', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Column Drop');
  }
  $q = $DB->db_query("alter table `" . DB_PREFIX . "settings` drop column `facebook`");
  if ($q === 'err') {
    $ERR = $DB->db_error(true);
    mswUpLog(DB_PREFIX . 'settings', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Column Drop');
  }
}

// Check for social parameters, add defaults to prevent any errors..
$sc_arr = array(
  'addthis' => array('code','html'),
  'disqus' => array('disname','discat'),
  'pushover' => array('pushuser','pushtoken'),
  'facebook' => array('fbinsights'),
  'twitter' => array('conkey','consecret','token','key','user'),
  'struct' => array('twitter','fb','google')
);
foreach (array_keys($sc_arr) AS $desc) {
  foreach ($sc_arr[$desc] AS $pm) {
    if ($DB->db_rowcount('social', ' WHERE `desc` = \'' . $desc . '\' AND `param` = \'' . $pm . '\'') == 0) {
      switch($desc) {
        case 'struct':
          $val = 'yes';
          break;
        default:
          $val = '';
          break;
      }
      $q = $DB->db_query("insert into `" . DB_PREFIX . "social` (`desc`, `param`, `value`) values ('{$desc}', '{$pm}', '{$val}')");
      if ($q === 'err') {
        $ERR = $DB->db_error(true);
        mswUpLog(DB_PREFIX . 'social', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Default social param');
      }
    }
  }
}

// For version 2.5, we must revert to the default theme..
if (SCRIPT_VERSION == '2.5') {
  $q = $DB->db_query("update `" . DB_PREFIX . "settings` set `theme` = '_theme_default'");
  if ($q === 'err') {
    $ERR = $DB->db_error(true);
    mswUpLog(DB_PREFIX . 'settings', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Column Update');
  }
}

mswUpLog('Settings updates completed', 'instruction');

?>