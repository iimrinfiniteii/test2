<?php

/* INSTALLER - UPGRADE
---------------------------------------------------*/

if (!defined('UPGRADE_RUN')) {
  exit;
}

mswUpLog('Starting layout updates', 'instruction');

// We don`t need the contact template anymore..
// Shouldn`t exist for newer versions..
if ($SETTINGS->version < 2.5) {
  $q = $DB->db_query("delete from `" . DB_PREFIX . "pages` where `template` = 'contact.tpl.php'");
  if ($q === 'err') {
    $ERR = $DB->db_error(true);
    mswUpLog(DB_PREFIX . 'pages', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Data Deletion');
  }
}

// Adjust pages slug column..
if (mswCheckColumnType('pages', 'slug', '250', $DB) == 'yes') {
  $q = $DB->db_query("alter table `" . DB_PREFIX . "pages` change column `slug` `slug` text default null after `landing`");
  if ($q === 'err') {
    $ERR = $DB->db_error(true);
    mswUpLog(DB_PREFIX . 'pages', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Change Column');
  }
}

mswUpLog('Layout updates completed', 'instruction');

?>