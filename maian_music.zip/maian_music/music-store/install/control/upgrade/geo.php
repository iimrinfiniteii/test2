<?php

/* INSTALLER - UPGRADE
---------------------------------------------------*/

if (!defined('UPGRADE_RUN')) {
  exit;
}

mswUpLog('Starting GeoIP updates', 'instruction');

// Add geo id column for ipv4 if it doesn`t exist..
if (mswCheckColumn('countries', 'geoname_id', $DB) == 'no') {
  $q = $DB->db_query("alter table `" . DB_PREFIX . "countries` add column `geoname_id` int(11) not null default '0'");
  if ($q === 'err') {
    $ERR = $DB->db_error(true);
    mswUpLog(DB_PREFIX . 'countries', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Add Column');
  } else {
    // And populate field with ipv4 id numbers..
    if (file_exists(PATH . 'control/geo/GeoCountries.csv')) {
      $data = array_map('str_getcsv', file(PATH . 'control/geo/GeoCountries.csv'));
      if (!empty($data)) {
        for ($i = 0; $i < count($data); $i++) {
          if ($i > 0 && isset($data[$i][0], $data[$i][4])) {
            $DB->db_query("UPDATE `" . DB_PREFIX . "countries` SET
            `geoname_id` = '" . (int) $data[$i][0] . "'
            WHERE LOWER(`iso2`) = '" . mswSQL(strtolower($data[$i][4]), $DB) . "'
            ");
          }
        }
      }
    } else {
      mswUpLog('GeoCountries.csv not located, import terminated', 'instruction');
    }
  }
}

// We don`t need the ipv4 table anymore..
if (mswCheckTable('geo_ipv4', $DB) == 'yes') {
  $q = $DB->db_query("drop table `" . DB_PREFIX . "geo_ipv4`");
  if ($q === 'err') {
    $ERR = $DB->db_error(true);
    mswUpLog(DB_PREFIX . 'geo_ipv4', $ERR[1], $ERR[0], __LINE__, __FILE__, $DB, 'Table Drop');
  }
}

mswUpLog('GeoIP updates completed', 'instruction');

?>