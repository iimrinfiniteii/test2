INSERT INTO `{prefix}boxes` (`title`, `info`, `ordr`, `en`, `tmp`, `icon`) VALUES
('Popular Music', '', 2, 'yes', 'box_popular_music.tpl.php', 'fa fas fa-heart'),
('Recently Viewed', NULL, 1, 'yes', 'box_recently_viewed_music.tpl.php', 'fa fas fa-binoculars')