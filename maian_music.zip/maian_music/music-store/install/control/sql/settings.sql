INSERT INTO `{prefix}settings` (`website`, `email`, `httppath`, `secfolder`, `dateformat`, `timeformat`, `jsformat`, `timezone`, `weekstart`, `zip`,
`rewrite`, `paymode`, `responselog`, `propend`, `version`, `prodkey`, `smtp_host`, `smtp_user`, `smtp_pass`, `smtp_port`, `smtp_from`, `smtp_email`,
`smtp_security`, `smtp_other`, `sysstatus`, `autoenable`, `reason`, `allowip`, `currency`, `invoice`, `curdisplay`, `access`, `afoot`, `pfoot`, `theme`,
`featured`, `metakeys`, `metadesc`, `minpass`, `emnotify`, `deftax`, `deftax2`, `defCountry`, `defCountry2`, `resip`, `licsubj`, `licmsg`, `licenable`,
`maxupdate`, `geoip`, `statistics`, `minpurchase`, `cdpur`, `rss`, `hideparams`, `acclogin`, `accloginflag`, `termsmsg`, `termsenable`, `smtp_debug`,
`smtp_rfrom`, `smtp_remail`, `smtp_send`, `smtp_certs`, `approve`, `company`
) VALUES (
'{store}', '{email}', '{path}', '', 'j M Y', 'H:i:s', 'DD-MM-YYYY', '{zone}', 'sun', 'no', 'no', 'test', 'yes', 'no', '{version}', '{key}', '', '', '', '587',
'', '', '', '', 'yes', 0, '', '', 'GBP', 1, '&pound;{AMOUNT}', 'a:8:{i:0;i:30;i:1;s:3:"min";i:2;i:3;i:3;s:2:"no";i:4;s:2:"no";i:5;i:5;i:6;s:3:"yes";i:7;s:3:"tmp";}',
'', '', '_theme_default', '', '', '', 8, 'a:8:{s:7:"salecus";s:1:"1";s:7:"saleweb";s:1:"1";s:10:"salecuspen";s:1:"1";s:10:"salewebpen";s:1:"1";s:7:"cusprof";s:1:"1";s:7:"webprof";s:1:"1";s:5:"cuscr";s:1:"1";s:5:"webcr";s:1:"1";}',
0, 0, 183, 183, 'no', 'License Agreement - Please Read', 'Hi {NAME},\r\n\r\nRegarding invoice {INVOICE}, this email licenses you for the following:\r\n\r\nTracks:\r\n{TRACKS}\r\n\r\nCD Downloads:\r\n{CDD}\r\n\r\nCDs\r\n{CD}\r\n\r\nFor transaction id {ID}, purchased on {DATE}.',
'no', {ts}, 'yes', 'a:4:{s:5:"years";s:9:"2013,2014";s:4:"best";s:2:"20";s:5:"month";s:4:"this";s:6:"legacy";s:2:"15";}', '', 'no', 'yes', 'yes', 'yes', 0, '', 'no', 'yes', '', '', 'smtp', 'no', 'no', '')