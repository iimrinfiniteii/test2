INSERT INTO `{prefix}pages` (`name`, `info`, `keys`, `desc`, `title`, `orderby`, `template`, `landing`, `slug`, `enabled`) VALUES
('About', 'About page.<br><br>Manage or remove in your control panel..', NULL, NULL, NULL, 3, '', 'no', 'about-page', 'yes'),
('License', 'License page.<br><br>Manage or remove in your control panel..', '', '', '', 4, '', 'no', '', 'yes'),
('Shipping & Returns', 'Shipping and returns page.<br><br>Manage or remove in your control panel..', NULL, NULL, NULL, 5, '', 'no', 'returns-page', 'yes')