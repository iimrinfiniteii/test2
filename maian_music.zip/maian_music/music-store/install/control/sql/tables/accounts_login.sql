create table `{prefix}accounts_login` (
  `id` int(7) unsigned not null auto_increment,
  `account` int(7) not null default '0',
  `ip` varchar(250) not null default '',
  `ts` int(30) not null default '0',
  `iso` char(2) not null default '',
  `country` varchar(250) not null default '',
  primary key (`id`),
  key `saleid_index` (`account`)
) {tabletype}