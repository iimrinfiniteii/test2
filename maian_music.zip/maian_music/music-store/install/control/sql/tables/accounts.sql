create table `{prefix}accounts` (
  `id` int(10) unsigned not null auto_increment,
  `name` varchar(250) not null default '',
  `email` varchar(250) not null default '',
  `pass` varchar(250) not null default '',
  `ip` varchar(250) not null default '',
  `ts` int(30) not null default '0',
  `enabled` enum('yes','no') not null default 'yes',
  `system1` varchar(250) not null default '',
  `system2` varchar(250) not null default '',
  `notes` text,
  `timezone` varchar(50) not null default '',
  `country` int(5) not null default '183',
  `shipping` int(5) not null default '0',
  `token` varchar(50) not null default '',
  `bypass` enum('yes','no') not null default 'no',
  `login` enum('yes','no') not null default 'yes',
  primary key (`id`)
) {tabletype}