create table `{prefix}sales_items` (
  `id` int(9) not null auto_increment,
  `sale` int(9) not null default '0',
  `item` int(9) not null default '0',
  `collection` int(9) not null default '0',
  `type` enum('collection','track','none') not null default 'none',
  `physical` enum('yes','no') not null default 'no',
  `expiry` int(30) not null default '0',
  `cost` varchar(10) not null default '0.00',
  `clicks` int(30) not null default '0',
  `token` varchar(40) not null default '',
  primary key (`id`),
  key `sale` (`sale`),
  key `item` (`item`),
  key `col` (`collection`)
) {tabletype}