create table `{prefix}collection_styles` (
  `id` int(4) unsigned not null auto_increment,
  `style` int(8) not null default '0',
  `collection` int(8) not null default '0',
  primary key (`id`),
  key `style` (`style`),
  key `col` (`collection`)
) {tabletype}