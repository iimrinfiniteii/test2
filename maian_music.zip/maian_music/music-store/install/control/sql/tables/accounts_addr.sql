create table `{prefix}accounts_addr` (
  `id` int(10) unsigned not null auto_increment,
  `account` int(30) not null default '0',
  `address1` varchar(250) not null default '',
  `address2` varchar(250) not null default '',
  `city` varchar(250) not null default '',
  `county` varchar(250) not null default '',
  `postcode` varchar(250) not null default '',
  `country` int(5) not null default '183',
  `default` enum('yes','no') not null default 'yes',
  primary key (`id`),
  key `acc` (`account`)
) {tabletype}