create table `{prefix}boxes` (
  `id` int(7) not null auto_increment,
  `title` varchar(250) not null default '',
  `info` text default null,
  `ordr` int(5) not null default '0',
  `en` enum('yes','no') not null default 'yes',
  `tmp` varchar(250) not null default '',
  `icon` varchar(200) not null default '',
  primary key (`id`)
) {tabletype}