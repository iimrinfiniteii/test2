create table `{prefix}pages` (
  `id` int(7) not null auto_increment,
  `name` varchar(250) not null default '',
  `info` text default null,
  `keys` text default null,
  `desc` text default null,
  `title` text default null,
  `orderby` int(5) not null default '0',
  `template` varchar(250) not null default '',
  `landing` enum('yes','no') not null default 'no',
  `slug` text default null,
  `enabled` enum('yes','no') not null default 'no',
  primary key (`id`)
) {tabletype}