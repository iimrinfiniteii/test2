create table `{prefix}sales_clipboard` (
  `id` int(10) unsigned not null auto_increment,
  `trackcol` int(7) not null default '0',
  `type` enum('track','collection') not null default 'track',
  `physical` enum('yes','no') not null default 'no',
  primary key (`id`)
) {tabletype}