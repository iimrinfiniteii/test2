create table `{prefix}offers` (
  `id` int(10) unsigned not null auto_increment,
  `discount` varchar(10) not null default '',
  `expiry` int(30) not null default '0',
  `type` enum('collections','tracks','all','cd') not null default 'collections',
  `collections` text default null,
  `enabled` enum('yes','no') not null default 'yes',
  primary key (`id`)
) {tabletype}