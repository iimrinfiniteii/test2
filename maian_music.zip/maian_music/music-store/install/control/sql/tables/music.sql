create table `{prefix}music` (
  `id` int(9) not null auto_increment,
  `title` varchar(250) not null default '',
  `collection` int(7) not null default '0',
  `mp3file` text default null,
  `previewfile` text default null,
  `length` varchar(10) not null default '',
  `bitrate` varchar(100) not null default '',
  `samplerate` varchar(100) not null default '',
  `cost` varchar(10) not null default '',
  `order` int(9) not null default '0',
  `ts` int(30) not null default '0',
  `updated` int(30) not null default '0',
  primary key (`id`),
  key `col` (`collection`),
  key `title` (`title`)
) {tabletype}