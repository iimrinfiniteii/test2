create table `{prefix}music_styles` (
  `id` int(4) unsigned not null auto_increment,
  `name` varchar(250) not null default '',
  `slug` text default null,
  `enabled` enum('yes','no') not null default 'yes',
  `type` int(10) not null default '0',
  `orderby` varchar(10) not null default '0',
  `collection` int(7) not null default '0',
  `title` text default null,
  `metakeys` text default null,
  `metadesc` text default null,
  primary key (`id`)
) {tabletype}