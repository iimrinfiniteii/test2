create table `{prefix}sales_click` (
  `id` int(7) unsigned not null auto_increment,
  `sale` int(7) not null default '0',
  `trackcol` int(7) not null default '0',
  `ip` varchar(250) not null default '',
  `ts` int(30) not null default '0',
  `action` varchar(250) not null default '',
  `type` enum('admin','visitor') not null default 'visitor',
  `iso` char(2) not null default '',
  `country` varchar(250) not null default '',
  primary key (`id`),
  key `saleid_index` (`sale`)
) {tabletype}