create table `{prefix}geo_ipv6` (
  `id` int(10) unsigned not null auto_increment,
  `from_ip` varchar(100) not null default '',
  `to_ip` varchar(100) not null default '',
  `loc_start` varchar(100) not null default '0',
  `loc_end` varchar(100) not null default '0',
  `country_iso` char(2) not null default '',
  `country` varchar(100) not null default '',
  primary key (`id`),
  key `from_ip` (`from_ip`),
  key `to_ip` (`to_ip`)
) {tabletype}