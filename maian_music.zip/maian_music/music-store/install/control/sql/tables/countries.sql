create table `{prefix}countries` (
  `id` int(4) unsigned not null auto_increment,
  `name` varchar(250) not null default '',
  `iso` varchar(3) not null default '',
  `iso2` char(2) not null default '',
  `iso4217` varchar(50) not null default '0',
  `tax` char(2) not null default '',
  `tax2` char(2) not null default '',
  `display` enum('yes','no') not null default 'yes',
  `eu` enum('yes','no') not null default 'no',
  `geoname_id` int(11) not null default '0',
  primary key (`id`),
  key `iso` (`iso`)
) {tabletype}