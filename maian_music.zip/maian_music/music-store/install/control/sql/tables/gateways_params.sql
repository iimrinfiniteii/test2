create table `{prefix}gateways_params` (
  `id` int(3) not null auto_increment,
  `gateway` int(6) not null default '0',
  `param` varchar(200) not null default '',
  `value` varchar(250) not null default '',
  primary key (`id`),
  key `mthd_index` (`gateway`)
) {tabletype}