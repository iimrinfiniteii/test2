create table `{prefix}shipping` (
  `id` int(10) unsigned not null auto_increment,
  `name` varchar(250) not null default '',
  `cost` varchar(250) not null default '',
  primary key (`id`)
) {tabletype}