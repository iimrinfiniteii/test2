create table `{prefix}gateways` (
  `id` int(3) not null auto_increment,
  `display` varchar(100) not null default '',
  `liveserver` varchar(250) not null default '',
  `sandboxserver` varchar(250) not null default '',
  `image` varchar(100) not null default '',
  `webpage` varchar(100) not null default '',
  `status` enum('yes','no') not null default 'yes',
  `class` varchar(100) not null default '',
  `default` enum('yes','no') not null default 'no',
  `docs` varchar(200) not null default '',
  primary key (`id`)
) {tabletype}