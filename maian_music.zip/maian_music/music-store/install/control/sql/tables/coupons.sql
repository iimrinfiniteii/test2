create table `{prefix}coupons` (
  `id` int(10) unsigned not null auto_increment,
  `code` varchar(30) not null default '',
  `discount` varchar(10) not null default '',
  `expiry` int(30) not null default '0',
  `enabled` enum('yes','no') not null default 'yes',
  `accounts` text default null,
  primary key (`id`),
  key `code` (`code`)
) {tabletype}