<?php

/* INSTALLER - AJAX OPS
--------------------------------------------------------*/

if (!isset($_GET['ajax-ops']) || !defined('PARENT')) {
  exit;
}

$arr    = array('status' => 'err', 'txt' => array('System Error', 'An error has occurred during install, please check the error log.<br><br><b>logs/install-error-report.txt</b><br><br>If install logging isn`t enabled, enable it in "install/control/config.php".'));
$engine = (isset($_POST['engine']) && in_array($_POST['engine'], array('MyISAM', 'InnoDB')) ? $_POST['engine'] : 'MyISAM');
$c      = (isset($_POST['charset']) ? $_POST['charset'] : $defChar);
$tableD = array();

if ($sqlVer < 5) {
  if ($c) {
    $split     = explode('_', $c);
    $tableType = 'DEFAULT CHARACTER SET ' . $split[0] . mswNL();
    $tableType .= 'COLLATE ' . $c . mswNL();
  }
  $tableType .= 'TYPE = ' . $engine;
} else {
  if ($c) {
    $split     = explode('_', $c);
    $tableType = 'CHARSET = ' . $split[0] . mswNL();
    $tableType .= 'COLLATE ' . $c . mswNL();
  }
  $tableType .= 'ENGINE = ' . $engine;
}

switch($_GET['ajax-ops']) {
  case 'install':
    // Set timezone for installer..
    @date_default_timezone_set($_POST['timezone']);
    define('INSTALL_RUN', 1);
    include(PATH . 'control/tables.php');
    if ($count > 0) {
      $arr['txt'][1] = 'One or more database tables could not be installed. Check the error log for more information.<br><br><b>logs/install-error-report.txt</b><br><br>If install logging isn`t enabled, enable it in "install/control/config.php".';
    } else {
      include(PATH . 'control/data.php');
      if ($dcount > 0) {
        $arr['txt'][1] = 'The database errored when installing the default system data. Check the error log for more information.<br><br><b>logs/install-error-report.txt</b><br><br>If install logging isn`t enabled, enable it in "install/control/config.php".';
      } else {
        if ($count == 0) {
          $arr['status'] = 'ok';
          $arr['txt'] = array('Installation Successful', '<b>' . SCRIPT_NAME . '</b> installed with no errors and the software is ready to use.<br><br>Please refer to the installation instructions for more info and login details etc.<br><br>I hope you enjoy your new system.');
        }
      }
    }
    break;
  case 'upgrade':
    // Set timezone for upgrade..
    @date_default_timezone_set($SETTINGS->timezone);
    define('UPGRADE_RUN', 1);
    $skipVersions = array('2.0','2.1','2.2','2.3','2.4');
    if (in_array(SCRIPT_VERSION, $skipVersions)) {
      include(PATH . 'control/upgrade/version.php');
      include(PATH . 'control/upgrade/fixes.php');
      $arr['next'] = 'done';
    } else {
      if (isset($_GET['ustage'])) {
        switch ($_GET['ustage']) {
          case 'start':
            include(PATH . 'control/upgrade/tables.php');
            $arr['next'] = (count($ops) == 1 ? 'done' : '1');
            $arr['prev'] = '0';
            break;
          case $_GET['ustage']:
            sleep(3);
            switch ($_GET['ustage']) {
              case '1':
                include(PATH . 'control/upgrade/music.php');
                break;
              case '2':
                include(PATH . 'control/upgrade/accounts.php');
                break;
              case '3':
                include(PATH . 'control/upgrade/gateways.php');
                break;
              case '4':
                include(PATH . 'control/upgrade/sales.php');
                break;
              case '5':
                include(PATH . 'control/upgrade/settings.php');
                break;
              case '6':
                include(PATH . 'control/upgrade/geo.php');
                break;
              case '7':
                include(PATH . 'control/upgrade/layout.php');
                break;
              case '8':
                include(PATH . 'control/upgrade/finish.php');
                break;
            }
            if ($_GET['ustage'] == count($ops) - 1) {
              include(PATH . 'control/upgrade/version.php');
              $arr['next'] = 'done';
            } else {
              $arr['next'] = ($_GET['ustage'] + 1);
              $arr['prev'] = $_GET['ustage'];
            }
            break;
        }
      }
    }
    break;
}

echo $JSON->encode($arr);
exit;

?>